"""Draw the three-page direct-foundation calculation report from calculated data.

The layout is reconstructed from the example report with ReportLab text and
vector rules.  Neither the example PDF nor Excel is needed at report time.
Coordinates below are measured in points from the top of an A4 page.
"""

from __future__ import annotations

from fractions import Fraction
import os
from pathlib import Path
from typing import Any

from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.cidfonts import UnicodeCIDFont
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen.canvas import Canvas


_PAGE = (595, 842)
_SERIF = "HeiseiMin-W3"
_GOTHIC = "HeiseiKakuGo-W5"
_BLACK = (0, 0, 0)
_RED = (1, 0, 0)


def _fonts() -> tuple[str, str]:
    """Embed matching installed fonts when available; retain a portable fallback."""
    windows = os.environ.get("WINDIR")
    if windows:
        directory = Path(windows) / "Fonts"
        candidates = (("PierMincho", directory / "msmincho.ttc"),
                      ("PierGothic", directory / "msgothic.ttc"))
        if all(path.is_file() for _, path in candidates):
            for name, path in candidates:
                if name not in pdfmetrics.getRegisteredFontNames():
                    pdfmetrics.registerFont(TTFont(name, str(path), subfontIndex=0))
            return candidates[0][0], candidates[1][0]
    for font in (_SERIF, _GOTHIC):
        if font not in pdfmetrics.getRegisteredFontNames():
            pdfmetrics.registerFont(UnicodeCIDFont(font))
    return _SERIF, _GOTHIC


def _number(value: Any, decimals: int | None = None, comma: bool = False) -> str:
    if value is None or value == "":
        return ""
    if decimals is None:
        return f"{value:,g}" if comma else f"{value:g}"
    return format(value, f"{',' if comma else ''}.{decimals}f")


def _fraction(value: float) -> str:
    fraction = Fraction(value).limit_denominator(1000)
    if fraction.denominator == 1:
        return str(fraction.numerator)
    return f"{fraction.numerator}/{fraction.denominator}"


class _Page:
    """Small drawing vocabulary with Excel-like half/full-width text spacing."""

    def __init__(self, canvas: Canvas, fonts: tuple[str, str]):
        self.canvas = canvas
        self.fonts = fonts

    @staticmethod
    def width(text: str, size: float) -> float:
        return sum(0.5 if ord(ch) < 128 else 1.0 for ch in text) * size * (10.08 / 9.9)

    def text(
        self,
        x: float,
        y: float,
        value: Any,
        *,
        size: float = 9.9,
        gothic: bool = False,
        color: tuple = _BLACK,
        align: str = "left",
        max_width: float | None = None,
    ) -> None:
        text = str(value)
        if not text:
            return
        width = self.width(text, size)
        if max_width and width > max_width:
            size *= max_width / width
            width = max_width
        if align == "right":
            x -= width
        elif align == "center":
            x -= width / 2
        c = self.canvas
        c.setFillColorRGB(*color)
        font = self.fonts[1 if gothic else 0]
        obj = c.beginText(x, _PAGE[1] - y)
        obj.setFont(font, size)
        # A complete string retains clean extraction. Fit its measured width to
        # the workbook's cell typography without overlapping proportional glyphs
        # when the portable CID fallback is used.
        measured = pdfmetrics.stringWidth(text, font, size)
        if measured:
            obj.setHorizScale(width / measured * 100)
        obj.textOut(text)
        c.drawText(obj)

    def symbol(self, x: float, y: float, base: str, sub: str) -> float:
        self.text(x, y, base)
        advance = self.width(base, 9.9)
        self.text(x + advance, y + 1.92, sub, size=6.5)
        return x + advance + self.width(sub, 6.5)

    def unit(self, x: float, y: float, base: str, exponent: int, suffix: str = "") -> None:
        self.text(x, y, base)
        end = x + self.width(base, 9.9)
        self.text(end, y - 4.92, exponent, size=6.5)
        self.text(end + 3.36, y, suffix)

    def line(self, x1: float, y1: float, x2: float, y2: float, width: float = 0.12) -> None:
        c = self.canvas
        c.setStrokeColorRGB(*_BLACK)
        c.setLineWidth(width)
        c.line(x1, _PAGE[1] - y1, x2, _PAGE[1] - y2)

    def heading(self, x: float, y: float, text: str, reference_x: float | None = None) -> None:
        self.text(x, y, text, gothic=True)
        if reference_x is not None:
            self.text(reference_x, y, "【基礎標準 13.2.2.2】", gothic=True)

    def definition(
        self,
        y: float,
        base: str,
        sub: str,
        description: str,
        *,
        first: bool = False,
        unit: tuple[str, int, str] | None = None,
    ) -> None:
        if first:
            self.text(157.8, y, "ここに、")
        self.symbol(198.12, y - 0.36, base, sub)
        self.text(210.96, y, "：" + description)
        if unit:
            x = 210.96 + self.width("：" + description, 9.9)
            self.unit(x, y, *unit)


def _soil_table(p: _Page, layers: list[dict]) -> None:
    left, top, right, bottom = 76.92, 185.64, 571.32, 371.28
    c = p.canvas
    c.setFillColorRGB(1, 1, 0.6)
    c.rect(left, _PAGE[1] - 214.26, right - left, 28.62, stroke=0, fill=1)
    xs = [left, 121.26, 179.34, 237.42, 280.98, 339.06, 397.14, 455.22, 513.30, right]
    for x in xs:
        p.line(x, 199.98 if x == 339.06 else top, x, bottom,
               0.96 if x in (left, right) else 0.12)
    p.line(left, top, right, top, 0.96)
    p.line(left, bottom, right, bottom, 0.96)
    p.line(280.98, 199.98, right, 199.98)
    for row in range(11):
        p.line(left, 214.26 + row * 14.28, right, 214.26 + row * 14.28)

    p.text(324.12, 183.48, "地盤の諸数値の設計用値のまとめ", gothic=True, align="center")
    for x, text in ((99.09, "層番"), (208.38, "土質区分"), (259.2, "Ｎ値")):
        p.text(x, 203.04, text, gothic=True, align="center")
    p.text(150.3, 197.52, "層厚", gothic=True, align="center")
    p.text(150.3, 208.68, "(m)", gothic=True, align="center")
    p.text(339.06, 197.76, "単位体積重量", gothic=True, align="center")
    p.text(310.02, 212.04, "湿潤", gothic=True, align="center")
    p.text(368.10, 212.04, "水中", gothic=True, align="center")
    for x, label, size in ((426.18, "内部摩擦角", 9.9), (484.26, "一軸圧縮強度", 8.9), (542.31, "変形係数", 9.9)):
        p.text(x, 195.96, label, size=size, gothic=True, align="center")
    p.text(426.18, 210.24, "φd(°)", gothic=True, align="center")
    for x, base in ((462.48, "qu(kN/m"), (520.56, "Ed(kN/m")):
        p.text(x, 211.2, base, gothic=True)
        p.text(x + 35.28, 206.28, "2", size=6.5, gothic=True)
        p.text(x + 38.64, 211.2, ")", gothic=True)

    fields = [
        ("name", None, False), ("thickness", 3, False), ("soil_type", None, False),
        ("n_value", None, False), ("unit_weight_wet", 1, False),
        ("unit_weight_submerged", 1, False), ("friction_angle", None, False),
        ("compressive_strength", None, False), ("deformation_modulus", None, True),
    ]
    for row, layer in enumerate(layers):
        y = 226.32 + row * 14.28
        for col, (field, decimals, comma) in enumerate(fields):
            value = layer.get(field)
            text = str(value or "") if field in ("name", "soil_type") else _number(value, decimals, comma)
            numeric = field not in ("name", "soil_type")
            x = xs[col + 1] - 2 if numeric else (xs[col] + xs[col + 1]) / 2
            p.text(x, y, text, gothic=True, color=_RED,
                   align="right" if numeric else "center", max_width=xs[col + 1] - xs[col] - 4)


def _page_one(p: _Page, result: dict) -> None:
    foundation, model = result["foundation"], result["model"]
    modulus = result["support_layer"]["deformation_modulus"]
    p.heading(93.96, 97.8, "§5. 地盤のモデル化")
    p.heading(108.48, 126.36, "5.1 地盤の諸数値の設計用値のまとめ")
    p.text(123, 154.92, "本橋脚の設計に用いる地盤の諸数値の設計用値を表 2.4.8 に示す.")
    _soil_table(p, result["layers"])
    p.text(123, 397.68, "支持層の支持力係数")
    for y, label in ((417.96, "地震時を除く"), (438.24, "地震時")):
        p.symbol(143.28, y - 2.16, "N", "γ")
        p.text(169.92, y, "=")
        p.text(203.52, y, _number(model["bearing_n_gamma"]), color=_RED, align="right", max_width=28)
        p.text(210.12, y, ",")
        p.symbol(231.96, y - 2.16, "N", "q")
        p.text(257.04, y, "=")
        p.text(290.64, y, _number(model["bearing_n_q"]), color=_RED, align="right", max_width=28)
        p.text(311.76, y, label)

    p.heading(108.48, 481.08, "5.2 地盤反力係数の算定")
    p.heading(123, 509.64, "(1) フーチング底面の鉛直地盤ばね定数")
    p.heading(137.52, 538.2, "1) フーチング底面の鉛直地盤反力係数", 340.8)
    for y, coefficient, exponent, label in (
        (565.92, "6.9", "-1/2", "（砂質土）"),
        (580.20, "5.1", "-3/4", "（砂質土，粘性土の互層）"),
        (594.48, "3.8", "-1", "（粘性土）"),
    ):
        p.symbol(153.72, y - 0.36, "k", "v")
        p.text(169.92, y, "=")
        p.text(191.4, y, coefficient)
        x = p.symbol(210.12, y - 0.36, "ρ", "gk")
        x = p.symbol(x, y - 0.36, "E", "d")
        x = p.symbol(x, y - 0.36, "B", "v")
        p.text(x + 1, y - 5.28, exponent, size=6.5)
        p.text(282.72, y, label)

    # Correct the legacy sheet's kh / horizontal definition to the kv used here.
    p.definition(623.04, "k", "v", "フーチング底面の鉛直地盤反力係数 ", first=True, unit=("(kN/m", 3, ")"))
    p.symbol(189.72, 636.96, "ρ", "gk")
    p.text(210.96, 637.32, "：地盤反力係数に関する地盤修正係数")
    p.definition(651.6, "E", "d", "地盤の変形係数")
    p.text(341.64, 651.6, "(=")
    p.text(395, 651.6, _number(modulus), align="right", max_width=40)
    p.unit(413.4, 651.6, "kN/m", 2, ")")
    p.definition(665.88, "B", "v", "フーチング底面の換算幅 (m)")
    p.symbol(210.12, 679.8, "B", "v")
    p.text(223.56, 680.16, "= √")
    p.symbol(248.76, 679.8, "A", "v")
    p.text(341.64, 680.16, "(=")
    p.line(353.04, 679.2, 355.32, 682.68, 0.24)
    p.line(355.32, 682.68, 357.6, 669.12, 0.24)
    p.line(357.6, 669.12, 414.84, 669.12, 0.24)
    p.text(410.04, 680.16, _number(foundation["area"], 3), align="right", max_width=48)
    p.text(460.32, 680.16, "=")
    p.text(525.96, 680.16, _number(foundation["equivalent_width"], 3), align="right", max_width=48)
    p.text(530.4, 680.16, "m)")
    p.symbol(211.8, 694.08, "A", "v")
    p.text(225.48, 694.44, "：フーチング底面積")
    p.text(341.64, 694.44, "(=")
    p.text(388.32, 694.44, _number(foundation["B"], 3), color=_RED, align="right", max_width=33)
    p.text(399.72, 694.44, "×")
    p.text(446.4, 694.44, _number(foundation["L"], 3), color=_RED, align="right", max_width=33)
    p.text(460.32, 694.44, "=")
    p.text(525.96, 694.44, _number(foundation["area"], 3), align="right", max_width=48)
    p.unit(529.56, 694.44, "m", 2, ")")

    for key, label, y in (("long_term", "長期", 723), ("short_term", "短期", 765.84)):
        p.text(152.04, y, "・" + label + " ( ")
        p.symbol(194.16, y - 0.36, "ρ", "gk")
        p.text(215, y, "=")
        p.text(245.4, y, _number(model["rho_" + key], 1), align="right", max_width=22)
        p.text(253.68, y, ")")
        fy = y + 14.28
        p.symbol(168.24, fy - 0.36, "k", "v")
        p.text(184.44, fy, "=")
        for x, value, width in (
            (216.36, _number(model["coefficient"]), 25),
            (259.92, _number(model["rho_" + key], 1), 25),
            (328.08, _number(modulus), 48),
            (395.64, _number(foundation["equivalent_width"], 3), 43),
            (511.8, _number(result[key]["kv"], 0), 40),
        ):
            p.text(x, fy, value, align="right", max_width=width)
        for x in (225.48, 269.04, 341.64):
            p.text(x, fy, "×")
        p.text(412.92, fy - 4.92, _fraction(model["exponent"]), size=6.5)
        p.text(460.32, fy, "=")
        p.unit(529.56, fy, "kN/m", 3)


def _product_formula(p: _Page, y: float, base: str, sub: str, factor_sub: str, area_base: str = "A") -> None:
    p.symbol(168.24, y - 0.36, base, sub)
    p.text(184.44, y, "=")
    x = p.symbol(195.6, y - 0.36, "k", factor_sub)
    p.symbol(x, y - 0.36, area_base, "v")


def _spring_line(p: _Page, y: float, base: str, sub: str, factor: float, area: float, value: float) -> None:
    p.symbol(168.24, y - 0.36, base, sub)
    p.text(184.44, y, "=")
    p.text(240.96, y, _number(factor, 0), align="right", max_width=45)
    p.text(254.52, y, "×")
    p.text(316.08, y, _number(area, 3), align="right", max_width=59)
    p.text(358.68, y, "=")
    p.text(433.8, y, _number(value, 0, True), align="right", max_width=65)
    p.text(442.44, y, "kN/m")


def _page_two(p: _Page, result: dict) -> None:
    area = result["foundation"]["area"]
    ratio = _fraction(result["model"]["shear_ratio"])
    p.heading(137.52, 97.8, "2) フーチング底面の鉛直地盤ばね定数", 340.8)
    _product_formula(p, 125.52, "K", "v", "v")
    p.definition(139.8, "K", "v", "フーチング底面の鉛直地盤ばね定数 (kN/m)", first=True)
    p.definition(154.08, "k", "v", "フーチング底面の鉛直地盤反力係数 ", unit=("(kN/m", 3, ")"))
    p.definition(168.36, "A", "v", "フーチング底面積 ", unit=("(m", 2, ")"))
    for key, label, y in (("long_term", "長期", 211.2), ("short_term", "短期", 254.04)):
        p.text(152.04, y - 13.44, "・" + label)
        _spring_line(p, y, "K", "v", result[key]["kv"], area, result[key]["Kv"])

    p.heading(123, 297.72, " (2) フーチング底面のせん断地盤ばね定数")
    p.heading(137.52, 326.28, "1) フーチング底面のせん断地盤反力係数", 369.84)
    p.symbol(168.24, 353.64, "k", "s")
    p.text(184.44, 354, "=")
    p.text(195.6, 353.64, "λ")
    p.symbol(205.68, 353.64, "k", "v")
    p.definition(382.56, "k", "s", "フーチング底面のせん断地盤反力係数 ", first=True, unit=("(kN/m", 3, ")"))
    p.text(196.44, 397.68, "λ")
    p.text(210.96, 397.68, "：換算係数")
    p.text(273.48, 397.68, "（ =")
    p.text(302.88, 397.68, ratio, max_width=25)
    p.text(336.28, 397.68, "とする）")
    for key, label, y in (("long_term", "長期", 439.68), ("short_term", "短期", 482.52)):
        p.text(152.04, y - 13.44, "・" + label)
        p.symbol(168.24, y - 0.36, "k", "s")
        p.text(184.44, y, "=")
        p.text(201.24, y, ratio, max_width=22)
        p.text(225.48, y, "×")
        p.text(284.52, y, _number(result[key]["kv"], 0), align="right", max_width=48)
        p.text(358.68, y, "=")
        p.text(410.16, y, _number(result[key]["ks"], 0), align="right", max_width=38)
        p.unit(427.92, y, "kN/m", 3)

    p.heading(137.52, 526.2, "2) フーチング底面のせん断地盤ばね定数", 369.84)
    _product_formula(p, 553.92, "K", "s", "s")
    p.definition(582.48, "K", "s", "フーチング底面のせん断地盤ばね定数 (kN/m)", first=True)
    p.definition(596.76, "k", "s", "フーチング底面のせん断地盤反力係数 ", unit=("(kN/m", 3, ")"))
    p.definition(611.04, "A", "v", "フーチング底面積 ", unit=("(m", 2, ")"))
    for key, label, y in (("long_term", "長期", 653.88), ("short_term", "短期", 696.72)):
        p.text(152.04, y - 13.44, "・" + label)
        _spring_line(p, y, "K", "s", result[key]["ks"], area, result[key]["Ks"])


def _page_three(p: _Page, result: dict) -> None:
    foundation = result["foundation"]
    p.heading(123, 97.8, " (3) フーチング底面の回転地盤ばね定数", 326.28)
    _product_formula(p, 125.52, "K", "r", "v", "I")
    p.definition(154.08, "K", "r", "フーチング底面の回転地盤ばね定数 (kN・m/rad)", first=True)
    p.definition(168.36, "k", "v", "フーチング底面の鉛直地盤反力係数", unit=("(kN/m", 3, ")"))
    p.definition(182.64, "I", "v", "フーチング底面の断面二次モーメント", unit=("(m", 4, ")"))

    for direction, title, y, first, cubed in (
        ("longitudinal", "1) 線路方向", 239.76, "L", "B"),
        ("transverse", "2) 線路直角方向", 396.84, "B", "L"),
    ):
        inertia = foundation["inertia_" + direction]
        p.heading(137.52, y - 27.72, title)
        p.symbol(153.72, y - 0.36, "I", "v")
        p.text(169.92, y, "=")
        p.text(214.08, y, _number(foundation[first], 3), align="right", max_width=34)
        p.text(225.48, y, "×")
        p.text(272.16, y, _number(foundation[cubed], 3), align="right", max_width=34)
        p.text(282.24, y - 4.92, "3", size=6.5)
        p.text(288.96, y, "/ 12 =")
        p.text(386.4, y, _number(inertia, 6), align="right", max_width=57)
        p.unit(400.56, y, "m", 4)
        for key, label, offset in (("long_term", "長期", 42.84), ("short_term", "短期", 85.68)):
            fy = y + offset
            p.text(152.04, fy - 13.44, "・" + label)
            p.symbol(168.24, fy - 0.36, "K", "r")
            p.text(184.44, fy, "=")
            p.text(240.96, fy, _number(result[key]["kv"], 0), align="right", max_width=46)
            p.text(254.52, fy, "×")
            p.text(328.32, fy, _number(inertia, 6), align="right", max_width=57)
            p.text(344.16, fy, "=")
            p.text(419.28, fy, _number(result[key]["Kr_" + direction], 0, True), align="right", max_width=66)
            p.text(427.92, fy, "kN・m/rad")


def render_report(result: dict, output_path: Path) -> None:
    """Render the calculation result as a selectable-text, three-page A4 PDF.

    Matching Japanese fonts are embedded when installed; standard Japanese CID
    fonts provide a portable fallback. No Excel or reference document is needed.
    Inputs appear in red as in the workbook.
    The fixed report has eleven soil rows; reject a longer profile explicitly
    instead of hiding any design input.
    """
    if len(result["layers"]) > 11:
        raise ValueError("The three-page report supports at most 11 soil layers.")
    fonts = _fonts()
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    c = Canvas(str(output_path), pagesize=_PAGE, pageCompression=1, invariant=1)
    c.setTitle("直接基礎 - 地盤のモデル化")
    c.setAuthor("P7橋脚 Python設計プログラム")
    c.setSubject("地盤の設計用値および直接基礎の地盤ばね定数")
    p = _Page(c, fonts)
    for draw in (_page_one, _page_two, _page_three):
        draw(p, result)
        c.showPage()
    c.save()
