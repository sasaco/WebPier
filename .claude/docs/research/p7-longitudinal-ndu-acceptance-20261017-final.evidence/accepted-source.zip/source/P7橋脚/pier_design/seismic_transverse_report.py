"""Four-page transverse earthquake load report drawn only from its calculated snapshot."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import replace
from decimal import Decimal, DecimalException, ROUND_HALF_UP, localcontext
from io import BytesIO
import math
from pathlib import Path
import os
from tempfile import NamedTemporaryFile

from reportlab.pdfbase import pdfmetrics
from reportlab.pdfgen.canvas import Canvas

from .frame_model_report import draw_frame_graph
from .frame_outline import Dimension, FrameLayout, build_outline, dimension_text, draw_outline, fit_frame, frame_dimensions
from .report import _Page, _fonts


_PAGE_SIZE = (595, 842)
_DIRECTIONS = {"down": "↓", "up": "↑", "right": "→"}
_LOAD_TYPES = {"fixed": "固定", "incremental": "増分", "limited_incremental": "限定増分"}


def _number(value: float, places: int = 2) -> str:
    if not math.isfinite(value):
        raise ValueError("0720帳票: 表示値には有限の数値が必要です")
    return f"{value:.{places}f}"


def _formula_factors(values: dict[str, tuple[float, int]], expected: float,
                     evaluate: Callable[[dict[str, Decimal]], Decimal], *, places: int = 2) -> dict[str, str]:
    """Add only the factor precision needed to reproduce the printed result.

    Begin with the reference's decimal places, then check the displayed
    decimal arithmetic itself. This keeps float/Single trailing noise out of
    the page without presenting a false equality for nonround inputs.
    """
    target = Decimal(_number(expected, places))
    with localcontext() as context:
        context.prec = 60
        for extra in range(13):
            formatted = {}
            for key, (value, minimum) in values.items():
                text = _number(value, minimum + extra)
                while len(text.partition(".")[2]) > minimum and text.endswith("0"):
                    text = text[:-1]
                formatted[key] = text
            try:
                displayed = evaluate({key: Decimal(text) for key, text in formatted.items()})
                rounded = displayed.quantize(Decimal(1).scaleb(-places), rounding=ROUND_HALF_UP)
            except DecimalException:
                # A positive divisor may round to zero at the initial display
                # precision; try additional digits before rejecting the page.
                continue
            if rounded == target:
                return formatted
    raise ValueError("0720帳票: 表示因子と計算結果を整合させる精度を確保できません")


def _text(p: _Page, x: float, y: float, value: object, *, size: float = 9.9,
          align: str = "left", width: float | None = None, gothic: bool = False) -> None:
    """Keep all report text readable; reject overflow instead of clipping it."""
    text = str(value)
    if width is not None and p.width(text, size) > width:
        size *= width / p.width(text, size)
    if size < 8.5:
        raise ValueError(f"0720帳票: 4ページ内に可読な文字サイズで収まりません: {text}")
    measured = p.width(text, size)
    left = x - measured if align == "right" else x - measured / 2 if align == "center" else x
    if left < 35 or left + measured > 565 or y < 35 or y > 785:
        raise ValueError(f"0720帳票: 4ページの描画範囲を超えています: {text}")
    p.text(x, y, text, size=size, align=align, gothic=gothic)


def _heading(p: _Page, y: float, text: str, *, x: float = 95) -> None:
    _text(p, x, y, text, gothic=True)


def _horizontal_dimension(p: _Page, left: float, right: float, y: float, value: float) -> None:
    label = _number(value, 3)
    if right - left < p.width(label, 9.9) + 6:
        raise ValueError("0720帳票: 水平寸法を可読な間隔で表示できません")
    p.line(left, y, right, y)
    for xx, direction in ((left, 1), (right, -1)):
        p.line(xx, y - 7, xx, y + 5)
        p.line(xx, y, xx + direction * 4, y - 2)
        p.line(xx, y, xx + direction * 4, y + 2)
    _text(p, (left + right) / 2, y - 4, label, align="center")


def _clear_dimension_labels(layout: FrameLayout, font: str) -> FrameLayout:
    """Keep short upper intervals and micro labels off extension lines."""
    ys = list(layout.dimension_label_ys)
    widths = [pdfmetrics.stringWidth(dimension_text(dimension), font, 9.9)
              for dimension in layout.dimensions]
    extensions = {layout.y(height) for dimension in layout.dimensions
                  for height in (dimension.top, dimension.bottom)}
    for index, dimension in enumerate(layout.dimensions):
        if (dimension.name != "柱下端微小部材" and
                (dimension.name != "上部形状" or dimension.value * layout.scale >= widths[index] + 6)):
            continue
        desired = layout.y(dimension.top) - widths[index] / 2 - 7
        selected_y = None
        for offset in range(100):
            candidate = desired - offset * 2
            top, bottom = candidate - widths[index] / 2, candidate + widths[index] / 2
            if top < 179:
                break
            if any(top - 3 <= yy <= bottom + 3 for yy in extensions):
                continue
            if any(other.column == dimension.column and other_index != index
                   and abs(candidate - ys[other_index]) < (widths[index] + widths[other_index]) / 2 + 4
                   for other_index, other in enumerate(layout.dimensions)):
                continue
            selected_y = candidate
            break
        if selected_y is None:
            raise ValueError("0720帳票: 短い区間の寸法文字を可読な間隔で表示できません")
        ys[index] = selected_y
    bounds = list(layout.annotation_bounds)
    start = len(layout.node_labels) + len(layout.member_labels)
    for index, (old_y, new_y) in enumerate(zip(layout.dimension_label_ys, ys, strict=True)):
        left, top, right, bottom = bounds[start + index]
        bounds[start + index] = (left, top + new_y - old_y, right, bottom + new_y - old_y)
    return replace(layout, dimension_label_ys=tuple(ys), annotation_bounds=tuple(bounds))


def _micro_node_labels(frame: dict, layout: FrameLayout, font: str) -> FrameLayout:
    """Keep the near-coincident endpoint labels vertically ordered at true scale."""
    labels, bounds = dict(layout.node_labels), list(layout.annotation_bounds)
    roles = frame["node_ids"]
    endpoints = {roles["column_base_micro_top"]: -6, roles["footing_top"]: 14}
    positions = {node["id"]: index for index, node in enumerate(frame["nodes"])}
    occupied = [bound for index, bound in enumerate(bounds)
                if index not in {positions[identifier] for identifier in endpoints}]
    ascent, descent = pdfmetrics.getAscentDescent(font, 9.9)
    for node in frame["nodes"]:
        identifier = node["id"]
        if identifier not in endpoints:
            continue
        xx, yy = layout.point(node["x"], node["y"])
        width = pdfmetrics.stringWidth(str(identifier), font, 9.9)
        ty = yy + endpoints[identifier]
        for left_offset in (10, 24, 38, 52):
            tx = xx - left_offset
            bound = (tx - width, ty - ascent, tx, ty - descent)
            if bound[0] < 97 or bound[1] < 179 or bound[2] > 533 or bound[3] > 679:
                continue
            if any(bound[0] < other[2] + 2 and bound[2] > other[0] - 2
                   and bound[1] < other[3] + 2 and bound[3] > other[1] - 2 for other in occupied):
                continue
            labels[identifier] = (tx, ty)
            bounds[positions[identifier]] = bound
            occupied.append(bound)
            break
        else:
            raise ValueError("0720帳票: 微小部材の節点番号を可読な間隔で表示できません")
    return replace(layout, node_labels=labels, annotation_bounds=tuple(bounds))


def _micro_node_leaders(p: _Page, frame: dict, layout: FrameLayout) -> None:
    roles = frame["node_ids"]
    for node in frame["nodes"]:
        identifier = node["id"]
        if identifier not in (roles["column_base_micro_top"], roles["footing_top"]):
            continue
        xx, yy = layout.point(node["x"], node["y"])
        tx, ty = layout.node_labels[identifier]
        end_offset = -2 if identifier == roles["column_base_micro_top"] else 2
        p.line(tx + 2, ty - 3, xx - 2, yy + end_offset, .12)


def _seismic_frame_dimensions(frame: dict) -> tuple[Dimension, ...]:
    """Dimension every retained upper level and the split physical column."""
    nodes = {node["id"]: node for node in frame["nodes"]}
    roles = frame["node_ids"]
    cap_top = nodes[roles["cap_top"]]["y"]
    micro_top = nodes[roles["column_base_micro_top"]]["y"]
    footing_top = nodes[roles["footing_top"]]["y"]
    upper_heights = sorted({nodes[level["node_id"]]["y"]
                            for level in frame["upper_levels"].values()
                            if nodes[level["node_id"]]["y"] > cap_top})
    upper_top = upper_heights[-1] if upper_heights else cap_top
    dimensions = []
    for dimension in frame_dimensions(frame):
        if dimension.name == "H4":
            dimension = replace(dimension, bottom=micro_top)
        elif dimension.column == 1 and dimension.top == cap_top:
            dimension = replace(dimension, top=upper_top, bottom=micro_top)
        dimensions.append(dimension)
    previous = cap_top
    for top in upper_heights:
        dimensions.append(Dimension("上部形状", top, previous))
        previous = top
    dimensions.extend(Dimension("柱下端微小部材", micro_top, footing_top, column)
                      for column in (0, 1))
    return tuple(dimensions)


def _overall_dimension(p: _Page, layout: FrameLayout, top: float, bottom: float) -> None:
    x = layout.dimension_xs[1] + 26
    ya, yb = layout.y(top), layout.y(bottom)
    if x > 554:
        raise ValueError("0720帳票: 全高寸法を可読な間隔で表示できません")
    for y in (ya, yb):
        p.line(layout.extension_x, y, x + 3, y)
    p.line(x, ya, x, yb)
    for y, sign in ((ya, 1), (yb, -1)):
        p.line(x, y, x - 2, y + sign * 4)
        p.line(x, y, x + 2, y + sign * 4)
    p.canvas.saveState()
    p.canvas.translate(x - 7, _PAGE_SIZE[1] - (ya + yb) / 2)
    p.canvas.rotate(90)
    p.canvas.setFont(p.fonts[0], 9.9)
    p.canvas.drawCentredString(0, 0, _number(top - bottom, 3))
    p.canvas.restoreState()


def _model(p: _Page, result: dict) -> None:
    _heading(p, 95, "§11. 線路直角方向の計算（地震時）", x=73)
    _heading(p, 124, "11.1 検討モデル", x=82)
    _heading(p, 152, "(1) 骨組図")
    frame, geometry = result["frame"], result["input"]["geometry"]
    outline = build_outline(geometry, "w")
    try:
        layout = fit_frame(outline, frame["nodes"], (95, 177, 509, 681),
                           members=frame["members"], dimensions=_seismic_frame_dimensions(frame),
                           font=p.fonts[0], font_size=9.9)
        layout = _clear_dimension_labels(layout, p.fonts[0])
        layout = _micro_node_labels(frame, layout, p.fonts[0])
    except ValueError as error:
        raise ValueError(f"0720帳票: 骨組図を4ページ内に可読な間隔で表示できません: {error}") from error
    draw_outline(p.canvas, outline, layout)
    draw_frame_graph(p.canvas, p.fonts, frame, layout)
    _micro_node_leaders(p, frame, layout)
    _overall_dimension(p, layout, max(node["y"] for node in frame["nodes"]),
                       min(node["y"] for node in frame["nodes"]))
    w7, w8, w9 = (geometry[f"w{i}"] for i in (7, 8, 9))
    xs = [layout.point(x, 0)[0] for x in (-w8 / 2 - w7, -w8 / 2, w8 / 2, w8 / 2 + w9)]
    for x in (xs[0], xs[-1]):
        p.line(x, layout.y(0) + 7, x, 732)
    if all(xs[i + 1] - xs[i] >= p.width(_number(value, 3), 9.9) + 6
           for i, value in enumerate((w7, w8, w9))):
        for i, value in enumerate((w7, w8, w9)):
            _horizontal_dimension(p, xs[i], xs[i + 1], 706, value)
    else:
        _text(p, 100, 706, f"左張出し {_number(w7, 3)}   中央幅 {_number(w8, 3)}   右張出し {_number(w9, 3)}", width=435)
    _horizontal_dimension(p, xs[0], xs[-1], 731, w7 + w8 + w9)
    levels = frame["upper_levels"]
    _text(p, 100, 754, f"上部形状高（h1＋h2）：B {_number(levels['B']['height'], 3)} m、C {_number(levels['C']['height'], 3)} m", size=9, width=420)
    _text(p, 535, 775, "単位：m", align="right")


def _train_factors(row: dict) -> dict[str, str]:
    """Keep both N and M consistent with the same printed source and rate."""
    values = {"source": (row["upstream_N"], 2), "rate": (row["factor"], 3), "arm": (row["arm"], 3)}
    with localcontext() as context:
        context.prec = 60
        for extra in range(13):
            factors = {key: _number(value, places + extra).rstrip("0").rstrip(".")
                       if extra else _number(value, places)
                       for key, (value, places) in values.items()}
            decimals = {key: Decimal(value) for key, value in factors.items()}
            force = decimals["source"] * decimals["rate"]
            moment = force * decimals["arm"]
            if (force.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP) == Decimal(_number(row["N"]))
                    and moment.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP) == Decimal(_number(row["M"]))):
                return factors
    raise ValueError("0720帳票: 列車荷重の表示因子と計算結果を整合させる精度を確保できません")


def _train_table(p: _Page, y: float, action: dict, label: str) -> float:
    _text(p, 106, y, f"・{label}線載荷")
    y += 18
    for x, text in ((283, "鉛直力 (kN)"), (433, "アーム (m)"), (508, "モーメント (kN・m)")):
        _text(p, x, y, text, align="center", size=9)
    y += 15
    for row in action["rows"]:
        if not row["active"] and row["raw_N"] == 0:
            continue
        factors = _train_factors(row)
        side = "起点側" if row["side"] == "B" else "終点側"
        _text(p, 115, y, f"{side} G{row['bearing']}", size=9, width=70)
        equation = f"{factors['source']} × {factors['rate']} = {_number(row['N'])}"
        _text(p, 392, y, equation, align="right", width=203)
        _text(p, 454, y, factors["arm"], align="right", width=55)
        _text(p, 548, y, _number(row["M"]), align="right", width=87)
        y += 14
    p.line(112, y - 9, 550, y - 9, .8)
    _text(p, 290, y + 5, "Σ")
    _text(p, 392, y + 5, _number(action["table_totals"]["N"]), align="right", width=90)
    _text(p, 471, y + 5, "Σ")
    _text(p, 548, y + 5, _number(action["table_totals"]["M"]), align="right", width=70)
    return y + 31


def _parallel_train_tables(p: _Page, trains: dict) -> float:
    """Give large valid bearing sets two open calculation blocks, one per track.

    Full source-reaction substitutions, each side's own arm and every active
    bearing remain visible. The ordinary six-bearing reference arrangement is
    unchanged; this alternative uses page width before reducing readable text.
    """
    _text(p, 334, 154, "B：起点側、C：終点側", size=9, width=220)
    bottoms = []
    for left, key, label in ((95, "up", "上り"), (334, "down", "下り")):
        action = trains[key]
        _text(p, left + 5, 178, f"・{label}線載荷")
        for offset, text in ((85, "鉛直力 (kN)"), (159, "a (m)"), (199, "M (kN・m)")):
            _text(p, left + offset, 196, text, align="center", size=8.5)
        y = 211.0
        for row in action["rows"]:
            if not row["active"] and row["raw_N"] == 0:
                continue
            factors = _train_factors(row)
            _text(p, left, y, f"{row['side']} G{row['bearing']}", size=9, width=27)
            equation = f"{factors['source']}×{factors['rate']}={_number(row['N'])}"
            _text(p, left + 140, y, equation, align="right", size=9, width=110)
            _text(p, left + 176, y, factors["arm"], align="right", size=9, width=32)
            _text(p, left + 220, y, _number(row["M"]), align="right", size=9, width=40)
            y += 13
        p.line(left, y - 8, left + 220, y - 8, .8)
        _text(p, left + 30, y + 8, "Σ", size=9)
        _text(p, left + 140, y + 8, _number(action["table_totals"]["N"]), align="right", size=9, width=85)
        _text(p, left + 157, y + 8, "Σ", size=9)
        _text(p, left + 220, y + 8, _number(action["table_totals"]["M"]), align="right", size=9, width=55)
        bottoms.append(y + 33)
    return max(bottoms)


def _girder(p: _Page, y: float, result: dict) -> None:
    _heading(p, y, "(6) 地震時桁荷重慣性力")
    _text(p, 106, y + 23, "・起終点側の等価作用（橋脚天端）")
    y += 47
    action = result["horizontal"]["girder"]
    for row in action["rows"]:
        values = row["formula"]["factors"]
        force = _formula_factors({key: (values[key], 2) for key in ("D1", "D2", "S2", "Kh")},
                                 row["H"], lambda f: (f["D1"] + f["D2"] + f["S2"]) * f["Kh"])
        moment = _formula_factors({"H": (row["H"], 2), "height": (row["height"], 3)},
                                  row["M"], lambda f: f["H"] * f["height"])
        _text(p, 112, y, f"{row['side']}  H = ( {force['D1']} + {force['D2']} + {force['S2']} ) × {force['Kh']} = {_number(row['H'])} kN", width=440)
        _text(p, 127, y + 20, f"M = {moment['H']} × {moment['height']} = {_number(row['M'])} kN・m", width=425)
        y += 46
    p.line(112, y - 12, 550, y - 12, .8)
    _text(p, 127, y + 7, f"合計   H = {_number(action['table_totals']['H'])} kN", width=425)
    _text(p, 161, y + 28, f"M = {_number(action['table_totals']['M'])} kN・m", width=391)


def _actions_one(p: _Page, result: dict) -> None:
    _heading(p, 95, "11.2 作用の計算（1）", x=82)
    _text(p, 95, 125, "下記以外の作用は、0620 線路直角方向荷重（地震時以外）と同様とする。", width=460)
    _heading(p, 154, "(5) 列車荷重")
    trains = result["vertical"]["train"]
    active_count = sum(row["active"] or row["raw_N"] != 0
                       for action in trains.values() for row in action["rows"])
    # Sequential tables end at 496 + 14 * active_count, including the girder
    # equations. Use the two-track width when they exceed the 785 pt page limit.
    if 496 + 14 * active_count <= 785:
        y = _train_table(p, 178, trains["up"], "上り")
        y = _train_table(p, y, trains["down"], "下り")
    else:
        y = _parallel_train_tables(p, trains)
    _text(p, 112, y - 5, "Mは丸め前鉛直力×アーム、合計Mは各行表示値の和とする。", size=8.5, width=438)
    _girder(p, y + 23, result)


def _actions_two(p: _Page, result: dict) -> None:
    _heading(p, 95, "11.2 作用の計算（2）", x=82)
    _heading(p, 125, "(7) 地震時列車荷重慣性力")
    action = result["horizontal"]["train"]
    kh = action["rows"][0]["formula"]["factors"]["Kh"]
    _text(p, 106, 151, f"・橋脚天端に作用する荷重（Kh={_number(kh)} 適用済み）")
    y = 180.0
    for row in action["rows"]:
        values = row["formula"]["factors"]
        factors = _formula_factors({"source": (values["earthquake_reaction"], 2), "Kh": (values["Kh"], 2)},
                                  row["H"], lambda f: f["source"] * f["Kh"])
        height = _formula_factors({key: (values[key], 3) for key in ("h1", "h2", "h3", "height_seismic")},
                                 row["height"], lambda f: sum(f.values()), places=3)
        _text(p, 112, y, f"{row['side']}  H = {factors['source']} × {factors['Kh']} = {_number(row['H'])} kN", width=440)
        _text(p, 127, y + 20, f"h = {height['h1']} + {height['h2']} + {height['h3']} + {height['height_seismic']} = {_number(row['height'], 3)} m", width=425)
        y += 48
    totals = action["table_totals"]
    _text(p, 112, 285, "水平力   H = " + " + ".join(_number(row["H"]) for row in action["rows"]) + f" = {_number(totals['H'])} kN", width=440)
    factors = _formula_factors(
        {key: (value, 3 if key.startswith("h") else 2)
         for i, row in enumerate(action["rows"]) for key, value in ((f"H{i}", row["H"]), (f"h{i}", row["height"]))},
        totals["M"], lambda f: sum(f[f"H{i}"] * f[f"h{i}"] for i in range(len(action["rows"]))),
    )
    expression = " + ".join(f"{factors[f'H{i}']} × {factors[f'h{i}']}" for i in range(len(action["rows"])))
    _text(p, 112, 313, f"モーメント   M = {expression} = {_number(totals['M'])} kN・m", width=440)
    _inertia(p, result)


def _line_inertia(p: _Page, y: float, name: str, symbol: str, formula: dict) -> None:
    factors = _formula_factors(
        {key: (value, 1 if key == "unit_weight" else 2) for key, value in formula["factors"].items()},
        formula["value"], lambda values: values["b"] * values["w"] * values["unit_weight"] * values["Kh"],
    )
    first, second = ("w", "b") if symbol == "Hw3" else ("b", "w")
    expression = (f"{symbol} = {factors[first]} × {factors[second]} × "
                  f"{factors['unit_weight']} × {factors['Kh']}"
                  f" = {_number(formula['value'])} kN/m")
    _text(p, 119, y, name, width=67)
    _text(p, 194, y, expression, width=355)


def _inertia(p: _Page, result: dict) -> None:
    _heading(p, 369, "(8) 自重による地震時慣性力")
    _text(p, 106, 397, f"設計水平震度  Kh  =  {_number(result['inertia']['Kh'])}")
    formulas = result["formulas"]
    y = 425.0
    pedestal = formulas["pedestal"]
    if pedestal["value"] or pedestal["moment"]:
        _text(p, 106, y, "・桁受けに作用する水平力")
        factors = pedestal["factors"]
        force_factors = _formula_factors(
            {key: (factors[key], 2) for key in ("weight", "Kh")}, pedestal["value"],
            lambda values: values["weight"] * values["Kh"],
        )
        moment_factors = _formula_factors(
            {"H": (pedestal["value"], 2), "height": (factors["height"], 3)}, pedestal["moment"],
            lambda values: values["H"] * values["height"],
        )
        _text(p, 119, y + 20,
              f"H = {force_factors['weight']} × {force_factors['Kh']}"
              f" = {_number(pedestal['value'])} kN", width=430)
        _text(p, 119, y + 40,
              f"M = {moment_factors['H']} × {moment_factors['height']}"
              f" = {_number(pedestal['moment'])} kN・m", width=430)
        y += 66
    _text(p, 106, y, "・橋脚く体に作用する水平力")
    distinct_bottom = formulas["beam_bottom"]["value"] != formulas["column"]["value"]
    _line_inertia(p, y + 21, "はり上" if distinct_bottom else "はり", "Hw1", formulas["beam_top"])
    y += 42
    if distinct_bottom:
        _line_inertia(p, y, "はり下", "Hw2", formulas["beam_bottom"])
        y += 21
    _line_inertia(p, y, "柱", "Hw3", formulas["column"])
    y += 40
    _text(p, 106, y, "・フーチング重心に作用する水平力")
    footing = formulas["footing"]
    factors, geometry = footing["factors"], footing["geometry"]
    rectangle_volume = geometry["b"] * geometry["w"] * geometry["h6"]
    # Show physical dimensions for the rectangular source case. A tapered or
    # rounded weight uses the actual adopted volume, never a guessed cuboid.
    rectangular = geometry["h5"] == 0 and math.isclose(
        rectangle_volume, factors["weight"] / factors["unit_weight"], rel_tol=0, abs_tol=1e-5)
    factor_inputs = {key: (factors[key], 2 if key == "Kh" else 1)
                     for key in ("unit_weight", "displaced_unit_weight", "Kh")}
    if rectangular:
        try:
            displayed = _formula_factors(
                {**factor_inputs, **{key: (geometry[key], 2) for key in ("b", "w", "h6")}},
                footing["value"], lambda values: values["b"] * values["w"] * values["h6"]
                * (values["unit_weight"] - values["displaced_unit_weight"]) * values["Kh"],
            )
        except ValueError:
            # At a rounding boundary even a tiny transferred-weight difference
            # can matter; print the actual adopted volume in that case.
            rectangular = False
    if rectangular:
        first = f"H = {displayed['b']} × {displayed['w']}"
        second = f"× {displayed['h6']}"
    else:
        displayed = _formula_factors(
            {**factor_inputs, "weight": (factors["weight"], 2)}, footing["value"],
            lambda values: values["weight"] / values["unit_weight"]
            * (values["unit_weight"] - values["displaced_unit_weight"]) * values["Kh"],
        )
        first = f"H = {displayed['weight']} / {displayed['unit_weight']}"
        second = ""
    second += (f" × ( {displayed['unit_weight']} - {displayed['displaced_unit_weight']} )"
               f" × {displayed['Kh']} = {_number(footing['value'])} kN")
    _text(p, 131, y + 22, first, width=418)
    _text(p, 205, y + 38, second.strip(), width=344)


def _combinations(p: _Page, result: dict) -> None:
    _heading(p, 95, "11.3 作用の組合せ", x=82)
    cases, combination = result["basic_cases"], result["combinations"][0]
    xs = (93, 142, 189, 239, 287, 554)
    top, header, row_height = 130, 159, 14.4
    bottom = header + len(cases) * row_height
    _text(p, 273, 127, "基本Case", align="center")
    for yy in (top, header, bottom):
        p.line(xs[0], yy, xs[-1], yy, .8)
    for xx in xs[1:-1]:
        p.line(xx, top, xx, bottom, .8)
    for index, label in enumerate(("Case", "記号", "作用方向", "荷重種別", "荷　重　名　称")):
        _text(p, (xs[index] + xs[index + 1]) / 2, 142, label, align="center", width=xs[index + 1] - xs[index] - 4)
    for row, case in enumerate(cases):
        y = header + row_height * row
        if row:
            p.line(xs[0], y, xs[-1], y)
        texts = (case["id"], case["symbol"], _DIRECTIONS[case["direction"]], _LOAD_TYPES[case["load_type"]])
        for index, value in enumerate(texts):
            _text(p, (xs[index] + xs[index + 1]) / 2, y + 11.5, value,
                  align="center", width=xs[index + 1] - xs[index] - 4)
        label = case["label"]
        if case["symbol"] in ("EQ1", "EQL", "EQ2"):
            kh = (result["seismic_conditions"]["girder_Kh"] if case["symbol"] == "EQ1" else
                  result["seismic_conditions"]["train_Kh"] if case["symbol"] == "EQL" else result["inertia"]["Kh"])
            label += f"（Kh={_number(kh)}）"
        _text(p, xs[4] + 3, y + 11.5, label, width=xs[5] - xs[4] - 6)

    top = bottom + 43
    _text(p, 261, top - 4, "組合せCase", align="center")
    columns = (93, 118, 154, 190, 511, 554)
    for xx in columns[1:-1]:
        p.line(xx, top, xx, top + 58, .8)
    for yy in (top, top + 29, top + 58):
        p.line(columns[0], yy, columns[-1], yy, .8)
    for x, label in ((105, "Case"), (350, "荷重補正係数＋基本Case")):
        _text(p, x, top + 18, label, align="center")
    for x, first, second in ((136, "αf", "ρm"), (172, "作用", "方向"), (532, "地盤抵抗", "TYPE")):
        _text(p, x, top + 12, first, align="center", size=8.5 if x == 532 else 9.9)
        _text(p, x, top + 26, second, align="center")
    _text(p, 105, top + 47, combination["id"], align="center")
    _text(p, 136, top + 40, _number(combination["alpha_f"], 1), align="center")
    _text(p, 136, top + 55, _number(combination["rho_m"], 1), align="center")
    _text(p, 172, top + 47, _DIRECTIONS[combination["direction"]], align="center")
    expression = " + ".join(str(case["id"]) if coefficient == 1 else f"{coefficient:g}×{case['id']}"
                            for case, coefficient in zip(cases, combination["coefficients"], strict=True)
                            if coefficient != 0)
    _text(p, 350, top + 47, expression, align="center", width=313)
    _text(p, 532, top + 47, combination["ground_resistance_type"], align="center")


def render_seismic_transverse_report(result: dict, output_path: str | Path) -> None:
    """Render four A4 pages from a detached result, atomically replacing the PDF.

    No input, prior output, or reference document is reopened. All text retains
    at least 8.5 pt (the established graph member IDs use 8 pt); a larger result
    that cannot fit this four-page scope fails before any target is replaced.
    """
    if (result.get("schema_version") != 1 or result.get("stage") != "0720"
            or result.get("direction") != "transverse"):
        raise ValueError("0720帳票: schema_version=1、stage=0720、direction=transverseの計算結果が必要です")
    if len(result["basic_cases"]) != 9 or len(result["combinations"]) != 1:
        raise ValueError("0720帳票: 基本9ケース・組合せ1ケースが必要です")
    if len(result["combinations"][0]["coefficients"]) != 9:
        raise ValueError("0720帳票: 組合せ係数は9個必要です")
    buffer = BytesIO()
    canvas = Canvas(buffer, pagesize=_PAGE_SIZE, pageCompression=1, invariant=1)
    canvas.setTitle("0720 線路直角方向荷重（地震時）")
    canvas.setAuthor("P7橋脚 計算プログラム")
    canvas.setSubject("検討モデル・作用の計算・作用の組合せ")
    page = _Page(canvas, _fonts())
    for number, draw in enumerate((_model, _actions_one, _actions_two, _combinations), 1):
        _text(page, 554, 52, f"11 - {number}", align="right", size=10.5)
        draw(page, result)
        canvas.showPage()
    canvas.save()
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    pending = None
    try:
        with NamedTemporaryFile(mode="wb", dir=path.parent, prefix=f".{path.stem}-", suffix=".tmp", delete=False) as stream:
            pending = Path(stream.name)
            stream.write(buffer.getvalue())
        os.replace(pending, path)
    finally:
        if pending is not None and pending.exists():
            pending.unlink()


