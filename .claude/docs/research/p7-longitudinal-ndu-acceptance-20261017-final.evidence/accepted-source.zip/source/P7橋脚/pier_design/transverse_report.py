"""Render the 0620 calculation sheets using current values and reference typography."""
from .transverse_report_example2 import render_transverse_report

__all__ = ["render_transverse_report"]
