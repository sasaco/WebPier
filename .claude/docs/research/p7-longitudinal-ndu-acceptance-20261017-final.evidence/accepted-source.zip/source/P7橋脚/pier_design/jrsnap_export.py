"""Pure current-input/0500/0710 to JRSNAP longitudinal model conversion."""

from __future__ import annotations

import math
import re
from collections.abc import Mapping
from copy import deepcopy
from dataclasses import asdict

from . import column_rebar, rebar_model
from .editor_model import EditorError
from .inputs import InputError
from .jrsnap_design_conditions import (
    GEOMETRY_TOLERANCE,
    PROFILE_ID,
    SCHEMA_VERSION,
    TARGET_VERSION,
    at,
    canonical_sha256,
    derive_jrsnap_soil_conditions,
    get_profile,
    number,
)
from .reaction_inputs import parse_reaction_input

_ROLES = ("cap_top", "footing_top", "footing_centroid", "footing_bottom", "column_base_micro_top")
_CASES = (("D1", 0), ("D2", 0), ("Wp", 0), ("Sw2", 0), ("L", 0),
          ("EQ1", 1), ("EQL", 4), ("EQ2", 1))


def _id(value, label: str) -> int:
    if type(value) is not int or value < 1:
        raise InputError(f"JRSNAP: {label}には正の整数IDが必要です")
    return value


def _same_generation(raw: dict, foundation: Mapping, seismic: Mapping, sha: str) -> None:
    if not isinstance(sha, str) or re.fullmatch(r"[0-9a-f]{64}", sha) is None:
        raise InputError("JRSNAP: input_sha256にはraw全バイトの小文字SHA256が必要です")
    for label, source in (("0500", foundation), ("0710", seismic)):
        if at(source, "provenance.input_sha256") != sha:
            raise InputError(f"JRSNAP: {label}.provenance.input_sha256の入力世代が一致しません")
        canonical_sha256(source)  # Reject non-finite values anywhere in the snapshot.
    if seismic.get("stage") != "0710" or seismic.get("schema_version") != 1 or seismic.get("direction") != "longitudinal":
        raise InputError("JRSNAP: 0710線路方向schema_version=1の結果が必要です")
    if foundation.get("schema_version") != 1:
        raise InputError("JRSNAP: 0500.schema_version=1が必要です")
    raw_geometry = asdict(parse_reaction_input(raw).geometry)
    if raw_geometry != at(seismic, "input.geometry"):
        raise InputError("JRSNAP: rawと0710.input.geometryの入力世代が一致しません")


def _frame(seismic: Mapping) -> tuple[list, list, dict, dict]:
    frame = at(seismic, "frame")
    source_nodes, source_members = at(frame, "nodes"), at(frame, "members")
    if not isinstance(source_nodes, list) or not isinstance(source_members, list):
        raise InputError("JRSNAP: frame.nodes/membersには配列が必要です")
    if not 1 <= len(source_nodes) <= 2500 or not 1 <= len(source_members) <= 400:
        raise InputError("JRSNAP: 節点2500/部材400の上限または空モデルです")
    indexed = {}
    for node in source_nodes:
        identifier = _id(at(node, "id"), "node.id")
        if identifier in indexed:
            raise InputError("JRSNAP: 節点IDが重複しています")
        indexed[identifier] = node
    if set(indexed) != set(range(1, len(indexed) + 1)):
        raise InputError("JRSNAP: 0710節点IDは1始まりの連番が必要です")
    roles = dict(at(frame, "node_ids"))
    for role in _ROLES:
        identifier = roles.get(role)
        matching = [node for node in source_nodes if role in node.get("roles", [])]
        if len(matching) != 1 or matching[0]["id"] != identifier or identifier not in indexed:
            raise InputError(f"JRSNAP: 役割{role}は一致する節点が1件だけ必要です")
    for role, identifier in roles.items():
        if identifier not in indexed or role not in indexed[identifier].get("roles", []):
            raise InputError(f"JRSNAP: 役割{role}の参照が不正です")
    origin = number(indexed[roles["footing_top"]]["y"], "footing_top.y")
    nodes = [{"id": node["id"], "x": number(node["x"], "node.x", minimum=-20000, maximum=20000),
              "y": number(origin - number(node["y"], "node.y"), "NDU node.y", minimum=-20000, maximum=20000),
              "roles": list(node["roles"])} for node in source_nodes]
    coordinates = {(node["x"], node["y"]) for node in nodes}
    if len(coordinates) != len(nodes):
        raise InputError("JRSNAP: 同一位置の重複節点は未対応です")
    by_id = {node["id"]: node for node in nodes}
    members, adjacency, seen_edges, correspondence = [], {key: set() for key in indexed}, set(), []
    allowed = {"h1", "h2", "h3", "h4", "parapet_arm", "column_base_micro_member",
               "footing_top_to_centroid", "footing_centroid_to_bottom"}
    for source in source_members:
        identifier = _id(at(source, "id"), "member.id")
        first, second = _id(at(source, "node_i"), "member.node_i"), _id(at(source, "node_j"), "member.node_j")
        if first not in by_id or second not in by_id or first == second:
            raise InputError("JRSNAP: 部材の節点参照が不正です")
        a, b = by_id[first], by_id[second]
        dx, dy = b["x"] - a["x"], b["y"] - a["y"]
        if dx != 0 and dy != 0:
            raise InputError("JRSNAP: v1は鉛直・水平部材だけに対応します")
        length = number(math.hypot(dx, dy), "member.length")
        if length <= GEOMETRY_TOLERANCE:
            raise InputError("JRSNAP: 1e-9 m以下の部材は未対応です")
        edge = frozenset((first, second))
        if edge in seen_edges:
            raise InputError("JRSNAP: 部材接続が重複しています")
        seen_edges.add(edge)
        adjacency[first].add(second)
        adjacency[second].add(first)
        swapped = dy < 0 or (dy == 0 and dx < 0)
        if swapped:
            first, second = second, first
        region = source.get("region")
        if region not in allowed:
            raise InputError(f"JRSNAP: 未対応部材領域です: {region}")
        members.append({"id": identifier, "node_i": first, "node_j": second,
                        "region": region, "length": length,
                        "kind": 2 if region == "column_base_micro_member" else 1})
        correspondence.append({"source_id": identifier, "native_id": identifier, "ends_reversed": swapped})
    if {member["id"] for member in members} != set(range(1, len(members) + 1)):
        raise InputError("JRSNAP: 要素IDは重複のない1始まり連番が必要です")
    reached, pending = set(), [roles["footing_bottom"]]
    while pending:
        identifier = pending.pop()
        if identifier not in reached:
            reached.add(identifier)
            pending.extend(adjacency[identifier] - reached)
    if reached != set(indexed):
        raise InputError("JRSNAP: 基礎底面に接続していない節点があります")
    micro = [member for member in members if member["region"] == "column_base_micro_member"]
    if (len(micro) != 1 or micro[0]["id"] != at(frame, "column_base_micro_member.member_id") or
            micro[0]["node_i"] != roles["column_base_micro_top"] or micro[0]["node_j"] != roles["footing_top"] or
            not math.isclose(micro[0]["length"], .01, rel_tol=0, abs_tol=1e-12)):
        raise InputError("JRSNAP: 0.010 m微小部材の役割・接続が一致しません")
    if number(at(seismic, "input.geometry.h4"), "H4") <= .01 + GEOMETRY_TOLERANCE:
        raise InputError("JRSNAP: H4は0.010 m + 1e-9 mより大きい値が必要です")
    for region in ("h4", "column_base_micro_member"):
        if sum(member["region"] == region for member in members) != 1:
            raise InputError(f"JRSNAP: {region}は1本だけ必要です")
    return nodes, members, roles, {"nodes": [{"source_id": key, "native_id": key} for key in indexed],
                                   "members": correspondence}


def _steel(value, label: str) -> float:
    if not isinstance(value, str) or re.fullmatch(r"SD(?:295|345|390)", value) is None:
        raise InputError(f"JRSNAP: {label}はSD295/SD345/SD390だけに対応します")
    return float(value[2:])


def _section(raw: dict, seismic: Mapping, nodes: list, roles: dict, profile: dict) -> dict:
    try:
        member = rebar_model.load_member(raw, "柱")
        geometry = rebar_model.section_geometry(raw, "柱")
        layout = rebar_model.column_layout(member, geometry)
        if not layout["complete"] or not layout["bars"]:
            raise InputError("JRSNAP: 柱配筋が未完成です: " + ";".join(row["message"] for row in layout["issues"]))
        if member.get("position_mode") == "指定" and rebar_model.column_detail_status(member, geometry) != "一致":
            raise InputError("JRSNAP: 柱の詳細配筋の生成元が未設定または基本条件変更です")
        bars, _, _, warnings = rebar_model.member_preview("柱", member, geometry)
        if warnings:
            raise InputError("JRSNAP: 柱配筋の警告を解消してください: " + ";".join(warnings))
        # A manually changed arrangement needs an explicit bar-layer/pitch model.
        if member.get("position_mode") == "指定":
            fields = ("x_mm", "y_mm", "diameter_mm", "material")
            if sorted(tuple(bar[key] for key in fields) for bar in bars) != sorted(
                    tuple(bar[key] for key in fields) for bar in layout["bars"]):
                raise InputError("JRSNAP: 手動変更した詳細配筋の主筋段数・間隔はv1未対応です")
        rows = rebar_model.directional_rows(bars, "線路")
        material_set = {bar["material"] for bar in bars}
        if len(material_set) != 1:
            raise InputError("JRSNAP: 主筋の複数鋼種混在は未対応です")
        steel = _steel(next(iter(material_set)), "主筋材質")
        face_indices = {index for index, row in enumerate(member["main_rows"])
                        if row.get("face_direction") == "線路" and row.get("per_face_count", 0) > 0}
        face_rows = [member["main_rows"][index] for index in sorted(face_indices)]
        if not face_rows:
            raise InputError("JRSNAP: 線路方向の主筋段が必要です")
        # Native DRTU/DRTL select the first/last N aggregated rows, without face IDs.
        # A shared corner remains one physical bar in this intended main-bar subset.
        main_bars = [bar for bar in layout["bars"] if face_indices.intersection(bar["row_indices"])]
        main_rows = rebar_model.directional_rows(main_bars, "線路")
        layers = len(face_rows)
        if (len(main_rows) != 2 * layers or rows[:layers] != main_rows[:layers] or
                rows[-layers:] != main_rows[-layers:]):
            raise InputError("JRSNAP: 先頭・末尾の主筋段数分の配筋行と線路主筋が一致しません"
                             "（側面筋の割込み・混入はv1未対応です）")
        pitches = []
        for row in face_rows:
            distribution = row.get("distribution", {})
            pitch = distribution.get("pitch_mm")
            if distribution.get("mode") == "等分":
                positions = column_rebar.face_positions(row, geometry["width_mm"])
                pitch = positions[1] - positions[0] if len(positions) > 1 else None
            pitches.append(number(pitch, "柱.main_rows.線路.distribution.pitch_mm", minimum=.001, maximum=99999))
        if len(set(pitches)) != 1:
            raise InputError("JRSNAP: 主筋段ごとに異なる間隔の代表値はv1未対応です")
        hoops = [row for row in column_rebar.hoop_rows(member) if row.get("direction") == "線路"]
        if len(hoops) != 1 or any(hoops[0].get(key) is not None for key in ("start_mm", "end_mm")):
            raise InputError("JRSNAP: 線路方向の帯筋は区間指定のない均一1設定が必要です")
        hoop = hoops[0]
        hoop_steel = _steel(hoop.get("material") or member.get("materials", {}).get("transverse"), "帯筋材質")
        legs = _id(hoop.get("effective_legs"), "帯筋有効脚数")
        diameter = number(hoop.get("diameter_mm"), "帯筋径", minimum=.001, maximum=99999)
        pitch = number(hoop.get("pitch_mm"), "帯筋配置間隔", minimum=.001, maximum=99999)
    except EditorError as exc:
        raise InputError(f"JRSNAP: {exc}") from exc
    fck = number(member.get("concrete_strength_mpa"), "柱fck", minimum=18, maximum=80)
    materials = at(seismic, "frame.materials.column")
    if fck != at(materials, "fck"):
        raise InputError("JRSNAP: raw柱fckと0710の材料が一致しません")
    width = number(geometry["width_mm"], "断面幅", minimum=.1, maximum=999999)
    height = number(geometry["height_mm"], "断面高さ", minimum=.1, maximum=999999)
    if (width != at(seismic, "input.geometry.w6") * 1000 or
            height != at(seismic, "input.geometry.b6") * 1000):
        raise InputError("JRSNAP: raw断面寸法と0710が一致しません")
    indexed = {node["id"]: node for node in nodes}
    span = (indexed[roles["footing_top"]]["y"] - indexed[roles["cap_top"]]["y"]) * 1000
    number(span, "La", minimum=.001, maximum=999999)
    if span / (height - rows[0]["center_mm"]) < 2:
        raise InputError("JRSNAP: La/d<2の低せん断スパンは曲げ型profileの対応範囲外です")
    if not 1 <= len(rows) <= 100:
        raise InputError("JRSNAP: 主筋行数は1～100行が必要です")
    return {"width_mm": width, "height_mm": height, "shear_span_mm": span,
            "fck": fck, "Ec": number(at(materials, "Ec") / 1e6, "Ec", minimum=.001, maximum=999999),
            "fyk": steel, "Es": profile["section"]["Es_kn_mm2"],
            "main_face_layers": len(face_rows), "main_face_pitch_mm": pitches[0],
            "rebar": rows, "hoop": {"fyk": hoop_steel, "diameter_mm": diameter,
                                       "legs": legs, "pitch_mm": pitch}}


def _cases(seismic: Mapping, elements: list, roles: dict) -> list:
    basics = at(seismic, "basic_cases")
    if not isinstance(basics, list) or len(basics) != 8:
        raise InputError("JRSNAP: 0710の8基本ケースが必要です")
    cases = []
    for index, ((symbol, increment), source) in enumerate(zip(_CASES, basics), 1):
        mode = {0: "fixed", 1: "incremental", 4: "limited_incremental"}[increment]
        if source.get("id") != index or source.get("symbol") != symbol or source.get("load_type") != mode or source.get("coefficient") != 1:
            raise InputError(f"JRSNAP: 基本ケース{symbol}の番号・増分方式・係数が一致しません")
        cases.append({"id": index, "symbol": symbol, "label": source["label"],
                      "increment": increment, "member_loads": [], "joint_loads": []})

    def point(case: int, role: str, *, h=0, n=0, m=0, label: str) -> None:
        values = {key: number(value, f"case{case}.{label}.{key}", minimum=-9999999999, maximum=9999999999)
                  for key, value in (("H", h), ("N", n), ("M", m))}
        cases[case - 1]["joint_loads"].append({"node": roles[role], **values, "label": label})

    def vertical(case: int, role: str, path: str, label: str) -> None:
        values = at(seismic, path)
        point(case, role, n=at(values, "N"), m=at(values, "M"), label=label)

    vertical(1, "cap_top", "vertical.fixed.top", "上部工反力")
    vertical(1, "footing_centroid", "vertical.fixed.footing", "フーチング自重")
    vertical(2, "cap_top", "vertical.additional.top", "上部工反力")
    vertical(2, "footing_top", "vertical.additional.soil", "上載土")
    vertical(3, "footing_centroid", "vertical.water.normal", "浮力")
    vertical(4, "cap_top", "vertical.snow.s2", "雪荷重")
    vertical(5, "cap_top", "vertical.train.earthquake", "列車荷重")
    for case, name in ((6, "girder"), (7, "train")):
        if at(seismic, f"horizontal.{name}.coefficient_applied") is not True:
            raise InputError("JRSNAP: 水平慣性力のKh適用済み情報が必要です")
        point(case, "cap_top", h=-number(at(seismic, f"horizontal.{name}.total"), name), label="慣性力")
    point(8, "footing_centroid", h=-number(at(seismic, "inertia.footing"), "inertia.footing"), label="フーチング慣性力")
    pedestal_h = number(at(seismic, "inertia.pedestal.H"), "inertia.pedestal.H")
    pedestal_m = number(at(seismic, "inertia.pedestal.M"), "inertia.pedestal.M")
    if pedestal_h or pedestal_m:
        point(8, "cap_top", h=-pedestal_h, m=-pedestal_m, label="H1慣性力")
    column_q = number(at(seismic, "vertical.fixed.column.intensity"), "D1.column.intensity", minimum=0, maximum=9999999999)
    for element in elements:
        region = element["region"]
        if region not in ("h2", "h3", "h4", "column_base_micro_member"):
            continue
        cases[0]["member_loads"].append({"element": element["id"], "kind": 4,
                                           "q_i": column_q, "q_j": None, "label": "柱自重"})
        first, second = {"h2": ("beam_top", "beam_top"), "h3": ("beam_top", "beam_bottom"),
                         "h4": ("column", "column"), "column_base_micro_member": ("column", "column")}[region]
        cases[7]["member_loads"].append({"element": element["id"], "kind": 1,
                                           "q_i": number(at(seismic, f"inertia.{first}"), first, minimum=0, maximum=9999999999),
                                           "q_j": number(at(seismic, f"inertia.{second}"), second, minimum=0, maximum=9999999999),
                                           "label": "自重慣性力"})
    return cases


def build_longitudinal_ndu_model(raw: dict, foundation: Mapping, seismic: Mapping,
                                 input_sha256: str) -> dict:
    """Return a detached model; never read files or mutate caller snapshots."""
    _same_generation(raw, foundation, seismic, input_sha256)
    soil = derive_jrsnap_soil_conditions(raw, foundation, seismic)
    profile = get_profile(raw)
    nodes, members, roles, correspondence = _frame(seismic)
    section = _section(raw, seismic, nodes, roles, profile)
    combinations = at(seismic, "combinations")
    expected = {"id": 1, "alpha_f": 1.0, "rho_m": 1.0, "direction": "left",
                "ground_resistance_type": 1, "coefficients": [1.0] * 8}
    if combinations != [expected]:
        raise InputError("JRSNAP: v1は0710の左方向・全8係数1の組合せ1件に対応します")
    micro = next(member for member in members if member["kind"] == 2)
    return {
        "metadata": {"profile_id": PROFILE_ID, "schema_version": SCHEMA_VERSION,
                     "target_version": TARGET_VERSION, "input_sha256": input_sha256,
                     "canonical_snapshot_sha256": {"foundation": canonical_sha256(foundation),
                                                    "seismic": canonical_sha256(seismic)},
                     "settings": profile, "soil_provenance": soil["provenance"],
                     "setting_sources": {"section.safety.GBC": "raw.jrsnap_longitudinal.shear_factor_vcd",
                                         "section.safety.GBV": "raw.jrsnap_longitudinal.shear_factor_vsd",
                                         "section.safety.GBVD": "raw.jrsnap_longitudinal.shear_factor_vdd",
                                         "section.aggregate_max_mm": "raw.jrsnap_longitudinal.aggregate_max_mm"},
                     "correspondence": correspondence, "roles": roles},
        "nodes": nodes, "members": members, "elements": deepcopy(members), "section": section,
        "nonlinear": {"id": 1, "section": 1, "element": micro["id"]},
        "supports": [{"node": roles["footing_bottom"], "direction": 1, "stiffness": soil["Ks"]},
                     {"node": roles["footing_bottom"], "direction": 2, "stiffness": soil["Kv"]}],
        "footing": {"node": roles["footing_bottom"], **{key: value for key, value in soil.items() if key != "provenance"}},
        "cases": _cases(seismic, members, roles), "combination": deepcopy(expected),
    }
