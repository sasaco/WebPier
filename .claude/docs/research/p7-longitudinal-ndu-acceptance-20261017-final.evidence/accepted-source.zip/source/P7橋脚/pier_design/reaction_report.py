"""Render 0600 with reference typography and calculation-aware page breaks.

The bundled layout describes cells and rules, not a background PDF. All varying
values and drawings come from the current calculation; Excel is not required.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any
from xml.sax.saxutils import escape

from reportlab.pdfgen.canvas import Canvas
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import PageBreak, Paragraph, Spacer, Table, TableStyle

from .report import _Page, _fonts
from .reaction_report_horizontal import draw_longitudinal_report, draw_transverse_earthquake_report
from .reaction_report_layout import missing_dynamic_cells
from .reaction_report_pagination import BLOCK_GAP, PAGE_BOTTOM, PAGE_TOP, draw_report_page, report_pages
from .reaction_report_snow import draw_snow_page, snow_page_height
from .reaction_report_values import build_display_values


def _moving_formulas(moving: dict) -> dict[str, str]:
    """Rebuild the VBA-written arithmetic strings from the selected axle terms."""
    formulas: dict[str, str] = {}
    for side, inner_index, outer in (("B", 1, "A"), ("C", 2, "D")):
        terms = [term for term in moving["contributions"] if term["side"] == side]
        if not terms:
            formulas[side] = formulas[outer] = "0"
            continue
        axle, span = terms[0]["axle_load"], terms[0]["span"]
        distances = "＋".join(f'{term["distance"]:.3f}' for term in terms)
        formulas[side] = f"{axle:.2f}×({distances})/{span:.3f}"
        formulas[outer] = f'{axle:.2f}×{len(terms)}-{moving["reactions"][inner_index]:.2f}'
    return formulas


def _text_overrides(result: dict) -> dict[str, dict[str, str]]:
    train = _moving_formulas(result["moving_train"])
    lateral = _moving_formulas(result["moving_lateral"])
    return {
        "列車荷重": {"J34": train["A"], "J36": train["B"],
                     "J38": train["C"], "J40": train["D"]},
        "直角荷重": {"K87": lateral["B"], "K94": lateral["C"]},
        # The source's fixed caption says 0.1, but its actual formula uses the
        # entered friction coefficient. Keep the caption consistent with the
        # substitution and calculated value printed beside it.
        "線路荷重": {f"J{row}": "μ ・ T / n" for row in
                     (99, 118, 147, 169, 199, 224, 252, 277,
                      310, 335, 364, 389, 416, 439, 469, 494)},
    }


def render_reaction_report(result: dict, output_path: str | Path) -> None:
    """Keep tables, figures, and complete support calculations on one page."""
    overrides = build_display_values(result)
    for sheet, values in _text_overrides(result).items():
        overrides.setdefault(sheet, {}).update(values)
    missing = missing_dynamic_cells(result, overrides)
    if missing:
        names = ", ".join(f"{sheet}!{address}" for sheet, address in missing)
        raise ValueError(f"0600帳票の計算値が不足しています: {names}")
    fonts = _fonts()
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    canvas = Canvas(str(path), pagesize=(595, 842), pageCompression=1, invariant=1)
    canvas.setTitle("0600 上部工反力及び橋脚自重")
    canvas.setAuthor("P7橋脚 計算プログラム")
    page = _Page(canvas, fonts)
    page_number = 0

    def finish_page() -> None:
        nonlocal page_number
        page_number += 1
        page.text(545, 36, f"6 - {page_number}", align="right", size=9.9)
        canvas.showPage()

    pages = report_pages(omit_pedestal=result["weights"]["cells"]["X63"] == 0)
    pending_pages = pages[:13]
    b_height, c_height = (snow_page_height(result, number) for number in (1, 2))
    if b_height + c_height + BLOCK_GAP <= PAGE_BOTTOM - PAGE_TOP:
        # Empty trailing girder tables leave usable space. Move the complete C
        # block into it at the original scale, without a continuation heading.
        draw_snow_page(canvas, result, 1, fonts, overrides, top=PAGE_TOP)
        draw_snow_page(canvas, result, 2, fonts, overrides,
                       top=PAGE_TOP + b_height + BLOCK_GAP)
        finish_page()
        pending_pages = pending_pages[2:]
    for sections in pending_pages:
        draw_report_page(canvas, result, sections, fonts, overrides)
        finish_page()
    draw_longitudinal_report(page, result, finish_page)
    for sections in pages[30:33]:
        draw_report_page(canvas, result, sections, fonts, overrides)
        finish_page()
    draw_transverse_earthquake_report(page, result, finish_page)
    canvas.save()


# Shared flowable primitives used by the existing 0610 and 0620 reports.
WIDTH = A4[0] - 80


class _Report:
    def __init__(self, fonts: tuple[str, str]) -> None:
        self.fonts = fonts
        self.story: list[Any] = []
        self.body = ParagraphStyle("body", fontName=fonts[0], fontSize=9.4, leading=14,
                                   wordWrap="CJK", spaceAfter=6)
        self.small = ParagraphStyle("small", parent=self.body, fontSize=8.7, leading=12, spaceAfter=0)
        self.heading = ParagraphStyle("heading", fontName=fonts[1], fontSize=12.5, leading=18,
                                      spaceBefore=7, spaceAfter=10, keepWithNext=True, wordWrap="CJK")
        self.subheading = ParagraphStyle("subheading", parent=self.heading, fontSize=10.5, leading=15, spaceAfter=7)

    def p(self, text: str, style: ParagraphStyle | None = None) -> Paragraph:
        return Paragraph(escape(str(text)).replace("\n", "<br/>"), style or self.body)

    def text(self, text: str) -> None:
        self.story.append(self.p(text))

    def title(self, text: str, *, sub: bool = False) -> None:
        self.story.append(self.p(text, self.subheading if sub else self.heading))

    def page(self, title: str) -> None:
        if self.story:
            self.story.append(PageBreak())
        self.title(title)

    def table(self, headers: list[str], rows: list[list[Any]], widths: list[float] | None = None) -> None:
        count = len(headers)
        widths = widths or [WIDTH / count] * count
        content = [[self.p(item, self.small) for item in headers]]
        content += [[self.p(str(item), self.small) for item in row] for row in rows]
        table = Table(content, colWidths=widths, repeatRows=1, hAlign="LEFT")
        table.setStyle(TableStyle([
            ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ("FONTNAME", (0, 0), (-1, 0), self.fonts[1]),
            ("LINEABOVE", (0, 0), (-1, 0), 0.65, colors.black),
            ("LINEBELOW", (0, 0), (-1, 0), 0.45, colors.black),
            ("LINEBELOW", (0, -1), (-1, -1), 0.65, colors.black),
            ("INNERGRID", (0, 0), (-1, -1), 0.25, colors.black),
            ("BOX", (0, 0), (-1, -1), 0.4, colors.black),
            ("LEFTPADDING", (0, 0), (-1, -1), 4),
            ("RIGHTPADDING", (0, 0), (-1, -1), 4),
            ("TOPPADDING", (0, 0), (-1, -1), 4),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
        ]))
        self.story.extend((table, Spacer(1, 10)))
