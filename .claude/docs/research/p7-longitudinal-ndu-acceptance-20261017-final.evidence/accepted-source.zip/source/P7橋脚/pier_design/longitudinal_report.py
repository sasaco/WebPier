"""Public entry point for the reference-style 0610 calculation report."""

from .longitudinal_example2_report import render_longitudinal_report
