"""Input-driven vector figures for the original 0600 calculation-sheet layout.

Coordinates are points from the top of an A4 page.  Member figures are
dimensioned schematics, as in the calculation sheets; the overall elevation
uses a common horizontal/vertical scale.  No reference PDF or workbook is read.
"""

from __future__ import annotations

import math

from reportlab.pdfbase import pdfmetrics


def _n(value: float) -> str:
    return f"{0.0 if abs(value) < 0.0005 else value:.3f}"


class _Drawing:
    def __init__(self, canvas, font: str):
        self.c, self.font = canvas, font
        self.height = canvas._pagesize[1]

    def line(self, x1, y1, x2, y2, *, thin=False, dashed=False):
        c = self.c
        c.setLineWidth(0.28 if thin else 0.6)
        c.setStrokeGray(0.45 if thin else 0)
        c.setDash([3, 2] if dashed else [])
        c.line(x1, self.height-y1, x2, self.height-y2)
        c.setDash([])

    def text(self, x, y, text, size=8, *, anchor="middle", rotate=False, white=False):
        c = self.c
        c.saveState()
        c.setFillGray(0)
        c.setFont(self.font, size)
        c.translate(x, self.height-y)
        if rotate:
            c.rotate(90)
        if white:
            width=pdfmetrics.stringWidth(str(text),self.font,size)
            left={"middle":-width/2,"start":0,"end":-width}[anchor]
            ascent,descent=pdfmetrics.getAscentDescent(self.font,size)
            c.setFillGray(1)
            c.rect(left-1,descent-.5,width+2,ascent-descent+1,fill=1,stroke=0)
            c.setFillGray(0)
        method = {"middle": c.drawCentredString, "start": c.drawString,
                  "end": c.drawRightString}[anchor]
        method(0, 0, str(text))
        c.restoreState()

    def polygon(self, points, *, dashed=False):
        c = self.c
        c.setStrokeGray(0)
        c.setLineWidth(0.6)
        c.setDash([3, 2] if dashed else [])
        path = c.beginPath()
        path.moveTo(points[0][0], self.height-points[0][1])
        for x, y in points[1:]:
            path.lineTo(x, self.height-y)
        path.close()
        c.drawPath(path, fill=0, stroke=1)
        c.setDash([])

    def dot(self, x, y):
        self.c.setFillGray(0)
        self.c.circle(x, self.height-y, 2.5, stroke=0, fill=1)

    def arrow(self, x, y, dx, dy, size=4, *, thin=True):
        length = math.hypot(dx, dy)
        if length == 0:
            return
        dx, dy = dx/length, dy/length
        self.line(x, y, x+dx*size-dy*size*.45, y+dy*size+dx*size*.45, thin=thin)
        self.line(x, y, x+dx*size+dy*size*.45, y+dy*size-dx*size*.45, thin=thin)

    def horizontal(self, x1, x2, y, source_y, value, *, size=8, label_y=None):
        self.line(x1, source_y, x1, y+4, thin=True)
        self.line(x2, source_y, x2, y+4, thin=True)
        # Zero dimensions get separate extension lines, as a schematic detail.
        if abs(x2-x1) < 5:
            self.line(x1-8, y, x2+8, y, thin=True)
            self.arrow(x1, y, -1, 0)
            self.arrow(x2, y, 1, 0)
            self.text((x1+x2)/2+13, y-4 if label_y is None else label_y, value, size,
                      anchor="start",white=True)
        else:
            self.line(x1, y, x2, y, thin=True)
            self.arrow(x1, y, 1, 0)
            self.arrow(x2, y, -1, 0)
            self.text((x1+x2)/2, y-4 if label_y is None else label_y, value, size,white=True)

    def vertical(self, x, y1, y2, source_x, value, *, size=8, rotate=True):
        self.line(source_x, y1, x+3, y1, thin=True)
        self.line(source_x, y2, x+3, y2, thin=True)
        if abs(y2-y1) < 8:
            self.line(x, y1-7, x, y2+7, thin=True)
            self.arrow(x, y1, 0, -1)
            self.arrow(x, y2, 0, 1)
            if value is None:
                return
            if rotate:
                self.text(x-3,(y1+y2)/2-8,value,size,rotate=True,white=True)
            else:
                self.text(x+6,(y1+y2)/2-4,value,size,anchor="start",white=True)
        else:
            self.line(x, y1, x, y2, thin=True)
            self.arrow(x, y1, 0, 1)
            self.arrow(x, y2, 0, -1)
            if value is None:
                return
            self.text(x-3 if rotate else x+7, (y1+y2)/2+2, value, size, rotate=rotate,white=True)

    def ground(self, x1, y1, x2, y2):
        self.line(x1, y1, x2, y2)
        start = x1+(x2-x1)*.25
        slope = (y2-y1)/(x2-x1) if x2 != x1 else 0
        for i in range(10):
            x = start+i*2.8
            y = y1+(x-x1)*slope
            self.line(x, y, x-5, y+4, thin=False)


def _dimensions(g, prefix):
    return [float(g[f"{prefix}{i}"]) for i in range(1, 10)]


def _column_soil_depth(g):
    """Ground depth at the column centre, including footing eccentricity."""
    width=g["b7"]+g["b8"]+g["b9"]
    return (g["df1"]-g["df2"])/width*(g["b9"]+g["b8"]/2)+g["df2"]


def _overall(d, g, prefix, bottom):
    a, a2, a3, a4, a5, a6, a7, a8, a9 = _dimensions(g, prefix)
    heights = [float(g[f"h{i}"]) for i in range(1, 7)]
    total_h = sum(heights)
    width = a7+a8+a9
    scale = min(146/max(total_h, .01), 145/max(a, width, .01))
    center = (a7-a9)/2
    cap_center = center+(a5-a4)/2
    pedestal_center = center+(2*a2+a3-a-a4+a5)/2
    z = [0.0]
    for height in reversed(heights):
        z.append(z[-1]+height)
    def x(v): return 269+v*scale
    def y(v): return bottom-v*scale
    def poly(points): d.polygon([(x(xx), y(zz)) for xx, zz in points])
    lo = a-a4-a5
    poly([(-width/2,z[0]),(width/2,z[0]),(width/2,z[1]),(-width/2,z[1])])
    if heights[4]:
        poly([(-width/2,z[1]),(width/2,z[1]),(center+a8/2,z[2]),(center-a8/2,z[2])])
    poly([(center-a6/2,z[2]),(center+a6/2,z[2]),(center+a6/2,z[3]),(center-a6/2,z[3])])
    if heights[2]:
        poly([(center-lo/2,z[3]),(center+lo/2,z[3]),(cap_center+a/2,z[4]),(cap_center-a/2,z[4])])
    poly([(cap_center-a/2,z[4]),(cap_center+a/2,z[4]),(cap_center+a/2,z[5]),(cap_center-a/2,z[5])])
    if heights[0] and a3:
        poly([(pedestal_center-a3/2,z[5]),(pedestal_center+a3/2,z[5]),
              (pedestal_center+a3/2,z[6]),(pedestal_center-a3/2,z[6])])
    d.text(299, bottom-215, "側 面 図" if prefix == "b" else "正 面 図", 9.5)
    mm = lambda v: f"{v*1000:.0f}"
    top = y(z[6])
    d.horizontal(x(cap_center-a/2),x(cap_center+a/2),top-44,top-5,mm(a))
    d.horizontal(x(center-a6/2),x(center+a6/2),y(z[3]) + 26,y(z[3]),mm(a6))
    if prefix == "w":
        yy=y(z[3])+27
        d.horizontal(x(cap_center-a/2),x(center-lo/2),yy,y(z[4]),mm(a4),size=7.2)
        d.horizontal(x(center+lo/2),x(cap_center+a/2),yy,y(z[4]),mm(a5),size=7.2)
    gx1 = g["df1"]+z[2]
    gx2 = g["df2"]+z[2]
    if prefix == "w": gx1=gx2=_column_soil_depth(g)+z[2]
    # Keep extreme soil levels inside the fixed figure without changing labels.
    gy1=max(top-12,min(bottom+1,y(gx1)))
    gy2=max(top-12,min(bottom+1,y(gx2)))
    d.line(102,gy1,474,gy2)
    for i in range(11):
        xx=105+i*2.5
        d.line(xx,gy1,xx+2,gy1+4)
    d.vertical(160,gy1,y(z[2]),197,mm(g["df1"] if prefix=="b" else _column_soil_depth(g)),size=7,rotate=False)
    xs=[-width/2,center-a8/2,center+a8/2,width/2]
    for left,right,value in zip(xs,xs[1:],(a7,a8,a9)):
        d.horizontal(x(left),x(right),min(gy1,gy2),y(z[2]),mm(value),size=7)
    height_labels=[]
    for i in range(6):
        if heights[5-i] > 0:
            d.vertical(365,y(z[i+1]),y(z[i]),x(max(width/2,cap_center+a/2))+7,
                       None,size=7,rotate=False)
            height_labels.append(((y(z[i+1])+y(z[i]))/2,mm(heights[5-i])))
    # Thin haunches otherwise put two dimension labels on the same baseline.
    # Keep the actual arrows at their physical levels and fan out the labels.
    previous=-math.inf
    for midpoint,label in sorted(height_labels):
        baseline=max(midpoint+2,previous+11)
        d.line(367,midpoint,376,baseline-2,thin=True)
        d.text(379,baseline,label,7,anchor="start",white=True)
        previous=baseline


def _centroid(d, x, y, reference_x, floor, label):
    d.dot(x,y)
    d.line(x,y+4,x,floor-7,thin=True)
    d.line(reference_x,y+12,reference_x,floor+3,thin=True,dashed=True)
    if abs(x-reference_x)>5:
        d.horizontal(reference_x,x,floor,y+5,label,size=7.3)
    else:
        d.text(x-2,floor-2,label,7.3)


def _pedestal(d,g,components):
    for prefix,x0,width,key in (("b",129,116,"xL"),("w",260,204,"xC")):
        a,a2,a3,a4,a5,*_= _dimensions(g,prefix)
        s=width/max(a,.01)
        base=300
        axis=x0+width/2-(a5-a4)/2*s
        left=x0+a2*s
        right=left+a3*s
        top=base-min(38,max(0,g["h1"]*12))
        d.line(x0,base,x0+width,base)
        d.line(x0,base,x0,base+14)
        d.line(x0+width,base,x0+width,base+14)
        if a3>0 and g["h1"]>0:
            d.polygon([(left,base),(right,base),(right,top),(left,top)])
            doty=(top+base)/2
        else:
            # A zero-volume pedestal must not acquire a fictitious solid body.
            doty=base-14
            d.line(left,base,left,base-27,thin=True,dashed=True)
            d.text(left,base-31,"0.000",7)
        dotx=max(x0,min(x0+width,axis+components["桁受け"][key]*s))
        d.dot(dotx,doty)
        d.line(axis,base-14,axis,base+43,thin=True,dashed=True)
        d.horizontal(x0,x0+width,214,base-5,_n(a))
        d.horizontal(x0,left,228,base-5,_n(a2),size=7.7)
        d.horizontal(left,right,228,top-4,_n(a3),size=7.7)
        d.horizontal(right,x0+width,242,base-5,_n(max(0,a-a2-a3)),size=7.7)
        d.horizontal(x0,axis,343,base+19,_n(a/2-(a5-a4)/2))
        d.horizontal(axis,x0+width,343,base+19,_n(a/2+(a5-a4)/2))
        if abs(dotx-axis)>5:
            d.horizontal(axis,dotx,256,base-4,"xL" if prefix=="b" else "xC",size=7.4)
        if prefix=="w":
            d.vertical(508,top,base,x0+width+7,_n(g["h1"]))


def _beam(d,g,components):
    for prefix,x0,width,key in (("b",129,116,"xL"),("w",260,204,"xC")):
        a,_,_,a4,a5,a6,*_= _dimensions(g,prefix)
        s=width/max(a,.01)
        left,right=x0+a4*s,x0+width-a5*s
        top=660
        total=max(g["h2"]+g["h3"],.01)
        hs=44/total
        shoulder=top+g["h2"]*hs
        lower=top+44
        d.polygon([(x0,top),(x0+width,top),(x0+width,shoulder),(right,lower),(left,lower),(x0,shoulder)])
        d.line(left,lower,right,lower,dashed=True)
        d.line(left,lower,left,lower+27)
        d.line(right,lower,right,lower+27)
        axis=(left+right)/2
        dotx=axis+components["はり"][key]*s
        doty=top-components["はり"]["hG"]*hs
        d.dot(dotx,doty)
        d.line(axis,top-20,axis,lower+32,thin=True,dashed=True)
        d.horizontal(x0,x0+width,617,top-5,_n(a))
        if abs(dotx-axis)>4:
            d.horizontal(axis,dotx,632,doty-3,"xL" if prefix=="b" else "xC",size=7.2)
        else: d.text(axis-3,632,"xL" if prefix=="b" else "xC",7.2)
        xx=[x0,left,axis,right,x0+width]
        vv=[a4,(a-a4-a5)/2,(a-a4-a5)/2,a5]
        for i,(x1,x2,value) in enumerate(zip(xx,xx[1:],vv)):
            d.horizontal(x1,x2,733,lower+3,_n(value),size=7.5,label_y=745 if x2-x1<32 else None)
        if prefix=="w":
            d.vertical(509,top,shoulder,x0+width+9,_n(g["h2"]))
            d.vertical(519,shoulder,lower,right+6,None)
            midpoint=(shoulder+lower)/2
            d.line(521,midpoint,526,midpoint+2,thin=True)
            d.text(529,midpoint+4,_n(g["h3"]),8,anchor="start",white=True)


def _foundation(d,g,components,*,kind,top,bottom,floor,water=None):
    """Paired component sections; all dimensions and centroids use current data."""
    for prefix,x0,width,key in (("b",129 if kind in ("soil","water") else 85,146,"xL"),
                               ("w",319 if kind in ("soil","water") else 260,204,"xC")):
        a,_,_,_,_,column,a7,a8,a9=_dimensions(g,prefix)
        total=a7+a8+a9
        sx=width/max(total,.01)
        axis=x0+width/2
        column_center=axis+(a7-a9)/2*sx
        cl,cr=column_center-column*sx/2,column_center+column*sx/2
        fl,fr=x0+a7*sx,x0+(a7+a8)*sx
        footing_h=g["h5"]+g["h6"]
        foot_display=43 if kind=="column" else 57
        sy=foot_display/max(footing_h,.01)
        shoulder=bottom-g["h6"]*sy
        foot_top=bottom-foot_display
        d.polygon([(x0,bottom),(x0+width,bottom),(x0+width,shoulder),(fr,foot_top),(fl,foot_top),(x0,shoulder)])
        d.line(cl,top,cl,foot_top)
        d.line(cr,top,cr,foot_top)
        d.line(fl,foot_top,fr,foot_top,dashed=True)
        if kind=="column":
            d.line(cl,top,cr,top)
            doty=(top+foot_top)/2
            labelcomp=components["柱"]
            dimension_y=foot_top-29
            d.horizontal(cl,cr,top+43,top+3,_n(column))
        elif kind=="footing":
            labelcomp=components["フーチング"]
            doty=bottom-labelcomp["hG"]*sy
            dimension_y=foot_top-29
        else:
            labelcomp=components[water[0] if water else "上載土"]
            df1,df2=g["df1"],g["df2"]
            if prefix=="w": df1=df2=_column_soil_depth(g)
            # Soil and water diagrams have independent vertical scales, like
            # the original calculation-sheet schematics, to keep labels clear.
            soil_scale=min(34/max(df1,df2,.01),18)
            gy1=foot_top-df1*soil_scale
            gy2=foot_top-df2*soil_scale
            d.ground(x0,gy1,x0+width,gy2)
            dimension_y=foot_top-13
            doty=foot_top-6
            if prefix=="b":
                d.vertical(x0-29,gy1,foot_top,x0-12,_n(df1))
                d.vertical(x0+width+25,gy2,foot_top,x0+width+8,_n(df2))
            else:
                d.vertical(x0+width*.35,gy1,foot_top,cl,_n(df1))
            if water:
                level=water[1]
                wy=max(top+18,min(bottom+4,bottom-level*sy))
                d.line(x0,wy,x0+width,wy,dashed=prefix=="b")
                if prefix=="w":
                    d.text(x0+3,wy-8,"▽ 水位",8,anchor="start")
                    for i in range(3): d.line(x0+2+i*2,wy+3+i*3,x0+11-i*2,wy+3+i*3,thin=True)
                    d.vertical(x0+width-18,wy,bottom,x0+width-29,_n(level))
                else:
                    offset={"高水位":0,"平水位":34,"低水位":68}[water[0]]
                    rectangle=water[2][f"G{220+offset}"]
                    wedge=water[2][f"L{220+offset}"]
                    split=max(x0,min(x0+width,x0+rectangle*sx))
                    d.horizontal(x0,split,top-2,top+11,_n(rectangle),size=7.2)
                    d.horizontal(split,x0+width,top-2,top+11,_n(wedge),size=7.2)
        dotx=max(x0,min(x0+width,axis+labelcomp[key]*sx))
        _centroid(d,dotx,doty,axis,floor-13,"xL" if prefix=="b" else "xC")
        # Top-of-footing and total dimensions share the same datum as the
        # self-weight formula (including eccentric footing shoulders).
        for x1,x2,val in ((x0,fl,a7),(fl,fr,a8),(fr,x0+width,a9)):
            d.horizontal(x1,x2,dimension_y,foot_top-2,_n(val),size=7.6,
                         label_y=dimension_y+12 if abs(x2-x1)<9 else None)
        d.horizontal(x0,x0+width,floor,bottom+5,_n(total))
        if prefix=="b" and kind in ("soil","water"):
            # Retain the separate H5 / H6 dimensions used by the source
            # soil and buoyancy calculations, including a zero haunch.
            d.vertical(100,foot_top,shoulder,x0-12,None)
            midpoint=(foot_top+shoulder)/2
            d.line(100,midpoint,96,midpoint,thin=True)
            d.text(94,midpoint+2,_n(g["h5"]),8,anchor="end",white=True)
            if kind=="water":
                d.vertical(112,shoulder,bottom,x0-5,_n(g["h6"]))
        if prefix=="w" and kind=="water":
            d.vertical(536,foot_top,bottom,x0+width+3,_n(footing_h))
        if prefix=="w" and kind in ("column","footing"):
            if kind=="column":
                d.vertical(509,top,foot_top,cr+8,_n(g["h4"]))
                d.vertical(509,foot_top,bottom,x0+width+8,_n(footing_h))
            else:
                d.vertical(509,foot_top,shoulder,x0+width+8,None)
                midpoint=(foot_top+shoulder)/2
                d.line(511,midpoint,526,midpoint,thin=True)
                d.text(529,midpoint+2,_n(g["h5"]),8,anchor="start",white=True)
                d.vertical(509,shoulder,bottom,x0+width+8,_n(g["h6"]))
            d.vertical(494,doty,bottom,dotx+15,"y")


def _support(d,x,y):
    d.polygon([(x,y),(x-3,y+6),(x+3,y+6)])


def _moving(d,result,*,lateral=False):
    moving=result["moving_lateral" if lateral else "moving_train"]
    b,c=(result["input"]["spans"][key] for key in ("b","c"))
    la=b["l1"]+b["span"]+b["l2"]
    whole=la+c["l1"]+c["span"]+c["l2"]
    left,right=(132,477) if lateral else (145,492)
    scale=(right-left)/max(whole,.01)
    x=lambda position:left+position*scale
    baseline=235
    d.line(left,baseline,right,baseline)
    support_positions=(b["l1"],b["l1"]+b["span"],la+c["l1"],la+c["l1"]+c["span"])
    for xx in support_positions: _support(d,x(xx),baseline)
    positions=sorted(p for p in moving["positions"] if -.0001<=p<=whole+.0001)
    for xx in positions:
        d.line(x(xx),208,x(xx),baseline)
        d.arrow(x(xx),baseline,0,-1,size=5,thin=False)
    # Every active axle is drawn. Dimensions use two tiers when dense so the
    # text remains legible for arbitrary train counts and span lengths.
    intervals=[(0,*positions,whole)[i:i+2] for i in range(len(positions)+1)]
    tier_right=[-1e9,-1e9,-1e9]
    for index,(begin,end) in enumerate(intervals):
        if end-begin<.0001: continue
        label=_n(end-begin)
        xx1,xx2=x(begin),x(end)
        center=(xx1+xx2)/2
        text_width=pdfmetrics.stringWidth(label,d.font,7.2)
        available=[i for i,last in enumerate(tier_right) if center-text_width/2>last+2]
        tier=available[0] if available else index%3
        tier_right[tier]=center+text_width/2
        d.horizontal(xx1,xx2,191-tier*10,204,label,size=7.2)
    xs=[0,b["l1"],b["l1"]+b["span"],la,la+c["l1"],la+c["l1"]+c["span"],whole]
    vals=[b["l1"],b["span"],b["l2"],c["l1"],c["span"],c["l2"]]
    for i,(start,end,value) in enumerate(zip(xs,xs[1:],vals)):
        # Short overhangs get staggered leaders to keep B and C labels apart.
        yy=269
        d.line(x(start),baseline+7,x(start),yy+3,thin=True)
        d.line(x(end),baseline+7,x(end),yy+3,thin=True)
        d.line(x(start),yy,x(end),yy,thin=True)
        d.arrow(x(start),yy,1,0)
        d.arrow(x(end),yy,-1,0)
        if i in (2,3):
            d.text(x(la)+(-17 if i==2 else 17),yy-9,_n(value),7.2)
        else: d.text((x(start)+x(end))/2,yy-9,_n(value),7.2)
    d.horizontal(left,x(la),286,baseline+9,_n(la),size=8)
    d.horizontal(x(la),right,286,baseline+9,_n(whole-la),size=8)


# Source-page vertical extents, including dimension labels and extension lines.
# The pagination layer moves complete figures, never crops them into fragments.
DIAGRAM_BOUNDS: dict[int, tuple[tuple[float, float], ...]] = {
    3: ((130,363),(446,679)),  # Side and front overall elevations.
    4: ((202,350),(604,750)),  # Pedestal and beam.
    5: ((208,422),),
    6: ((312,465),),
    7: ((110,292),(612,805)),  # Soil and complete high-water figure.
    8: ((400,592),),          # Normal water only; no continuation fragment.
    9: ((187,379),),
    11: ((158,293),),
    34: ((158,293),),
}


def draw_diagrams(canvas, result: dict, page_number: int, fonts: tuple[str,str], *,
                  y_range: tuple[float,float] | None = None) -> None:
    """Draw complete figures contained in a source-page vertical band.

    ``page_number`` is the original 1-based calculation-sheet page number.
    ``y_range`` uses points measured from that source page's top.  Only figures
    whose entire ``DIAGRAM_BOUNDS`` interval lies in the band are drawn; a band
    crossing a figure does not draw a clipped fragment.  Coordinates remain in
    the source-page system, so the caller can translate the canvas to relocate
    a band.  With no band, all figures for the source page are drawn.

    High water is now complete on source page 7 through y=802 (floor=798).
    Source page 8 contains only the normal-water figure.
    """
    if y_range is not None and y_range[0] > y_range[1]:
        raise ValueError("y_range must be ordered from top to bottom")
    if page_number not in DIAGRAM_BOUNDS:
        return
    def selected(index):
        top,bottom=DIAGRAM_BOUNDS[page_number][index]
        return y_range is None or (y_range[0] <= top and bottom <= y_range[1])
    canvas.saveState()
    d=_Drawing(canvas,fonts[0])
    g=result["input"]["geometry"]
    comp=result["weights"]["components"]
    cells=result["weights"]["cells"]
    if page_number==3:
        if selected(0): _overall(d,g,"b",357)
        if selected(1): _overall(d,g,"w",673)
    elif page_number==4:
        if selected(0): _pedestal(d,g,comp)
        if selected(1): _beam(d,g,comp)
    elif page_number==5 and selected(0):
        _foundation(d,g,comp,kind="column",top=214,bottom=371,floor=414)
    elif page_number==6 and selected(0):
        _foundation(d,g,comp,kind="footing",top=316,bottom=416,floor=459)
    elif page_number==7:
        if selected(0):
            _foundation(d,g,comp,kind="soil",top=114,bottom=243,floor=286)
        if selected(1):
            _foundation(d,g,comp,kind="water",top=628,bottom=755,floor=798,
                        water=("高水位",g["hw1"],cells))
    elif page_number==8 and selected(0):
        _foundation(d,g,comp,kind="water",top=414,bottom=541,floor=584,
                    water=("平水位",g["hw2"],cells))
    elif page_number==9 and selected(0):
        _foundation(d,g,comp,kind="water",top=201,bottom=328,floor=371,
                    water=("低水位",g["hw3"],cells))
    elif page_number in (11,34) and selected(0):
        _moving(d,result,lateral=page_number==34)
    canvas.restoreState()
