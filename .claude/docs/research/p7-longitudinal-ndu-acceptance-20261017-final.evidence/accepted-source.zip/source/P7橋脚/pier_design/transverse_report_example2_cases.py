"""Draw the three case sheets in the layout of Example2, pages 13–15.

Positions use PDF points measured from the reference.  The coefficient sheet
is sideways on a portrait sheet, just as in the reference (page Rotate = 0).
Only presentation lives here: references and coefficients come from result.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from typing import TYPE_CHECKING, Any

from reportlab.pdfbase import pdfmetrics

if TYPE_CHECKING:
    from .transverse_report_example2 import _Report
    from .transverse_report_style import _Page


_Case = Mapping[str, Any]

_SIZE = 9.94
_OUTER = .96
_INNER = .12


def _text(page: _Page, x: float, y: float, value: object, *, align: str = "left",
          size: float = _SIZE, width: float | None = None, bold: bool = False) -> None:
    page.text(x, y, value, size, align, width=width, bold=bold)


def _grid(page: _Page, xs: Sequence[float], top: float, header: float, height: float,
          count: int, *, heavy_columns: Sequence[int] = ()) -> None:
    """A source-style grid, without shading or extra cell padding."""
    bottom = top + header + count * height
    for index, x in enumerate(xs):
        page.line(x, top, x, bottom,
                  _OUTER if index in (0, len(xs) - 1, *heavy_columns) else _INNER)
    for y in (top, top + header, bottom):
        page.line(xs[0], y, xs[-1], y, _OUTER)
    for index in range(1, count):
        y = top + header + index * height
        page.line(xs[0], y, xs[-1], y, _INNER)


def _symbol(page: _Page, x: float, y: float, symbol: str, *, size: float = _SIZE) -> None:
    """The first character is full size; the reference suffix is subscript."""
    base, subscript = symbol[0], symbol[1:]
    small = size * 2 / 3
    base_width = pdfmetrics.stringWidth(base, page.fonts[0], size)
    sub_width = pdfmetrics.stringWidth(subscript, page.fonts[0], small)
    left = x - (base_width + sub_width) / 2
    _text(page, left, y, base, size=size)
    _text(page, left + base_width, y + 1.92, subscript, size=small)


def _basic_label(page: _Page, case: _Case, y: float) -> None:
    parts = case["label"].split()
    _text(page, 123.48, y, parts[0])
    if case["family"] == "impact":
        _text(page, 205.80, y, parts[1])
        _text(page, 288.12, y, parts[2])
        if len(parts) > 3:
            _text(page, 323.40, y, parts[3])
    elif len(parts) > 1:
        _text(page, 205.80, y, parts[1])
        if len(parts) > 2:
            _text(page, 323.40, y, parts[2])


def _define_label(page: _Page, case: _Case, y: float) -> None:
    parts = case["label"].split()
    _text(page, 288.12, y, parts[0])
    condition = parts[2] if case["family"] == "impact" else parts[1] if len(parts) > 1 else ""
    if condition:
        _text(page, 370.44, y, condition)


def _basic_and_define(report: _Report) -> None:
    report.source_start()
    page, result = report.page, report.result
    _text(page, 64.68, 79.678, "9.4 設計作用の組合せおよび応力算出点", bold=True)
    _basic_table(page, result)
    _define_table(page, result)


def _basic_table(page: _Page, result: Mapping[str, Any]) -> None:
    _text(page, 88.20, 106.798, "(1) 基本ケース", bold=True)
    xs = (98.16, 121.74, 356.94, 403.92)
    _grid(page, xs, 122.518, 27.12, 13.56, len(result["basic_cases"]))
    for x, label in ((105.36, "No"), (204.48, "荷　重　名　称"), (370.80, "バネ")):
        _text(page, x, 139.198, label)
    for index, case in enumerate(result["basic_cases"]):
        y = 161.038 + index * 13.56
        _text(page, 110.40, y, case["id"], align="center")
        _basic_label(page, case, y)
        _text(page, 380.88, y, case["spring_case"], align="center")


def _define_table(page: _Page, result: Mapping[str, Any]) -> None:
    _text(page, 88.20, 405.118, "(2) Defineケース", bold=True)
    xs = (98.16, 121.74, 157.02, 192.30, 227.58, 286.38, 521.52)
    _grid(page, xs, 420.838, 27.12, 13.56, len(result["define_cases"]))
    for x, label in ((105.36, "No"), (134.76, "C1"), (170.04, "C2"),
                     (205.32, "C3"), (247.32, "記号"), (369.12, "荷　重　名　称")):
        _text(page, x, 437.518, label)
    basics = {case["id"]: case for case in result["basic_cases"]}
    for index, case in enumerate(result["define_cases"]):
        y = 457.918 + index * 13.56
        _text(page, 110.40, y, case["id"], align="center")
        for column, reference in enumerate(case["signed_basic_case_ids"]):
            _text(page, xs[column + 2] - 6.94, y, reference, align="right")
        _symbol(page, 257.40, y - .72, case["source_symbol"])
        _define_label(page, basics[abs(case["signed_basic_case_ids"][0])], y + 1.44)


def _vertical(page: _Page, x: float, y: float, text: str, step: float = 11.16) -> None:
    for index, character in enumerate(text):
        _text(page, x, y + step * index, character, size=9.96)


def _coefficient(value: float) -> str:
    if value == 0:
        return "－"
    text = format(float(value), ".12g")
    return text if "." in text or "e" in text.lower() else text + ".0"


def _matrix_grid(page: _Page) -> list[float]:
    left, top, right, bottom = 80.002, 103.68, 660.802, 432.60
    x = [left + index * 29.04 for index in range(19)] + [right]
    _matrix_columns(page, x, top, bottom)
    _matrix_rows(page, x, top, bottom)
    return x


def _matrix_columns(page: _Page, x: Sequence[float], top: float, bottom: float) -> None:
    # No, performance and item columns run the full height.  Coefficient
    # divisions are interrupted at merged family headings.
    for column in (0, 1, 2, 3, 18, 19):
        page.line(x[column], top, x[column], bottom,
                  _OUTER if column in (0, 3, 19) else _INNER)
    families = {5, 8, 11, 13, 15, 16}
    for column in range(4, 18):
        page.line(x[column], top, x[column], 117.24, _INNER)
        page.line(x[column], 117.24 if column in families else 130.80,
                  x[column], bottom, _INNER)


def _matrix_rows(page: _Page, x: Sequence[float], top: float, bottom: float) -> None:
    left, right = x[0], x[-1]
    for y in (top, 171.48, bottom):
        page.line(left, y, right, y, _OUTER)
    page.line(x[3], 117.24, x[18], 117.24, _INNER)
    page.line(x[3], 130.80, x[15], 130.80, _INNER)
    page.line(x[16], 130.80, x[18], 130.80, _INNER)
    page.line(x[3], 157.92, x[18], 157.92, _INNER)
    for row in range(1, 16):
        y = 171.48 + row * 16.32
        if row in (4, 7, 9, 13):
            page.line(left, y, right, y, _OUTER)
        else:
            page.line(x[0], y, x[1], y, _INNER)
            page.line(x[3], y, right, y, _INNER)
            if row == 14:
                page.line(x[2], y, x[3], y, _INNER)


def _matrix_header(page: _Page, xs: Sequence[float], defines: Sequence[_Case]) -> None:
    _text(page, 89.602, 140.76, "No", size=9.96)
    _vertical(page, 118.522, 123.84, "要求性能")
    _vertical(page, 147.562, 123.84, "性能項目")
    _text(page, 622.162, 140.76, "備考", size=9.96)
    for start, count, name in ((3, 2, "死荷重"), (5, 3, "浮力"), (8, 3, "雪荷重"),
                               (11, 2, "列車荷重"), (13, 2, "衝撃荷重"), (16, 2, "風荷重")):
        _text(page, (xs[start] + xs[start + count]) / 2, 127.20,
              name, align="center", size=9.96)
    for offset, case in enumerate(defines):
        center = (xs[offset + 3] + xs[offset + 4]) / 2
        _text(page, center, 113.64, case["id"], align="center", size=9.96)
        _symbol(page, center, 167.16, case["combination_symbol"], size=9.96)
    _matrix_conditions(page, xs)


def _matrix_conditions(page: _Page, xs: Sequence[float]) -> None:
    for column, label in ((3, "固定"), (4, "付加"), (11, "単線"), (12, "複線"),
                          (13, "単線"), (14, "複線")):
        _text(page, (xs[column] + xs[column + 1]) / 2, 147.48,
              label, align="center", size=9.96)
    for column, label, datum in ((5, "高水位", "HWL"), (6, "平水位", "MWL"), (7, "低水位", "LWL")):
        center = (xs[column] + xs[column + 1]) / 2
        _text(page, center, 140.28, label, align="center", size=8.48)
        _text(page, center, 154.32, datum, align="center", size=9.90)
    for column, label in ((8, "2年"), (9, "10年"), (10, "30年"), (16, "列車"), (17, "列車")):
        center = (xs[column] + xs[column + 1]) / 2
        _text(page, center, 141.96, label, align="center", size=9.96)
        second = "確率" if column < 11 else "あり" if column == 16 else "なし"
        _text(page, center, 153.12, second, align="center", size=9.96)
    for y, text in ((129.60, "車両"), (140.76, "横荷"), (151.92, "重")):
        _text(page, (xs[15] + xs[16]) / 2, y, text, align="center", size=9.96)


def _matrix_groups(page: _Page) -> None:
    for y in (196.08, 342.96):
        _vertical(page, 118.522, y, "安全性")
    _vertical(page, 124.162, 253.20, "使用性")
    _vertical(page, 113.002, 253.20, "耐久性")
    _vertical(page, 124.162, 299.52, "復旧")
    _text(page, 113.002, 305.16, "性", size=9.96)
    _vertical(page, 118.522, 400.08, "使用性")
    for y, text in ((201.60, "破壊"), (247.56, "ひび割れ"),
                    (299.52, "損傷"), (331.68, "地盤の安定")):
        _vertical(page, 147.562, y, text)
    _text(page, 143.002, 394.92, "長期", size=9.96)
    _text(page, 143.002, 419.40, "短期", size=9.96)


def _matrix_body(page: _Page, xs: Sequence[float], result: Mapping[str, Any]) -> None:
    for index, case in enumerate(result["combinations"]):
        y = 182.76 + index * 16.32
        _text(page, 102.202, y, case["id"], align="right", size=9.96)
        for column, coefficient in enumerate(case["coefficients"]):
            center = (xs[column + 3] + xs[column + 4]) / 2
            _text(page, center, y, _coefficient(coefficient), align="center",
                  size=9.96, width=27.0)
        if index < 13:
            _text(page, (xs[18] + xs[19]) / 2, y, case["label"].split()[-1],
                  align="center", size=9.96)


def _combination_matrix(report: _Report) -> None:
    report.source_start()
    page, result = report.page, report.result
    page.c.saveState()
    try:
        # _Page uses (x, 842-y). This maps its virtual landscape coordinates
        # to the reference portrait sheet without changing the PDF Rotate flag.
        page.c.translate(842, 0)
        page.c.rotate(90)
        _text(page, 67.282, 88.92, "(3) 組合せケースと荷重係数", size=9.96, bold=True)
        xs = _matrix_grid(page)
        _matrix_header(page, xs, result["define_cases"])
        _matrix_groups(page)
        _matrix_body(page, xs, result)
    finally:
        page.c.restoreState()


def _extractions(report: _Report) -> None:
    report.source_start()
    page, result = report.page, report.result
    _text(page, 67.44, 117.838, "(4) 抽出ケース", bold=True)
    xs = (80.16, 109.20, 268.98, 298.02, 327.06, 356.10, 385.08)
    _grid(page, xs, 136.318, 32.64, 16.32, len(result["extraction_cases"]), heavy_columns=(1,))
    for x, label in ((90.12, "No"), (154.20, "荷　重　名　称"),
                     (278.88, "C1"), (307.92, "C2"), (336.96, "C3"), (366.0, "C4")):
        _text(page, x, 155.758, label)
    for index, case in enumerate(result["extraction_cases"]):
        y = 180.238 + index * 16.32
        _text(page, 102.32, y, case["id"], align="right")
        _text(page, 111.00, y, case["label"])
        for column, reference in enumerate(case["combination_ids"]):
            _text(page, xs[column + 3] - 6.94, y, reference, align="right")


def render_case_pages(report: _Report) -> None:
    """Append basic/Define, sideways matrix, and extraction sheets."""
    _basic_and_define(report)
    _combination_matrix(report)
    _extractions(report)
