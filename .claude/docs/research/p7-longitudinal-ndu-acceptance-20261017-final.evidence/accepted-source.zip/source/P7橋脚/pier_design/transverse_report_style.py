"""Reference-style 0620 pages built from current calculated values."""
from __future__ import annotations
from functools import lru_cache
import json
from pathlib import Path
from typing import Any, Mapping
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfgen.canvas import Canvas
from .frame_outline import build_outline, draw_outline, fit_frame, frame_dimensions
from .frame_model_report import draw_frame_graph, draw_model_conditions
from .reaction_math import excel_round
from .reaction_report_layout import draw_layout_page, missing_layout_cells
from .report import _fonts


@lru_cache(maxsize=1)
def load_layout():
    return json.loads((Path(__file__).parent/'assets/transverse_report_layout.json').read_text(encoding='utf-8'))


def _f(value,places=3):
    return '－' if value is None else f'{excel_round(value,places):.{places}f}'


class _Page:
    def __init__(self,canvas,fonts):self.c,self.fonts=canvas,fonts

    def text(self,x,y,text,size=9.9,align='left',width=None,bold=False,colour=(0,0,0)):
        font=self.fonts[1 if bold else 0];text=str(text)
        measured=pdfmetrics.stringWidth(text,font,size)
        if width and measured>width:size*=width/measured
        self.c.setFont(font,size);self.c.setFillColorRGB(*colour)
        method={'left':self.c.drawString,'right':self.c.drawRightString,'center':self.c.drawCentredString}[align]
        method(x,842-y,text)

    def line(self,x1,y1,x2,y2,width=.3,grey=0):
        self.c.setLineWidth(width);self.c.setStrokeGray(grey)
        self.c.line(x1,842-y1,x2,842-y2)

    def note(self,y,lines):
        for line in lines:
            wrapped=''
            for character in line:
                if wrapped and pdfmetrics.stringWidth(wrapped+character,self.fonts[0],8.1)>435:
                    self.text(102,y,wrapped,8.1);y+=12;wrapped=''
                wrapped+=character
            self.text(102,y,wrapped,8.1);y+=12
        return y

    def table(self,x,y,widths,headers,rows,*,size=9.2,row_height=18,header_height=32,red_columns=()):
        xs=[x]
        for width in widths:xs.append(xs[-1]+width)
        bottom=y+header_height+row_height*len(rows)
        for xx in xs:self.line(xx,y,xx,bottom,.3,.45)
        for yy in (y,y+header_height,bottom):self.line(x,yy,xs[-1],yy,.65)
        for i,heading in enumerate(headers):
            for j,line in enumerate(str(heading).split('\n')):
                self.text((xs[i]+xs[i+1])/2,y+12+j*11,line,size,'center',widths[i]-5)
        for index,row in enumerate(rows):
            yy=y+header_height+index*row_height
            for i,value in enumerate(row):
                self.text((xs[i]+xs[i+1])/2,yy+row_height*.72,value,size,'center',widths[i]-5,
                          colour=(1,0,0) if i in red_columns else (0,0,0))
            if index+1<len(rows):self.line(x,yy+row_height,xs[-1],yy+row_height,.18,.65)
        return bottom


def _frame(p: _Page, result: Mapping[str, Any]) -> None:
    frame = result['frame']
    outline = build_outline(result['input']['geometry'], 'w')
    layout = fit_frame(outline, frame['nodes'], (102, 200, 535, 610),
                       members=frame['members'], dimensions=frame_dimensions(frame),
                       font=p.fonts[0], font_size=9.9)
    draw_outline(p.c, outline, layout)
    draw_frame_graph(p.c, p.fonts, frame, layout)
    p.note(666, [f"基礎底面の支持節点ID: {frame['support_node_id']}。太線は剛域。",
                 '骨組図・寸法は現在の実節点・部材接続に対応する。構造解析・部材照査は含まない。'])


def _selection(p,result):
    p.text(88,90,'支承位置・荷重分担および単線選択',10,bold=True)
    s=result['single_track_selection'];c=result['cells']['荷重計算']
    p.note(118,['単線選択は保存荷重による事前選択から順序変更し、現在の入力・上流荷重で評価する。',
                '荷重モーメントのC側アームは、元の計算に従いB側支承位置を使用する。'])
    headers=['支承','B位置\n(m)','C位置\n(m)','複線B\n分担率','複線C\n分担率','採用B値','採用C値']
    rows=[[f'G{i+1}',_f(c[f'G{i+5}']),_f(c[f'Y{i+5}']),_f(c[f'J{i+5}']),_f(c[f'AB{i+5}']),
           _f(s['factors_B'][i],9),_f(s['factors_C'][i],9)] for i in range(10)]
    p.table(88,154,[36,58,58,52,52,91,91],headers,rows,size=8.5)
    p.text(102,390,'単線候補の評価',9.9,bold=True)
    rows=[[r['source_row'],_f(r['sum_B_single'],6),_f(r['sum_C_single'],6),_f(r['score_single'],6),
           '採用' if r['index']==s['selected_index'] else '－'] for r in s['candidates']]
    p.table(102,407,[48,90,90,130,66],['候補','B分担率和','C分担率和','判定値','選択'],rows,size=8.5)
    p.note(533,[f"MD1 = {_f(s['MD1_single'])} kN・m    MD2 = {_f(s['MD2_single'])} kN・m    ML = {_f(s['ML_single'])} kN・m"])
    if s['fallback_to_d2']:
        p.note(558,['採用候補なし：元の計算に従いD2行の荷重(kN)を採用値へ転記する。',
                    'この採用値は正常な分担率ではない。該当する列車・衝撃表のV列は設計鉛直力ではない。'])
    else:p.note(558,[f"採用候補：L{s['selected_index']}。採用B/C値は入力値の精度を保持している。"])
    g=result['input']['geometry']
    rows=[['起点側土かぶり',_f(g['df1']),'終点側土かぶり',_f(g['df2'])],
          ['高水位',_f(g['hw1']),'平水位',_f(g['hw2'])],['低水位',_f(g['hw3']),'単位','m']]
    p.table(102,610,[125,80,125,94],['入力条件','値','入力条件','値'],rows,size=9)


def _train_notes(p,result,page):
    group,name=page['kind'].split('_',1);table=result['vertical'][group][name]
    fallback=name!='ultimate' and result['single_track_selection']['fallback_to_d2']
    y=page['content_bottom']+18;unit='元表 kN' if fallback else 'kN'
    end=p.note(y,[f"V列のみの合計（元式計算値） = {_f(table['distributed_force_sum'])} {unit}    腕の合計 = {_f(table['arm_sum'])} m",
              f"元式モーメント = {_f(table['source_moment_sum'])} kN・m    互換集計（単位なし） = {_f(table['compatibility_total'])}",
              '※ 表末の参考集計は力・腕・モーメントを含むため、鉛直力として使用しない。',
              'モーメントは分担前反力×アーム。C側アームはB側支承位置を使用する。'])
    if fallback:p.note(end+4,['分担値R：D2行の荷重(kN)。V列は元表 kNの表示であり、設計に使える分担率による鉛直力を表しません。'])


def _basic(p,result):
    p.text(88,90,'(4) 設計作用の組合せ',10,bold=True);p.text(102,119,'1) 基本ケース',9.9,bold=True)
    rows=[[f"B{r['id']:02d}",r['printed_number'],r['label'],'・'.join(filter(None,[r['condition'],r['track']])),
           r['spring_case'],'未計算' if r['status']=='template_row_only' else '計算済'] for r in result['basic_cases']]
    end=p.table(88,137,[35,25,138,147,29,64],['ID','No.','荷重名称','条件・線別','ばね','個別荷重'],rows,row_height=20,size=8.7)
    p.note(end+22,['元表の印字No.の重複を保持し、B01～B24で各行を識別する。',
                   '「未計算」の10行は方向別・線別の個別荷重を算定していない。組合せ係数は保持する。',
                   'ばね1：長期、2：短期。分類3の新しいばね値や組合せ応答は本書では算定しない。'])


def _matrix(p,result,part):
    first,last=((0,10),(10,20),(20,28))[part];cols=result['combinations'][first:last]
    p.text(58,90,'設計作用の組合せ',10,bold=True);p.text(58,114,'2) 組合せケース',9.9,bold=True)
    p.text(537,114,f'{part+1} / 3',9,'right')
    widths=[34,141,*([304/len(cols)]*len(cols))]
    headers=['ID','基本ケース',*[f"C{x['id']:02d}\nNo.{x['printed_number']}" for x in cols]]
    rows=[]
    for i,basic in enumerate(result['basic_cases']):
        detail=' '.join(filter(None,[basic['condition'],basic['track']]))
        rows.append([f"B{basic['id']:02d}",basic['label']+(' '+detail if detail else ''),
                     *['' if x['coefficients'][i]==0 else _f(x['coefficients'][i],2) for x in cols]])
    end=p.table(58,136,widths,headers,rows,size=8.1,row_height=18,header_height=32,red_columns=range(2,len(widths)))
    p.note(end+22,['係数は無次元。空欄は0。各頁に全24基本ケースを再掲する。',
                   '未計算の個別荷重や構造解析結果を補う表ではない。'])
    y=end+56
    for col in cols:
        p.text(102,y,f"C{col['id']:02d}：{col['title']}（元表 No.{col['printed_number']}）",8.2,width=435);y+=12


def display_overrides(result):
    c={'G287':'遠心荷重は上表に示す。元の計算では個別の集約・基本ケースに接続されていない。',
       'G214':'a) 安全性（破壊）および復旧性の照査に用いる衝撃荷重'}
    for row in (154,181,208,238,265):c[f'H{row}']='参考集計※'
    return {'荷重計算':c}


def render_transverse_report(result,output_path):
    layout=load_layout();overrides=display_overrides(result)
    missing=missing_layout_cells(layout,result,overrides)
    if missing:raise ValueError(f'0620の表示値が不足: {missing}')
    path=Path(output_path);path.parent.mkdir(parents=True,exist_ok=True)
    c=Canvas(str(path),pagesize=(595,842),pageCompression=1,invariant=1)
    c.setTitle('0620 直角方向荷重');c.setAuthor('P7橋脚 計算プログラム')
    fonts=_fonts();p=_Page(c,fonts)
    output_page = 0

    def finish_page() -> None:
        nonlocal output_page
        output_page += 1
        digest = result['provenance'].get('input_sha256', '未指定')[:12]
        p.text(58,815,f'0620 直角方向荷重　入力 SHA256: {digest}',7)
        p.text(537,815,str(output_page),7,'right')
        c.showPage()

    for page in layout['pages']:
        kind=page['kind']
        if kind=='model':
            draw_model_conditions(c,result,fonts,finish_page)
            continue
        if kind=='selection':_selection(p,result)
        elif kind=='basic':_basic(p,result)
        elif kind.startswith('matrix_'):_matrix(p,result,int(kind[-1])-1)
        else:
            draw_layout_page(c,result,layout,page,fonts,overrides)
            if kind=='frame':_frame(p,result)
            elif kind.startswith(('train_','impact_')):_train_notes(p,result,page)
            elif kind=='dead':p.note(page['content_bottom']+18,['C側荷重のアームは元の計算に従いB側支承位置を使用する。'])
        finish_page()
    c.save()
