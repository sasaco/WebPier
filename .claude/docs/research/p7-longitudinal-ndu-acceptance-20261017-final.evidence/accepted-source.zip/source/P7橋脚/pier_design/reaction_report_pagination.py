"""Reflow the reference's cells and vector figures at calculation boundaries.

Coordinates identify bands in the bundled source layout, not in an input PDF.
Only translation is used: text, rules, and figures retain their original size.
Each output page keeps a table, a water-level calculation, or a complete T1/T2
working together. Short overflow pages from spreadsheet printing are removed.
"""

from __future__ import annotations

from dataclasses import dataclass

from .reaction_report_diagrams import draw_diagrams
from .reaction_report_layout import draw_page
from .reaction_report_snow import SNOW_EXTRA_HEIGHT, SNOW_PAGE_BANDS, draw_snow_page


PAGE_TOP = 56.0
PAGE_BOTTOM = 786.0
BLOCK_GAP = 12.0


@dataclass(frozen=True)
class Band:
    source_page: int
    top: float
    bottom: float

    @property
    def height(self) -> float:
        return self.bottom - self.top


@dataclass(frozen=True)
class Section:
    title: str
    bands: tuple[Band, ...]
    # Continuation headings supply the context lost when T2 starts a new page.
    heading: str = ""
    snow_page: int | None = None

    @property
    def height(self) -> float:
        extra = SNOW_EXTRA_HEIGHT[self.snow_page - 1] if self.snow_page else 0
        return sum(band.height for band in self.bands) + (28 if self.heading else 0) + extra


def _section(title: str, *bands: tuple[int, float, float], heading: str = "",
             snow_page: int | None = None) -> Section:
    return Section(title, tuple(Band(*band) for band in bands), heading, snow_page)


def report_pages(*, omit_pedestal: bool = False) -> tuple[tuple[Section, ...], ...]:
    """Explicit engineering boundaries; no worksheet row-count page breaks."""
    pages = [
        (_section("死荷重・雪荷重・起点側", *SNOW_PAGE_BANDS[0], snow_page=1),),
        (_section("死荷重・雪荷重・終点側", *SNOW_PAGE_BANDS[1], snow_page=2,
                  heading="6.1 死荷重・雪荷重　(2) 主桁反力（続き）"),),
        (_section("橋脚全体図", (3, 84.96, 680)),),
        (_section("はり" if omit_pedestal else "桁受け・はり",
                  (4, 372.48 if omit_pedestal else 86.28, 755)),),
        (_section("柱", (5, 85.68, 422)),
         _section("フーチング", (6, 85.68, 465))),
        (_section("載荷土", (6, 480, 759.24), (7, 71.4, 300)),),
        (_section("高水位", (7, 310, 805)),),
        (_section("平水位", (8, 122, 598)),),
        (_section("底水位", (8, 606, 768.24), (9, 71.4, 385)),),
        (_section("重量・重心集計", (10, 85.68, 500)),),
        (_section("列車荷重", (11, 85.68, 690)),),
        (_section("桁の衝撃荷重", (12, 85.68, 478)),),
        (_section("橋脚・基礎の衝撃荷重", (13, 85.68, 612)),),
        (_section("桁のロングレール縦荷重", (14, 85.68, 428.4)),),
        (_section("桁の制動・始動荷重", (14, 442.68, 728.28),
                  heading="6.3.1 線路方向に働く水平荷重　(1) 桁に働く水平荷重（続き）"),
         _section("桁の地震慣性力", (15, 85.68, 285.6))),
        (_section("0.8 LR", (16, 85.68, 728.28)),),
        (_section("1.0 LR", (17, 85.68, 756.84), (18, 71.4, 85.68)),),
        (_section("1.0 B・T1", (19, 85.68, 485.52)),),
        (_section("1.0 B・T2", (19, 499.8, 756.84), (20, 71.4, 157.08),
                  heading="2) 制動荷重　1.0 B（続き・T2）"),),
        (_section("1.1 B・T1", (21, 85.68, 456.96)),),
        (_section("1.1 B・T2", (21, 471.24, 756.84), (22, 71.4, 128.52),
                  heading="2) 制動荷重　1.1 B（続き・T2）"),),
        (_section("1.0 LR + 1.0 B・T1", (23, 85.68, 528.36)),),
        (_section("1.0 LR + 1.0 B・T2", (23, 542.64, 756.84), (24, 71.4, 199.92),
                  heading="3) ロングレール縦荷重＋制動荷重　安全性　1.0 LR + 1.0 B（続き・T2）"),),
        (_section("1.1 LR + 1.0 B・T1", (25, 85.68, 471.24)),),
        (_section("1.1 LR + 1.0 B・T2", (25, 485.52, 756.84), (26, 71.4, 142.8),
                  heading="3) ロングレール縦荷重＋制動荷重　安全性　1.1 LR + 1.0 B（続き・T2）"),),
        (_section("1.0 LR + 1.1 B", (27, 85.68, 756.84), (28, 71.4, 85.68)),),
        (_section("復旧性・T1", (29, 85.68, 485.52)),),
        (_section("復旧性・T2", (29, 499.8, 756.84), (30, 71.4, 157.08),
                  heading="3) ロングレール縦荷重＋制動荷重　復旧性　1.0 LR + 1.0 B（続き・T2）"),),
        (_section("支承の地震慣性力", (31, 85.68, 656.88)),),
        (_section("線路方向まとめ", (32, 85.68, 373.2)),),
        (_section("遠心荷重", (33, 85.68, 754.08)),),
        (_section("車両横荷重", (34, 85.68, 478)),),
        (_section("風荷重", (35, 85.68, 646.2)),),
        (_section("直角方向の地震慣性力", (36, 85.68, 487.92)),
         _section("直角方向まとめ", (37, 85.68, 327.12))),
    ]
    for page in pages:
        height = sum(section.height for section in page) + BLOCK_GAP * (len(page) - 1)
        if height > PAGE_BOTTOM - PAGE_TOP:
            raise ValueError(f"0600のページ内容が用紙を超えます: {page[0].title}")
    return tuple(pages)


def draw_report_page(canvas, result: dict, sections: tuple[Section, ...],
                     fonts: tuple[str, str], overrides: dict) -> None:
    y = PAGE_TOP
    for section in sections:
        if section.heading:
            canvas.setFont(fonts[1], 9.9)
            canvas.setFillColorRGB(0, 0, 0)
            canvas.drawString(89, 842 - y - 10, section.heading)
            y += 28
        if section.snow_page:
            draw_snow_page(canvas, result, section.snow_page, fonts, overrides, top=y)
            y += section.height - (28 if section.heading else 0) + BLOCK_GAP
            continue
        for band in section.bands:
            canvas.saveState()
            canvas.translate(0, band.top - y)
            draw_page(canvas, result, band.source_page, fonts, overrides,
                      y_range=(band.top, band.bottom))
            draw_diagrams(canvas, result, band.source_page, fonts,
                          y_range=(band.top, band.bottom))
            canvas.restoreState()
            y += band.height
        y += BLOCK_GAP
