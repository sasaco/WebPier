"""Shared graph drawing and paginated current-model conditions for 0610/0620."""

from __future__ import annotations

from collections.abc import Callable, Mapping
import math

from reportlab.pdfbase import pdfmetrics
from reportlab.pdfgen.canvas import Canvas

from .frame_outline import Dimension, FrameLayout, clear_node_labels, dimension_text
from .reaction_report_layout import format_value


MODEL_TABLE_BOTTOM = 765.0
_ROLES = {"cap_top": "梁天端", "footing_top": "基礎天端", "footing_centroid": "基礎重心",
          "footing_bottom": "基礎底面", "h2_h3": "H2/H3", "h3_h4": "H3/H4",
          "parapet_base": "H1基部", "parapet_top": "H1上端"}
_REGIONS = {"h1": "H1", "h2": "H2", "h3": "H3", "h4": "H4",
            "footing_top_to_centroid": "基礎天端→重心",
            "footing_centroid_to_bottom": "基礎重心→底面", "parapet_arm": "H1水平アーム"}


def _text(canvas: Canvas, fonts: tuple[str, str], x: float, y: float, value: object,
          size: float = 9, *, align: str = "left", width: float | None = None) -> None:
    text = str(value)
    measured = pdfmetrics.stringWidth(text, fonts[0], size)
    if width and measured > width:
        size *= width / measured
    canvas.setFont(fonts[0], size)
    canvas.setFillGray(0)
    method = {"left": canvas.drawString, "right": canvas.drawRightString,
              "center": canvas.drawCentredString}[align]
    method(x, canvas._pagesize[1] - y, text)


def _draw_graph_line(canvas: Canvas, page_height: float, a: tuple[float, float],
                     b: tuple[float, float], width: float = .12) -> None:
    canvas.setStrokeGray(0)
    canvas.setLineWidth(width)
    canvas.line(a[0], page_height - a[1], b[0], page_height - b[1])


def _draw_frame_members(canvas: Canvas, frame: Mapping, nodes: Mapping[int, Mapping],
                        layout: FrameLayout, page_height: float) -> None:
    for member in frame["members"]:
        a, b = nodes[member["node_i"]], nodes[member["node_j"]]
        _draw_graph_line(canvas, page_height,
                         layout.point(a["x"], a["y"]), layout.point(b["x"], b["y"]),
                         1.6 if member["behavior"] == "rigid" else .8)


def _draw_frame_nodes(canvas: Canvas, fonts: tuple[str, str], frame: Mapping,
                      layout: FrameLayout, page_height: float) -> None:
    for node in frame["nodes"]:
        point = layout.point(node["x"], node["y"])
        tx, ty = layout.node_labels[node["id"]]
        canvas.setFillGray(0)
        canvas.circle(point[0], page_height - point[1], 1.7, stroke=0, fill=1)
        _text(canvas, fonts, tx, ty, node["id"], 9.9, align="right")


def _draw_member_labels(canvas: Canvas, fonts: tuple[str, str], frame: Mapping,
                        layout: FrameLayout, page_height: float) -> None:
    for member in frame["members"]:
        xx, yy = layout.member_labels[member["id"]]
        canvas.setFillGray(1)
        canvas.setStrokeGray(0)
        canvas.setLineWidth(.35)
        canvas.rect(xx - 3.5, page_height - yy - 7, 7, 14, fill=1, stroke=1)
        _text(canvas, fonts, xx, yy + 3, member["id"], 8, align="center")


def _draw_dimension_label(canvas: Canvas, fonts: tuple[str, str], dimension: Dimension,
                          xx: float, label_y: float, page_height: float) -> None:
    canvas.saveState()
    try:
        canvas.translate(xx - 7, page_height - label_y)
        canvas.rotate(90)
        canvas.setFont(fonts[0], 9.9)
        canvas.setFillGray(0)
        canvas.drawCentredString(0, 0, dimension_text(dimension))
    finally:
        canvas.restoreState()


def _draw_frame_dimensions(canvas: Canvas, fonts: tuple[str, str],
                           layout: FrameLayout, page_height: float) -> None:
    for dimension, label_y in zip(layout.dimensions, layout.dimension_label_ys):
        ya, yb = layout.y(dimension.top), layout.y(dimension.bottom)
        xx = layout.dimension_xs[dimension.column]
        for yy in (ya, yb):
            _draw_graph_line(canvas, page_height, (layout.extension_x, yy), (xx + 3, yy))
        _draw_graph_line(canvas, page_height, (xx, ya), (xx, yb))
        for yy, sign in ((ya, 1), (yb, -1)):
            _draw_graph_line(canvas, page_height, (xx, yy), (xx - 2, yy + sign * 4))
            _draw_graph_line(canvas, page_height, (xx, yy), (xx + 2, yy + sign * 4))
        midpoint = (ya + yb) / 2
        if abs(label_y - midpoint) > 1:
            _draw_graph_line(canvas, page_height, (xx - 3, midpoint), (xx - 7, label_y))
        _draw_dimension_label(canvas, fonts, dimension, xx, label_y, page_height)


def draw_frame_graph(canvas: Canvas, fonts: tuple[str, str], frame: Mapping, layout: FrameLayout) -> None:
    """Draw actual connections and ID labels without relying on node ordering."""
    page_height = canvas._pagesize[1]
    nodes = {node["id"]: node for node in frame["nodes"]}

    canvas.saveState()
    try:
        canvas.setDash([])
        clear_node_labels(canvas, layout)
        _draw_frame_members(canvas, frame, nodes, layout, page_height)
        _draw_frame_nodes(canvas, fonts, frame, layout, page_height)
        _draw_member_labels(canvas, fonts, frame, layout, page_height)
        _draw_frame_dimensions(canvas, fonts, layout, page_height)
    finally:
        canvas.restoreState()


def _coordinate(value: float) -> str:
    """Keep very small real eccentricities distinguishable in the model table."""
    if value and abs(value) < .0005:
        return f"{value:.6g}"
    return format_value(value, "0.000")


def draw_model_conditions(canvas: Canvas, result: Mapping, fonts: tuple[str, str],
                          finish_page: Callable[[], None]) -> None:
    """Print the active graph, retaining legacy cells solely as JSON audit data.

    ``finish_page`` adds the caller's footer and advances the canvas. Each
    table repeats its title/header when split, including under a reduced page
    budget used by pagination regression tests.
    """
    frame = result["frame"]
    top = 77.0
    y = top
    continued = False

    def title() -> None:
        nonlocal y
        _text(canvas, fonts, 88, y, "骨組モデル条件" + ("（続き）" if continued else ""), 10)
        y += 24

    def new_page() -> None:
        nonlocal y, continued
        finish_page()
        y, continued = top, True
        title()

    def line(x1: float, yy1: float, x2: float, yy2: float) -> None:
        canvas.setStrokeGray(.35)
        canvas.setLineWidth(.25)
        canvas.line(x1, 842 - yy1, x2, 842 - yy2)

    def table(name: str, widths: tuple[float, ...], headers: tuple[str, ...], rows: list) -> None:
        nonlocal y
        row_height, heading_height = 16.0, 20.0
        cursor = 0
        while cursor < len(rows):
            if y + 16 + heading_height + row_height > MODEL_TABLE_BOTTOM:
                new_page()
            available = math.floor((MODEL_TABLE_BOTTOM - y - 16 - heading_height) / row_height)
            if available < 1:
                raise ValueError("model table page budget is too small for one readable row")
            chunk = rows[cursor:cursor + available]
            _text(canvas, fonts, 88, y + 2, name + ("（続き）" if cursor else ""), 9.2)
            y += 16
            xs = [88.0]
            for width in widths:
                xs.append(xs[-1] + width)
            bottom = y + heading_height + row_height * len(chunk)
            for xx in xs:
                line(xx, y, xx, bottom)
            for yy in (y, y + heading_height, bottom):
                line(xs[0], yy, xs[-1], yy)
            for i, heading in enumerate(headers):
                _text(canvas, fonts, (xs[i] + xs[i + 1]) / 2, y + 15,
                      heading, 8.6, align="center", width=widths[i] - 5)
            for j, row in enumerate(chunk):
                yy = y + heading_height + j * row_height
                for i, value in enumerate(row):
                    _text(canvas, fonts, (xs[i] + xs[i + 1]) / 2, yy + 12,
                          value, 8.4, align="center", width=widths[i] - 5)
                line(xs[0], yy + row_height, xs[-1], yy + row_height)
            cursor += len(chunk)
            y = bottom + 10
            if cursor < len(rows):
                new_page()

    title()
    table("実節点座標", (32, 65, 65, 282), ("節点ID", "x (m)", "y (m)", "境界・役割"),
          [[n["id"], _coordinate(n["x"]), _coordinate(n["y"]),
            " / ".join(_ROLES[role] for role in n["roles"])] for n in frame["nodes"]])
    table("実部材接続", (32, 32, 32, 130, 44, 87, 87),
          ("部材ID", "始点", "終点", "区間", "挙動", "断面参照", "材料参照"),
          [[m["id"], m["node_i"], m["node_j"], _REGIONS[m["region"]],
            "剛域" if m["behavior"] == "rigid" else "弾性",
            m["section_ref"] or "－", m["material_ref"] or "－"] for m in frame["members"]])
    table("使用断面", (100, 75, 75, 95, 99), ("断面参照", "幅 (m)", "高さ (m)", "A (m2)", "I (m4)"),
          [[name, format_value(s["width"], "0.000"), format_value(s["depth"], "0.000"),
            format_value(s["area"], "0.000"), format_value(s["inertia"], "0.00000")]
           for name, s in frame["sections"].items()])
    table("材料", (148, 148, 148), ("材料参照", "fck (N/mm2)", "Ec (kN/m2)"),
          [[name, format_value(m["fck"], "0.0"), format_value(m["Ec"], "#,##0")]
           for name, m in frame["materials"].items()])
    spring_provenance = frame.get("spring_provenance")
    direction_label = ("線路直角方向" if spring_provenance["direction"] == "transverse" else "線路方向") if spring_provenance else None
    spring_heading = (f"支持・基礎ばね（{direction_label}、取付節点ID: {frame['support_node_id']}）"
                      if spring_provenance else f"支持・基礎ばね（取付節点ID: {frame['support_node_id']}）")
    table(spring_heading, (84, 120, 120, 120),
          ("区分", "Kv (kN/m)", "Ks (kN/m)", "Kr (kN m/rad)"),
          [["長期" if name == "long_term" else "短期",
            *[format_value(s[key], "#,##0") for key in ("Kv", "Ks", "Kr")]]
           for name, s in frame["springs"].items()])
    notes = [
        "H2・H3・H4は従来の等価柱断面 body と材料を継承する。",
        "H1はB3×W3断面。フーチングと偏心H1の水平アームは剛域とする。",
        "部材から自重を自動加算しない。柱頭の集約荷重は梁天端に保持する。",
        "旧4節点の原表セル・転記値・legacy_nodesは、結果JSONの監査用に保持する。",
        "直接基礎を対象とし、杭の条件は適用しない。構造解析・部材照査は含まない。",
        (f"基礎ばねは0500の{direction_label}・長短期の正規Double値。取付節点ID: {spring_provenance['support_node_id']}。"
         if spring_provenance else "基礎ばねは0500の計算済みSingle値。0610のKrは0500直角方向値を用いる。"),
    ]
    for note in notes:
        if y + 13 > MODEL_TABLE_BOTTOM:
            new_page()
        _text(canvas, fonts, 88, y, note, 8, width=444)
        y += 13
    finish_page()
