"""Open equation pages following Example 2's transverse load report.

This module presents canonical actions only.  It neither reconstructs loads
from workbook cells nor combines forces at different application points.
"""
from __future__ import annotations

from typing import TYPE_CHECKING, Any

from reportlab.pdfbase import pdfmetrics

from .transverse_report_style import _f

if TYPE_CHECKING:
    from .transverse_report_example2 import _Report


_Record = dict[str, Any]

_BOTTOM = 752
_LEADING = 13.5
_SIDE_LABELS = {"B": "起点側 RB", "C": "終点側 RC"}


def _new(report: _Report, title: str | None = None) -> None:
    report.source_start(title)


def _ensure(report: _Report, height: float, continuation: str | None = None) -> None:
    if report.y + height > _BOTTOM:
        _new(report)
        if continuation:
            _text(report, continuation + "（続き）", x=78, after=24)


def _text(report: _Report, value: str, *, x: float = 112, size: float = 9.9,
          after: float = 20, bold: bool = False) -> None:
    report.page.text(x, report.y, value, size, bold=bold)
    report.y += after


def _note(report: _Report, value: str, *, x: float = 112, size: float = 9.0,
          after: float = 8) -> None:
    """Wrap explanatory prose without changing the open equation layout."""
    line = ""
    for character in value:
        if line and pdfmetrics.stringWidth(line + character, report.page.fonts[0], size) > 402:
            _ensure(report, 15)
            _text(report, line, x=x, size=size, after=14)
            line = ""
        line += character
    _ensure(report, 15)
    _text(report, line, x=x, size=size, after=14 + after)


def _section(report: _Report, title: str, height: float = 45) -> None:
    _ensure(report, height)
    _text(report, title, x=88.2, size=9.94, after=25, bold=True)


def _point(loads: _Record, anchor: str) -> _Record:
    return next(point for point in loads["points"] if point["anchor"] == anchor)


def _active_rows(loads: _Record) -> list[_Record]:
    # An entered position of zero is an active bearing, including a zero force.
    return [row for row in loads["rows"] if row.get("active", True)
            and not (row.get("side") is None and row.get("label") == "桁受け"
                     and all(row[key] == 0 for key in ("N", "H", "M")))]


def _table_header(report: _Report, kind: str) -> None:
    p, y = report.page, report.y
    if kind == "simple":
        columns = ((217.56, "鉛直力 (kN)"), (311.64, "アーム (m)"), (405.72, "ﾓｰﾒﾝﾄ (kN･m)"))
    else:
        columns = ((323.3, "鉛直力 (kN)"), (394.58, "アーム (m)"), (452.76, "ﾓｰﾒﾝﾄ(kN･m)"))
    for x, label in columns:
        p.text(x, y, label, 9.9, "left")
    report.y += _LEADING


def _start_bearing_table(report: _Report, rows: list[_Record], kind: str,
                         title: str | None) -> None:
    height = 40 + len(rows) * _LEADING + (24 if title else 0)
    # Keep a block together if it fits on an otherwise empty page.
    if height < _BOTTOM - 100:
        _ensure(report, height)
    if title:
        _text(report, title, x=112 if title.startswith("・") else 88.2, after=23,
              bold=not title.startswith("・"))
    _table_header(report, kind)


def _bearing_label(report: _Report, row: _Record, kind: str,
                   previous_side: str | None) -> None:
    p, y = report.page, report.y
    side = row.get("side")
    if kind == "simple":
        label = f"{_SIDE_LABELS[side]} G{row['bearing']}" if side is not None else row.get("label", "")
        if label == "はり・ハンチ等価荷重":
            label = "はり・ハンチ等価"
        p.text(123.48, y, label, 9.9, width=98)
    elif side is not None:
        if kind == "train" or side != previous_side:
            p.text(134, y, _SIDE_LABELS[side], 9.2, width=46)
        p.text(199, y, f"G{row['bearing']} =", 9.2, "right")
    else:
        p.text(134, y, row.get("label", ""), 9.2, width=122)


def _simple_bearing_values(report: _Report, row: _Record) -> None:
    p, y = report.page, report.y
    p.text(260.96, y, _f(row["N"], 2), 9.9, "right")
    p.text(355.04, y, _f(row["arm"], 3), 9.9, "right")
    p.text(449.12, y, _f(row["M"], 2), 9.9, "right")


def _bearing_equation(report: _Report, row: _Record, kind: str,
                      train_by_bearing: dict[tuple[str | None, int | None], _Record]) -> None:
    p, y = report.page, report.y
    if kind == "train":
        left = row["upstream_N"]
        middle = row["factor"]
        middle_places, relation = 3, "="
    else:
        left = train_by_bearing[(row.get("side"), row["bearing"])]["N"]
        middle = row["impact_coefficient"]
        middle_places, relation = 3, "→"
    p.text(247, y, _f(left, 2), 9.5, "right")
    p.text(252.72, y, "×", 9.5)
    p.text(296.39, y, _f(middle, middle_places), 9.5, "right")
    p.text(311.16, y, relation, 9.5)
    p.text(378.71, y, _f(row["N"], 2), 9.5, "right")
    p.text(437.36, y, _f(row["arm"], 3), 9.5, "right")
    p.text(490.88, y, _f(row["M"], 2), 9.5, "right")


def _bearing_rows(report: _Report, rows: list[_Record], kind: str,
                  title: str | None, train_loads: _Record | None) -> None:
    train_by_bearing = {(row.get("side"), row.get("bearing")): row
                        for row in (train_loads or {}).get("rows", [])}
    previous_side = None
    for index, row in enumerate(rows):
        if report.y + _LEADING + (24 if index == len(rows) - 1 else 0) > _BOTTOM:
            _new(report)
            _text(report, (title or "荷重計算") + "（続き）", x=88, after=24)
            _table_header(report, kind)
            previous_side = None
        _bearing_label(report, row, kind, previous_side)
        if kind == "simple":
            _simple_bearing_values(report, row)
        else:
            _bearing_equation(report, row, kind, train_by_bearing)
        previous_side = row.get("side")
        report.y += _LEADING


def _bearing_total(report: _Report, loads: _Record, kind: str,
                   total_N: float | None, total_label: str) -> None:
    report.page.line(123.48 if kind == "simple" else 133, report.y - 9,
                     450 if kind == "simple" else 510, report.y - 9, .45)
    total = loads["table_totals"]
    if kind == "simple":
        report.page.text(123.48, report.y + 2, "合計", 9.9)
        report.page.text(260.96, report.y + 2, _f(total["N"] if total_N is None else total_N, 2), 9.9, "right")
    else:
        report.page.text(318, report.y + 2, total_label, 9.9, "center")
        report.page.text(378.71, report.y + 2, _f(total["N"], 2), 9.9, "right")
    report.page.text(449.12 if kind == "simple" else 490.88, report.y + 2, _f(total["M"], 2), 9.9, "right")
    report.y += 30


def _bearing_table(report: _Report, loads: _Record, *, kind: str = "simple",
                   title: str | None = None, total_N: float | None = None,
                   train_loads: _Record | None = None, total_label: str = "Σ") -> None:
    """Draw only the source's aligned calculation columns and total rule."""
    rows = _active_rows(loads)
    _start_bearing_table(report, rows, kind, title)
    _bearing_rows(report, rows, kind, title, train_loads)
    _bearing_total(report, loads, kind, total_N, total_label)


def _footing_formula(report: _Report, geometry: dict[str, float], footing: _Record) -> None:
    """Expand a rectangular footing only when it reproduces the stated load."""
    g = geometry
    breadth = g["b7"] + g["b8"] + g["b9"]
    width = g["w7"] + g["w8"] + g["w9"]
    product = g["unit_weight_footing"] * breadth * width * g["h6"]
    if g["h5"] == 0 and _f(product, 2) == _f(footing["N"], 2):
        expression = (f"{_f(g['unit_weight_footing'], 1)} × {_f(breadth, 2)} × "
                      f"{_f(width, 2)} × {_f(g['h6'], 2)} = ")
    else:
        expression = ""
    _text(report, f"フーチング　W3 = {expression}{_f(footing['N'], 2)} kN", x=99.96, after=39.6)


def _beam_formula(report: _Report, geometry: dict[str, float], details: _Record) -> None:
    """Show the existing equivalent beam, never the example's different split."""
    g = geometry
    lower_width = g["w1"] - g["w4"] - g["w5"]
    product = g["b1"] * (g["w1"] * g["h2"] + (g["w1"] + lower_width) * g["h3"] / 2) * g["unit_weight_body"]
    if g["b4"] + g["b5"] == 0 and _f(product, 2) == _f(details["beam_N"], 2):
        _text(report, f"はり・ハンチ等価荷重　Wb = {_f(g['b1'], 2)} × {{"
              f"{_f(g['w1'], 2)} × {_f(g['h2'], 2)}", x=99.96, after=13.56)
        _text(report, f"＋ ({_f(g['w1'], 2)} ＋ {_f(lower_width, 2)}) × {_f(g['h3'], 2)} / 2}} × "
              f"{_f(g['unit_weight_body'], 1)} = {_f(details['beam_N'], 2)} kN", x=170, after=28.32)
    else:
        _text(report, f"はり・ハンチ等価荷重　Wb = {_f(details['beam_N'], 2)} kN", x=99.96, after=41.88)


def _soil_formula(report: _Report, geometry: dict[str, float], soil: _Record) -> None:
    g = geometry
    breadth = g["b7"] + g["b8"] + g["b9"]
    width = g["w7"] + g["w8"] + g["w9"]
    upper = g["unit_weight_soil"] * breadth * width * g["df1"]
    excluded = -g["unit_weight_soil"] * g["w6"] * g["b6"] * g["df1"]
    if g["h5"] == 0 and g["df1"] == g["df2"] and _f(upper + excluded, 2) == _f(soil["N"], 2):
        _text(report, f"載荷土　P = {_f(g['unit_weight_soil'], 1)} × {_f(breadth, 2)} × "
              f"{_f(width, 2)} × {_f(g['df1'], 2)} = {_f(upper, 2)} kN", x=99.96, after=13.5)
        _text(report, f"P = −{_f(g['unit_weight_soil'], 1)} × {_f(g['w6'], 2)} × "
              f"{_f(g['b6'], 2)} × {_f(g['df1'], 2)} = {_f(excluded, 2)} kN", x=139, after=13.5)
        _text(report, f"ΣP = {_f(soil['N'], 2)} kN", x=363, after=25)
    else:
        _text(report, f"載荷土　ΣP = {_f(soil['N'], 2)} kN（基礎重心）", x=99.96, after=25)


def _fixed_dead(report: _Report, geometry: dict[str, float], fixed: _Record,
                details: _Record) -> None:
    _text(report, "(1) 固定死荷重", x=88.2, size=9.94, after=19.44, bold=True)
    _text(report, f"柱　q = {_f(geometry['b6'], 2)} × {_f(geometry['w6'], 2)} × "
          f"{_f(geometry['unit_weight_body'], 1)} = {_f(details['column_intensity'], 2)} kN/m",
          x=99.96, after=20.64)
    footing = _point(fixed, "footing_centroid")
    _footing_formula(report, geometry, footing)
    if footing["M"]:
        _text(report, f"M3 = {_f(footing['M'], 2)} kN･m", after=20)
    _text(report, "・橋脚天端に作用する荷重", x=99.96, after=20.64)
    _beam_formula(report, geometry, details)
    _bearing_table(report, fixed, total_N=details["gross_top_N"])
    report.y += 12
    top = _point(fixed, "cap_top")
    _ensure(report, 66, "(1) 固定死荷重")
    _text(report, f"N = {_f(details['gross_top_N'], 2)} − {_f(details['column_intensity'], 2)} × "
          f"{_f(details['overlap_height'], 3)} = {_f(top['N'], 2)} kN", after=21)
    _text(report, f"M = {_f(top['M'], 2)} kN･m", after=22)
    _note(report, "柱との重複区間を橋脚天端荷重から控除する。はり・ハンチは等価荷重を用いる。", after=7)


def _additional_dead(report: _Report, geometry: dict[str, float], additional: _Record) -> None:
    # The six-bearing reference leaves this deliberate gap before D2.
    report.y = max(report.y, 476)
    _section(report, "(2) 付加死荷重", height=155 + len(_active_rows(additional)) * _LEADING)
    soil = _point(additional, "footing_centroid")
    _soil_formula(report, geometry, soil)
    if soil["M"]:
        _text(report, f"M4 = {_f(soil['M'], 2)} kN･m", after=20)
    _text(report, "・橋脚天端に作用する荷重", x=99.96, after=22)
    _bearing_table(report, additional)


def _dead_pages(report: _Report) -> None:
    actions = report.result["actions"]
    geometry = report.result["input"]["geometry"]
    fixed, additional = actions["dead_fixed"], actions["dead_additional"]
    details = fixed["details"]
    _new(report, "9.2　作用の計算")
    _fixed_dead(report, geometry, fixed, details)
    _additional_dead(report, geometry, additional)


def _buoyancy_case(report: _Report, loads: _Record, label: str,
                   breadth: float, width: float, rectangular_top: float) -> None:
    point = _point(loads, "footing_centroid")
    water_level = loads["details"]["water_level"]
    # The canonical buoyancy worksheet uses 10 kN/m³ for water.  Below
    # the lowest soil surface its displaced volume is the full rectangle;
    # above it the wedge/column terms must not be replaced by B*L*h.
    rectangle_force = -10 * breadth * width * water_level
    if water_level <= rectangular_top and _f(rectangle_force, 2) == _f(point["N"], 2):
        _text(report, f"{label}　U = −10 × {_f(breadth, 2)} × {_f(width, 2)} × "
              f"{_f(water_level, 2)} = {_f(point['N'], 2)} kN", x=99.96, after=20)
    else:
        _text(report, f"{label}　h = {_f(water_level, 3)} m　"
              f"U = {_f(point['N'], 2)} kN", x=99.96, after=20)
    if point["M"]:
        _text(report, f"M = {_f(point['M'], 2)} kN･m", after=18)


def _water_and_snow(report: _Report) -> None:
    actions = report.result["actions"]
    g = report.result["input"]["geometry"]
    breadth = g["b7"] + g["b8"] + g["b9"]
    width = g["w7"] + g["w8"] + g["w9"]
    rectangular_top = g["h5"] + g["h6"] + min(g["df1"], g["df2"])
    _new(report)
    _section(report, "(3) 浮力")
    for key, label in (("high", "高水位"), ("normal", "平水位"), ("low", "低水位")):
        _buoyancy_case(report, actions[f"buoyancy_{key}"], label, breadth, width, rectangular_top)
    _note(report, "基礎重心に作用する。鉛直力は下向きを正とする。", after=8)
    _section(report, "(4) 雪荷重")
    for index, years in enumerate((2, 10, 30), 1):
        _bearing_table(report, actions[f"snow_{years}_year"], title=f"{index}) {years}年確率")


def _service_impact_intro(report: _Report) -> bool:
    factor = report.result["factor_parameters"]["service_factor"]
    if factor == 0:
        _note(report, "使用性の荷重修正係数が0のため、使用性の列車・衝撃荷重は0とする。")
        return False
    _note(report, f"使用性の荷重修正係数 a = {_f(factor, 3)} を適用済み。", after=1)
    _note(report, "衝撃係数には使用性の低減0.75を含む。", after=8)
    return True


def _train_or_impact(report: _Report, *, impact: bool = False, service: bool = False,
                     selected: dict[str, _Record] | None = None) -> None:
    actions = report.result["actions"] if selected is None else selected
    name = "衝撃荷重" if impact else "列車荷重"
    _new(report)
    title = "補足　使用性の衝撃荷重" if service else f"({'6' if impact else '5'}) {name}"
    _section(report, title)
    if service and not _service_impact_intro(report):
        return
    _text(report, "1) 単線載荷", x=88.2, after=26, bold=True)
    prefix = "impact" if impact else "train"
    for track, label in (("up", "・上り線載荷"), ("down", "・下り線載荷"), ("double", "2) 複線載荷")):
        _bearing_table(report, actions[f"{prefix}_{track}"], kind="impact" if impact else "train",
                       title=label, train_loads=actions[f"train_{track}"] if impact else None)
        report.y += 7
    if impact:
        _note(report, "→：支点総衝撃力を0.1 kNに丸め、その差を分担率の絶対値に応じて配分した鉛直力。", after=0)
        _note(report, "モーメントは配分後の未丸め鉛直力と各支承のアームから求める。", after=0)
    else:
        _note(report, "列車・衝撃・車両横荷重の基本値は荷重修正係数 a = 1.00。組合せ時に係数を適用する。", after=0)


def _horizontal_sum(report: _Report, loads: _Record, *, moment: bool = False) -> None:
    rows = loads["rows"]
    total = loads["table_totals"]
    if moment:
        _text(report, "M = HB × hB ＋ HC × hC", after=22)
        expression = " ＋ ".join(f"{_f(row['H'], 2)} × {_f(row['arm'], 3)}" for row in rows)
        _text(report, f"   = {expression}", after=21)
        _text(report, f"   = {_f(total['M'], 2)} kN･m", after=28)
    else:
        _text(report, "H = HB ＋ HC", after=22)
        expression = " ＋ ".join(_f(row["H"], 2) for row in rows)
        _text(report, f"   = {expression} = {_f(total['H'], 2)} kN", after=28)


def _wind_table(report: _Report, loads: _Record) -> None:
    for x, heading in ((205.80, "水平力(kN)"), (276.36, "鉛直力(kN)"),
                       (335.16, "アーム(m)"), (405.72, "ﾓｰﾒﾝﾄ(kN･m)")):
        report.page.text(x, report.y, heading, 9.9)
    report.y += 15
    for row in loads["rows"]:
        report.page.text(111.72, report.y, _SIDE_LABELS[row["side"]], 9.9)
        for x, field, places in ((247, "H", 2), (317, "N", 2), (379, "arm", 3), (449.12, "M", 2)):
            report.page.text(x, report.y, _f(row[field], places), 9.9, "right")
        report.y += _LEADING
    report.page.line(111.72, report.y - 8, 450, report.y - 8, .45)
    report.page.text(111.72, report.y + 2, "合計", 9.9)
    report.page.text(363, report.y + 2, "M =", 9.9)
    report.page.text(449.12, report.y + 2, _f(loads["table_totals"]["M"], 2), 9.9, "right")
    report.y += 28
    _note(report, "起点側・終点側の荷重をそれぞれ集約して示す。", x=111.72, after=0)


def _wind(report: _Report, key: str, label: str) -> None:
    loads = report.result["actions"][key]
    _text(report, label, x=88.2, after=37, bold=True)
    _text(report, "・橋脚天端に作用する荷重", after=25)
    _horizontal_sum(report, loads)
    report.y += 10
    _text(report, "・く体に作用する風荷重", after=25)
    geometry = report.result["input"]["geometry"]
    _text(report, f"qH = {_f(loads['details']['pressure'], 1)} × {_f(geometry['b6'], 2)}"
          f" = {_f(loads['line_loads'][0]['qH'], 2)} kN/m", after=38)
    _wind_table(report, loads)


def _horizontal_pages(report: _Report) -> None:
    _new(report)
    _section(report, "(7) 車両横荷重")
    loads = report.result["actions"]["vehicle_lateral"]
    _text(report, "・節点に作用する荷重", after=25)
    _horizontal_sum(report, loads)
    report.y += 12
    _text(report, "・橋脚天端～梁軸芯のトルクによるモーメント", after=25)
    _horizontal_sum(report, loads, moment=True)
    report.y += 10
    _section(report, "(8) 風荷重")
    _wind(report, "wind_with_train", "1) 列車荷重がある場合")
    _new(report)
    _wind(report, "wind_without_train", "2) 列車荷重がない場合")


def _service_actions(result: _Record) -> dict[str, _Record]:
    selected = {}
    for combination in result["combinations"]:
        if combination["id"] not in (5, 7):
            continue
        for component in combination["resolved_components"]:
            for candidate in component["candidates"]:
                if not candidate["action_key"].startswith(("train_", "impact_")):
                    continue
                selected[candidate["action_key"]] = candidate["loads"]
    return selected


def render_load_pages(report: _Report) -> None:
    """Render canonical actions in the source report's content order."""
    _dead_pages(report)
    _water_and_snow(report)
    _train_or_impact(report)
    _train_or_impact(report, impact=True)
    _horizontal_pages(report)
    _train_or_impact(report, impact=True, service=True, selected=_service_actions(report.result))
