"""Draw horizontal-load equations with aligned symbols, results and units."""

from __future__ import annotations

from collections.abc import Callable
import re
from types import SimpleNamespace

from .report import _Page


_LEFT = 72.0
_RIGHT = 545.0
_LEADING = 17.0
_SUBSCRIPT = re.compile(r"([A-Za-z]+)_\{([^}]+)\}")
_SNOW_SYMBOL = {"雪荷重_2年確率": "S_{2}", "雪荷重_10年確率": "S_{10}", "雪荷重_30年確率": "S_{30}"}


def _number(value: float, decimals: int = 2, *, significant: int | None = None) -> str:
    text = format(value, f".{significant}g" if significant is not None else f".{decimals}f")
    return text if len(text) <= 14 else format(value, ".6g")


def _runs(text: str):
    end = 0
    for match in _SUBSCRIPT.finditer(text):
        yield text[end:match.start()], False
        yield match[1], False
        yield match[2], True
        end = match.end()
    yield text[end:], False


def _rich_width(p: _Page, text: str, size: float = 9.9) -> float:
    return sum(p.width(part, size * 2 / 3 if sub else size) for part, sub in _runs(text))


def _rich(p: _Page, x: float, y: float, text: str, *, size: float = 9.9) -> None:
    for part, sub in _runs(text):
        part_size = size * 2 / 3 if sub else size
        p.text(x, y + (1.92 if sub else 0), part, size=part_size)
        x += p.width(part, part_size)


def _expression(p: _Page, x: float, y: float, terms: list[str], *, right: float = _RIGHT) -> float:
    """Break substitutions at term boundaries, never inside a number or symbol."""
    line = ""
    for term in terms:
        candidate = line + term
        if line and _rich_width(p, candidate) > right - x:
            _rich(p, x, y, line)
            y += _LEADING
            line = term
        else:
            line = candidate
    _rich(p, x, y, line)
    return y


def _equation(p: _Page, y: float, symbol: str, terms: list[str], value: float | None = None,
              unit: str = "kN", *, decimals: int = 2, symbol_x: float = 120,
              equal_x: float = 153, expression_x: float = 170) -> float:
    """Place equation columns independently; long substitutions continue below."""
    _rich(p, symbol_x, y, symbol)
    if symbol:
        p.text(equal_x, y, "＝")
    expression = "".join(terms)
    if value is not None and _rich_width(p, expression) <= 447 - expression_x:
        _rich(p, expression_x, y, expression)
    else:
        y = _expression(p, expression_x, y, terms)
        if value is not None and expression:
            y += _LEADING
    if value is not None:
        if equal_x != 450 or expression:
            p.text(450, y, "＝")
        p.text(508, y, _number(value, decimals), align="right", max_width=48)
        p.text(518, y, unit)
    return y + _LEADING


def _coefficient(value: float) -> str:
    return _number(value) if round(value, 2) == value else _number(value, significant=8)


def _brake_multiplier(result: dict, row: dict, side: str) -> str:
    detail = row[side]
    coefficient = _coefficient(detail["effective_brake_coefficient"])
    if result["longitudinal_base"][side]["braking_rule"] == "EA-17" and not detail["recovery_brake_override"]:
        rho = result["input"]["train"]["factors_ultimate"]
        return f"({coefficient} / {_number(rho, significant=8)})" if rho else "0"
    return coefficient


def _horizontal_terms(result: dict, row: dict, side: str) -> str:
    combination = row["combination"]
    terms = []
    if combination["lr_factor"]:
        terms.append(f"{combination['lr_factor']:.1f} L_{{R}}")
    if combination["brake_factor"]:
        symbol = "B_{0}" if _unfactored_ea17(result, row, side) else "B"
        terms.append(f"{_brake_multiplier(result, row, side)} {symbol}")
    return " ＋ ".join(terms)


def _condition(row: dict) -> str:
    return row["label"].split()[0]


def _unfactored_ea17(result: dict, row: dict, side: str) -> bool:
    return result["longitudinal_base"][side]["braking_rule"] == "EA-17" and row[side]["recovery_brake_override"]


def _vertical_symbol(combination: dict) -> str:
    terms = [f"{combination['d1_factor']:.1f} D_{{1}}", f"{combination['d2_factor']:.1f} D_{{2}}"]
    if combination["live_group"]:
        live = "(L＋I)" if combination["include_impact"] else "L"
        terms.append(f"{_coefficient(combination['effective_live_coefficient'])} {live}")
    terms.append(_SNOW_SYMBOL[combination["snow_key"]])
    return " ＋ ".join(terms)


def _introduction(p: _Page, result: dict, finish_page: Callable[[], None]) -> float:
    vehicle = result["input"]["train"]
    p.heading(_LEFT, 96, "6.3.1 線路方向に働く水平荷重")
    if vehicle.get("name"):
        p.text(545, 96, f"設計車両：{vehicle['name']}", align="right")
    p.heading(_LEFT, 124, "(1) 桁に働く水平荷重")
    p.heading(85, 152, "1) ロングレール縦荷重")
    top = 180.0
    for rate, description in ((10, "(a) ひび割れの検討および安全性・復旧性の照査"), (8, "(b) 使用性の照査")):
        p.text(99, top, description)
        p.text(115, top + 21, f"1 軌道当り　{rate} kN/m を考える。")
        top += 42
        for number, side in ((1, "B"), (2, "C")):
            base = result["longitudinal_base"][side]
            rail = "LR" if rate == 10 else "LR_service"
            terms = [f"{rate} × {_number(base['length'])} × {_number(base['track_total'], significant=6)}"]
            if rate * base["length"] > 2000:
                terms = [f"min({rate} × {_number(base['length'])}, 2000)", f" × {_number(base['track_total'], significant=6)}"]
            top = _equation(p, top, f"T{number}", terms, base[rail]) + 4
        top += 14
    p.heading(85, top, "2) 制動荷重・始動荷重")
    top += 25
    ea = result["longitudinal_base"]["B"]["braking_rule"] == "EA-17"
    p.text(99, top, "制動荷重および始動荷重の特性値は下式によって求める。")
    top += 22
    for label, constant, numerator in (("制動荷重", .27 if ea else .20, 1 if ea else .80),
                                       ("始動荷重", .25 if ea else .19, .95 if ea else .76)):
        _rich(p, 110, top, f"{label} ：（{constant:.2f} ＋ {numerator:.2f} / L_{{v}}" + ("）・ΣR" if ea else "・L）・T"))
        top += 17
    top += 15
    for label, key, constant, numerator in (("(a) 制動荷重", "brake", .27 if ea else .20, 1 if ea else .80),
                                            ("(b) 始動荷重", "start", .25 if ea else .19, .95 if ea else .76)):
        p.text(99, top, label)
        top += 23
        for number, side in ((1, "B"), (2, "C")):
            base = result["longitudinal_base"][side]
            terms = ([f"({constant:.2f} ＋ {numerator:.2f} / {_number(vehicle['length'])})", f" × {_number(base['train_reaction_total'])}"] if ea else
                     [f"({constant:.2f} ＋ {numerator:.2f} / {_number(vehicle['length'])} × {_number(base['length'])})", f" × {_number(vehicle['axle_load'])}"])
            top = _equation(p, top, f"T{number}", terms, base[key]) + 3
        top += 13
    p.text(99, top, "制動荷重と始動荷重の大きい値を採用して設計する。")
    top += 35
    p.heading(85, top, "3) 地震時慣性力荷重")
    _rich(p, 275, top, "K_{h}＝1.00")
    top += 23
    _rich(p, 99, top, "T ＝ (D_{1} ＋ D_{2} ＋ S_{2}) × K_{h}")
    top += 22
    for number, side, points in ((1, "B", ("A", "B")), (2, "C", ("C", "D"))):
        dead = [result["dead_loads"]["points"][point] for point in points]
        snow = [result["snow_loads"]["points"][point]["雪荷重_2年確率"] for point in points]
        _rich(p, 120, top, f"T{number}")
        p.text(153, top, "＝")
        top = _expression(p, 170, top, [f"({_number(dead[0]['D1'])} ＋ {_number(dead[1]['D1'])}",
                                        f" ＋ {_number(dead[0]['D2'])} ＋ {_number(dead[1]['D2'])}"])
        top += _LEADING
        top = _equation(p, top, "", [f"＋ {_number(snow[0])} ＋ {_number(snow[1])}) × 1.00"],
                        result["longitudinal_base"][side]["earthquake_dead"], equal_x=450) + 4
    finish_page()
    p.heading(85, 96, "4) 地震時列車荷重慣性力")
    p.text(99, 120, "線路方向の列車荷重慣性力は、車輪とレールとの粘着係数 μ＝0.20 とする。")
    top = 144.0
    for number, side in ((1, "B"), (2, "C")):
        load = result["train"]["earthquake"][f"R{side}"]
        top = _equation(p, top, f"T{number}", [f"({_number(load)} ＋ {_number(load)}) × 0.20"],
                        result["longitudinal_base"][side]["earthquake_train"]) + 4
    return top + 18


def _vertical(p: _Page, top: float, result: dict, row: dict, side: str) -> float:
    detail, combination = row[side], row["combination"]
    movable = detail["bearing"] == "可動"
    point = side if movable else ("A" if side == "B" else "D")
    value = detail["local_vertical"] if movable else detail["remote_vertical"]
    dead = result["dead_loads"]["points"][point]
    snow = result["snow_loads"]["points"][point][combination["snow_key"]]
    p.text(138, top, f"{detail['bearing']}支承に働く鉛直荷重")
    top += 18
    _rich(p, 150, top, f"R_{{m}} ＝ {_vertical_symbol(combination)}")
    top += 18
    p.text(163, top, "＝")
    dead_terms = [f"{combination['d1_factor']:.1f} × {_number(dead['D1'])}",
                  f" ＋ {combination['d2_factor']:.1f} × {_number(dead['D2'])}"]
    if not combination["live_group"]:
        dead_terms.append(f" ＋ {_number(snow)}")
    top = _expression(p, 182, top, dead_terms)
    if combination["live_group"]:
        live = result["train"]["girder"][combination["live_group"]][combination["live_track"]][f"R{point}"]
        coefficient = live["coefficient"] if combination["include_impact"] else 0
        raw = result["train"]["raw_reactions"][f"R{point}"]
        tracks = result["longitudinal_base"][side]["track_total"]
        top += _LEADING
        top = _expression(p, 182, top, [f"＋ {_coefficient(combination['effective_live_coefficient'])} × {_number(raw)}",
                                       f" × {_number(tracks, significant=6)} × (1 ＋ {_number(coefficient, 3)})",
                                       f" ＋ {_number(snow)}"])
    top += _LEADING
    p.text(163, top, "＝")
    p.text(254, top, _number(value), align="right")
    p.text(266, top, "kN")
    return top + 30


def _bearing(p: _Page, top: float, result: dict, row: dict, side: str) -> float:
    detail, base = row[side], result["longitudinal_base"][side]
    combination = row["combination"]
    number = 1 if side == "B" else 2
    p.text(110, top, f"【{'起点側' if side == 'B' else '終点側'} {side}支点】 {detail['bearing']}支点")
    top += 22
    if combination["brake_factor"] and _unfactored_ea17(result, row, side):
        _rich(p, 120, top, f"B_{{0}} ＝ {_number(detail['braking_base'])} kN （荷重修正前の制動荷重）")
        top += _LEADING
    terms = []
    if combination["lr_factor"]:
        terms.append(_number(base["LR_service"]) if combination["lr_factor"] == .8 else
                     f"{combination['lr_factor']:.1f} × {_number(base['LR'])}")
    if combination["brake_factor"]:
        coefficient = _brake_multiplier(result, row, side)
        terms.append((" ＋ " if terms else "") + f"{coefficient} × {_number(detail['braking_base'])}")
    if combination["lr_factor"] == .8 and not combination["brake_factor"]:
        _rich(p, 110, top, f"※ T{number} ＝ {_number(detail['applied'])} kN")
        top += _LEADING
    else:
        top = _equation(p, top, f"※ T{number}", terms, detail["applied"], symbol_x=110)
    line_start = top - 9
    top += 14
    top = _vertical(p, top, result, row, side)
    p.text(138, top, f"{detail['bearing']}支承に働く水平荷重")
    top += 18
    if detail["bearing"] == "可動":
        candidates = (("T / n", [f"{_number(detail['applied'])} / 2"], detail["half_applied"]),
                      ("μ ・ R_{m}", [f"{_number(detail['mu'], significant=6)} × {_number(detail['local_vertical'])}"], detail["movable_friction"]),
                      ("μ ・ T / n", [f"{_number(detail['mu'], significant=6)} × {_number(detail['half_applied'])}"], detail["movable_floor"]))
    else:
        candidates = (("T − 1/2 μ ・ R_{m}", [f"{_number(detail['applied'])} − 1/2 × {_number(detail['mu'], significant=6)}", f" × {_number(detail['remote_vertical'])}"], detail["fixed_candidate"]),
                      ("T / n", [f"{_number(detail['applied'])} / 2"], detail["half_applied"]))
    for symbol, terms, value in candidates:
        top = _equation(p, top, symbol, terms, value, symbol_x=150, equal_x=240, expression_x=258)
    p.line(115, line_start, 115, top - 7, .7)
    top += 8
    _rich(p, 110, top, "※ ∴ H ＝")
    p.text(249, top, _number(detail["force"]), align="right")
    p.text(261, top, "kN")
    return top + 33


def _case_header(p: _Page, top: float, result: dict, row: dict, number: int) -> float:
    p.heading(_LEFT, top, f"(2) 支承に働く水平荷重  {number}) {_condition(row)}")
    top += 27
    b, c = (_horizontal_terms(result, row, side) for side in ("B", "C"))
    _rich(p, 99, top, f"・{b}" if b == c else f"・起点側：{b}　　終点側：{c}")
    top += 22
    _rich(p, 110, top, f"[ {_vertical_symbol(row['combination'])} の組み合わせ ]")
    return top + 29


def _case_page(p: _Page, result: dict, row: dict, number: int,
               finish_page: Callable[[], None], *, top: float = 96) -> None:
    # Measure with the same term wrapping before drawing. A changed input may
    # move a complete support block, but never separate its T and adopted H.
    measure = SimpleNamespace(width=p.width, text=lambda *a, **k: None, line=lambda *a, **k: None)
    heights = {side: _bearing(measure, 0, result, row, side) for side in ("B", "C")}
    if top + 78 + sum(heights.values()) > 790 and 96 + 78 + sum(heights.values()) <= 790:
        finish_page()
        top = 96
    top = _case_header(p, top, result, row, number)
    for side in ("B", "C"):
        if top + heights[side] > 790:
            finish_page()
            top = _case_header(p, 96, result, row, number)
        if top + heights[side] > 790:
            raise ValueError("0600支承計算ブロックが1ページに収まりません")
        top = _bearing(p, top, result, row, side)
    finish_page()


def _earthquake_cases(p: _Page, result: dict, rows: list[dict], finish_page: Callable[[], None]) -> None:
    top = 96.0
    for row in rows:
        p.heading(_LEFT, top, f"(2) 支承に働く水平荷重  {row['case']}) {row['label']}")
        top += 30
        _rich(p, 99, top, "K_{h}＝1.00" if row["case"] == 9 else "μ＝0.20")
        top += 25
        for number, side in ((1, "B"), (2, "C")):
            detail = row[side]
            p.text(110, top, f"【{'起点側' if side == 'B' else '終点側'} {side}支点】 {detail['bearing']}支点")
            top += 21
            _rich(p, 110, top, f"※ T{number} ＝ {_number(detail['applied'])} kN")
            top += 22
            divisor = 2 if detail["bearing"] == "可動" else 1
            top = _equation(p, top, "※ ∴ H", [f"{_number(detail['applied'])} / {divisor}"], detail["force"], symbol_x=110) + 26
        top += 24
    finish_page()


def _draw_table_grid(p: _Page, xs: tuple[float, ...], top: float, height: float, rows: int) -> None:
    for x in xs:
        p.line(x, top, x, top + (rows + 1) * height, .5)
    for index in range(rows + 2):
        y = top + index * height
        p.line(xs[0], y, xs[-1], y, .5 if index in (0, 1, rows + 1) else .12)


def _draw_numeric_cell(p: _Page, xs: tuple[float, ...], column: int, y: float, text: str, *, size: float) -> None:
    left, right = xs[column], xs[column + 1]
    p.text((left + right) / 2, y, text, size=size, align="center", max_width=right - left - 4)


def _summary(p: _Page, result: dict, rows: list[dict], finish_page: Callable[[], None]) -> None:
    p.heading(_LEFT, 96, "(3) 線路方向の支承水平荷重のまとめ")
    p.text(535, 122, "単位：kN", align="right")
    xs = (60.0, 88.0, 340.0, 405.0, 470.0, 535.0)
    top, height = 135.0, 40.0
    _draw_table_grid(p, xs, top, height, len(rows))
    for index, text in enumerate(("No", "荷重組合せ", "B", "C", "合計")):
        p.text((xs[index] + xs[index + 1]) / 2, top + 25, text, align="center")
    for index, row in enumerate(rows, 1):
        y = top + index * height + 24
        for column, value in ((0, str(index)), (2, _number(row['B']['force'])),
                              (3, _number(row['C']['force'])), (4, _number(row['B']['force'] + row['C']['force']))):
            _draw_numeric_cell(p, xs, column, y, value, size=9)
        if "combination" in row:
            b, c = (_horizontal_terms(result, row, side) for side in ("B", "C"))
            snow = _SNOW_SYMBOL[row["combination"]["snow_key"]]
            _rich(p, 94, y - 7, f"{_condition(row)}　{b}" if b == c else f"{_condition(row)}　B：{b}", size=9)
            _rich(p, 94, y + 9, f"{snow}（{row['combination']['snow_key'][4:]}）" if b == c else f"　　　 C：{c}　{snow}", size=9)
        else:
            p.text(94, y, row["label"], size=9)
    finish_page()


def draw_longitudinal_report(p: _Page, result: dict, finish_page: Callable[[], None]) -> None:
    top = _introduction(p, result, finish_page)
    rows = [*result["longitudinal"], *result.get("longitudinal_snow_cases", [])]
    _case_page(p, result, rows[0], 1, finish_page, top=top)
    for number, row in enumerate(rows[1:8], 2):
        _case_page(p, result, row, number, finish_page)
    _earthquake_cases(p, result, rows[8:10], finish_page)
    for number, row in enumerate(rows[10:], 11):
        _case_page(p, result, row, number, finish_page)
    _summary(p, result, rows, finish_page)


def _transverse_support(p: _Page, top: float, result: dict, side: str) -> float:
    detail = result["transverse"][6][side]
    p.text(110, top, f"・{'起点側' if side == 'B' else '終点側'}")
    top += 22
    dead = result["dead_loads"]["points"][side]
    snow = result["snow_loads"]["points"][side]["雪荷重_2年確率"]
    top = _equation(p, top, f"H_{{{side}}}", [f"{_number(dead['D1'])} ＋ {_number(dead['D2'])}", f" ＋ {_number(snow)}"], detail["force"])
    p.text(123, top, "作用位置")
    top = _equation(p, top, "h_{s}", [], detail["height"], "m", decimals=6, symbol_x=205, equal_x=450, expression_x=465)
    p.text(123, top, "モーメント")
    top = _equation(p, top, "M", [f"{_number(detail['force'])} × {_number(detail['height'], 6)}"], detail["moment"], "kN・m", symbol_x=205, equal_x=226, expression_x=245)
    return top + 22


def draw_transverse_earthquake_report(p: _Page, result: dict, finish_page: Callable[[], None]) -> None:
    p.heading(85, 96, "(4) 地震時慣性力荷重")
    _rich(p, 110, 120, "設計水平震度　K_{h} ＝ 1.00")
    top = 148.0
    for side in ("B", "C"):
        top = _transverse_support(p, top, result, side)
    p.heading(85, top, "(5) 地震時列車荷重慣性力荷重")
    top += 24
    _rich(p, 110, top, "設計水平震度　K_{h} ＝ 0.30")
    top += 28
    vehicle = result["input"]["train"]
    for side in ("B", "C"):
        span = result["input"]["spans"][side.lower()]
        detail = result["transverse"][7][side]
        load = result["train"]["earthquake"][f"R{side}"]
        p.text(110, top, f"・{'起点側' if side == 'B' else '終点側'}")
        top += 21
        p.text(123, top, "水平力")
        top = _equation(p, top, f"H_{{{side}}}", [f"{_number(load)} × 0.30"], detail["force"], symbol_x=190, equal_x=211, expression_x=230)
        p.text(123, top, "作用位置")
        top = _equation(p, top, "y_{1}", [f"{_number(span['h1'], 3)} ＋ {_number(span['h2'], 3)}", f" ＋ {_number(span['h3'], 3)} ＋ {_number(vehicle['height_seismic'], 3)}"], detail["height"], "m", decimals=3, symbol_x=190, equal_x=211, expression_x=230)
        p.text(123, top, "モーメント")
        top = _equation(p, top, "M_{1}", [f"{_number(detail['force'])} × {_number(detail['height'], 3)}"], detail["moment"], "kN・m", symbol_x=190, equal_x=211, expression_x=230)
        top += 17
    finish_page()
    p.heading(_LEFT, 96, "(6) 支承に働く水平荷重のまとめ")
    p.text(_LEFT, 122, "力 H：kN、作用高さ h：m")
    top = 144.0
    xs = (60.0, 315.0, 370.0, 425.0, 480.0, 535.0)
    row_h = 26.0
    _draw_table_grid(p, xs, top, row_h, 8)
    for index, value in enumerate(("ケース", "B H", "B h", "C H", "C h")):
        p.text((xs[index] + xs[index + 1]) / 2, top + 17, value, align="center", size=9)
    for index, row in enumerate(result["transverse"], 1):
        y = top + index * row_h + 17
        p.text(xs[0] + 4, y, row["label"], size=9)
        values = (_number(row['B']['force']), _number(row['B']['height'], 3),
                  _number(row['C']['force']), _number(row['C']['height'], 3))
        for column, value in enumerate(values, 1):
            _draw_numeric_cell(p, xs, column, y, value, size=8.8)
    finish_page()
