"""Engineering report for canonical transverse actions and case definitions."""
from collections.abc import Iterable, Sequence
from pathlib import Path
from typing import Any

from reportlab.pdfbase import pdfmetrics
from reportlab.pdfgen.canvas import Canvas

from .frame_outline import build_outline, draw_outline, fit_frame, frame_dimensions
from .frame_model_report import draw_frame_graph
from .report import _fonts
from .transverse_report_style import _Page, _f
from .transverse_report_example2_loads import render_load_pages
from .transverse_report_example2_cases import render_case_pages

_PARTS = {"beam": "梁", "column": "柱", "footing": "フーチング"}
_ROLES = {"cap_top": "梁天端", "footing_top": "基礎天端", "footing_centroid": "基礎重心",
          "footing_bottom": "基礎底面", "h2_h3": "H2/H3", "h3_h4": "H3/H4",
          "parapet_base": "H1基部", "parapet_top": "H1上端"}


class _Report:
    def __init__(self, result: dict[str, Any], path: str | Path) -> None:
        self.result = result
        self.canvas = Canvas(str(path), pagesize=(595, 842), pageCompression=1, invariant=1)
        self.canvas.setTitle("0620 直角方向荷重")
        self.canvas.setAuthor("P7橋脚 計算プログラム")
        self.page = _Page(self.canvas, _fonts())
        self.number, self.y, self.title = 0, 100, ""

    def finish(self) -> None:
        self.number += 1
        digest = self.result["provenance"].get("input_sha256", "未指定")[:12]
        self.page.text(48, 815, f"0620 直角方向荷重　入力 SHA256: {digest}", 7)
        self.page.text(547, 815, self.number, 7, "right")
        self.canvas.showPage()

    def start(self, title: str) -> None:
        if self.title:
            self.finish()
        self.title, self.y = title, 100
        self.page.text(48, 62, title, 13, bold=True, width=499)
        self.page.line(48, 76, 547, 76, .6)

    def source_start(self, title: str | None = None) -> None:
        """Start an unboxed reference-style sheet after the existing model pages."""
        if self.title:
            self.finish()
        self.title, self.y = title or "reference", 76
        if title:
            self.page.text(76.44, 79.68, title, 9.94, bold=True)
            self.y = 106.8

    def ensure(self, height: float) -> None:
        if self.y + height > 770:
            self.start(self.title)

    def heading(self, text: str, height: float = 100) -> None:
        self.ensure(height)
        self.page.text(48, self.y, text, 10, bold=True, width=499)
        self.y += 17

    def note(self, text: object) -> None:
        line = ""
        for character in str(text):
            if line and pdfmetrics.stringWidth(line + character, self.page.fonts[0], 8.3) > 490:
                self.ensure(15)
                self.page.text(48, self.y, line, 8.3)
                self.y += 14
                line = ""
            line += character
        self.ensure(15)
        self.page.text(48, self.y, line, 8.3)
        self.y += 17

    def table(
        self,
        widths: Sequence[float],
        headers: Sequence[str],
        rows: Iterable[Sequence[object]],
        *,
        size: float = 8.7,
        row_height: float = 19,
    ) -> None:
        pending = list(rows)
        while pending:
            self.ensure(32 + row_height + 12)
            count = max(1, int((758 - self.y - 32) // row_height))
            batch, pending = pending[:count], pending[count:]
            self.y = self.page.table(48, self.y, widths, headers, batch, size=size,
                                    row_height=row_height, header_height=32) + 14
            if pending:
                self.start(self.title)


def _frame(report: _Report) -> None:
    result, p = report.result, report.page
    frame = result["frame"]
    report.start("線路直角方向　骨組図")
    outline = build_outline(result["input"]["geometry"], "w")
    layout = fit_frame(outline, frame["nodes"], (92, 135, 525, 650),
                       members=frame["members"], dimensions=frame_dimensions(frame),
                       font=p.fonts[0], font_size=9.9)
    draw_outline(p.c, outline, layout)
    draw_frame_graph(p.c, p.fonts, frame, layout)
    report.y = 698
    report.note(f"支持節点：{frame['support_node_id']}　　太線：剛域　　破線：橋脚外形")
    report.note("寸法単位：m。荷重は梁天端、基礎重心および柱の分布区間に作用する。")


def _member_rows(frame: dict[str, Any]) -> list[list[object]]:
    rows: list[list[object]] = []
    for member in frame["members"]:
        rigid = member["behavior"] == "rigid"
        section = None if rigid else frame["sections"][member["section_ref"]]
        rows.append([
            member["id"],
            f"{member['node_i']} → {member['node_j']}",
            "剛域" if rigid else _PARTS[member["material_ref"]],
            "－" if rigid else _f(section["area"], 3),
            "－" if rigid else _f(section["inertia"], 5),
        ])
    return rows


def _model(report: _Report) -> None:
    frame = report.result["frame"]
    report.start("骨組条件・材料・基礎ばね")
    report.heading("節点座標")
    report.table([43, 90, 90, 276], ["節点", "x (m)", "y (m)", "位置"],
                 [[n["id"], _f(n["x"]), _f(n["y"]), " / ".join(_ROLES[r] for r in n["roles"])]
                  for n in frame["nodes"]])
    report.heading("部材・断面")
    rows = _member_rows(frame)
    report.table([43, 90, 90, 138, 138], ["部材", "節点 i → j", "材料", "A (m²)", "I (m⁴)"], rows)
    report.heading("コンクリート")
    report.table([139, 150, 210], ["部位", "設計基準強度 (N/mm²)", "弾性係数 Ec (kN/m²)"],
                 [[_PARTS[k], _f(v["fck"], 1), f"{v['Ec']:,.0f}"] for k, v in frame["materials"].items()])
    report.heading("直接基礎ばね（線路直角方向）")
    report.table([100, 133, 133, 133], ["条件", "Kv (kN/m)", "Ks (kN/m)", "Kr (kN・m/rad)"],
                 [[label, *[f"{frame['springs'][term][k]:,.0f}" for k in ("Kv", "Ks", "Kr")]]
                  for term, label in (("long_term", "長期：1"), ("short_term", "短期：2"))])


def render_transverse_report(result: dict[str, Any], output_path: str | Path) -> None:
    if result.get("schema_version") != 2:
        raise ValueError("0620の荷重・ケース形式が対応していません")
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    report = _Report(result, path)
    _frame(report)
    _model(report)
    render_load_pages(report)
    render_case_pages(report)
    report.finish()
    report.canvas.save()
