"""Draw the reference 0600 worksheet layout using current calculation values.

The template contains typography, rules, static captions and source cell IDs.
Formula caches are intentionally absent: missing calculated display values are
reported instead of silently printing an old workbook result.
"""

from __future__ import annotations

from functools import lru_cache
from fractions import Fraction
import json
from pathlib import Path
import re
from typing import Any

from reportlab.pdfbase import pdfmetrics

from .reaction_math import excel_round


@lru_cache(maxsize=1)
def load_layout() -> dict:
    return json.loads((Path(__file__).parent / "assets/reaction_report_layout.json").read_text(encoding="utf-8"))


def missing_dynamic_cells(result: dict, overrides: dict | None = None) -> list[tuple[str, str]]:
    return missing_layout_cells(load_layout(), result, overrides)


def missing_layout_cells(layout: dict, result: dict,
                         overrides: dict | None = None) -> list[tuple[str, str]]:
    """Validate varying cells in any bundled calculation-sheet layout."""
    missing = []
    for page in layout["pages"]:
        values = {**result.get("cells", {}).get(page["sheet"], {}), **(overrides or {}).get(page["sheet"], {})}
        missing.extend((page["sheet"], cell["address"]) for cell in page["cells"]
                       if cell.get("dynamic") and cell["address"] not in values)
    return sorted(set(missing))


def format_value(value: Any, number_format: str) -> str:
    """Format the numeric patterns used by the original engineering workbook."""
    if value is None:
        return ""
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        if "@" in number_format:
            before, after = number_format.split("@", 1)
            return before.replace('"', '') + str(value) + after.replace('"', '')
        return str(value)
    sections = number_format.split(";")
    pattern = sections[1] if value < 0 and len(sections) > 1 else sections[2] if value == 0 and len(sections) > 2 else sections[0]
    pattern = re.sub(r"\[[^]]*\]", "", pattern)
    if pattern.lower() == "general":
        return f"{value:g}"
    if "/" in pattern and "?" in pattern:
        fixed = re.search(r"/([1-9][0-9]*)", pattern)
        fraction = Fraction(value).limit_denominator(int(fixed[1]) if fixed else 100)
        if fraction.denominator == 1:
            return str(fraction.numerator)
        whole = int(value)
        remainder = fraction - whole
        return (f"{whole} " if whole else "") + f"{abs(remainder.numerator) if whole else remainder.numerator}/{remainder.denominator}"
    if not re.search(r"[0#?]", pattern):
        return pattern.replace('"', '').replace("\\", "")
    # Bracketed grouping such as #,##0 is rendered with the source's comma.
    decimal = re.search(r"\.([0#?]+)", pattern)
    decimals = len(decimal.group(1)) if decimal else 0
    number = value * 100 if "%" in pattern else value
    number = excel_round(number, decimals)
    space_grouping = "#\\ ##0" in pattern
    text = f"{number:,.{decimals}f}" if "," in pattern or space_grouping else f"{number:.{decimals}f}"
    if space_grouping:
        text = text.replace(",", " ")
    if decimal and "#" in decimal.group(1):
        text = text.rstrip("0").rstrip(".")
    if "%" in pattern:
        text += "%"
    literals = re.findall(r'"([^"]*)"', pattern)
    if literals:
        text += "".join(literals)
    return text


def _inside_region(box: list, regions: list) -> bool:
    # Spreadsheet objects and their cell-based dimensions are replaced by the
    # current-input vector diagram supplied by the report's diagram layer.
    x = (box[0] + box[2]) / 2
    y = (box[1] + box[3]) / 2
    return any(left <= x <= right and top <= y <= bottom for left, top, right, bottom in regions)


def _font_name(source: dict, fonts: tuple[str, str]) -> str:
    return fonts[1] if "ゴシック" in source["name"] or "Gothic" in source["name"] else fonts[0]


def _text_width(text: str, size: float, *, halfwidth_kana: bool = False) -> float:
    return sum(.5 if ord(char) < 128 or (halfwidth_kana and '\uff61' <= char <= '\uff9f')
               else 1 for char in text) * size * (10.08 / 9.9)


def _wrapped_lines(text: str, size: float, width: float, *,
                   halfwidth_kana: bool = False) -> list[str]:
    lines = []
    for paragraph in text.splitlines():
        current = ""
        for char in paragraph:
            if current and _text_width(current + char, size, halfwidth_kana=halfwidth_kana) > width:
                # Keep a distance such as 4.975 on one line. Excel's wrapped
                # expression cells are easier to follow when a sum breaks at
                # an operator instead of through a decimal number.
                boundaries = [match.end() for match in re.finditer(r"[+＋×*/÷−\-、 )）]", current)]
                boundary = boundaries[-1] if boundaries else 0
                if boundary >= len(current) * .4:
                    lines.append(current[:boundary].rstrip())
                    current = current[boundary:].lstrip()
                else:
                    lines.append(current)
                    current = ""
            current += char
        lines.append(current)
    return lines


def _draw_text(canvas, text: str, x: float, baseline: float, source: dict,
               fonts: tuple[str, str], width: float | None = None) -> float:
    size = source["size"]
    if source["escapement"]:
        size *= 2 / 3
        baseline += 1.92 if source["escapement"] == 2 else -4.92
    desired = _text_width(text, size, halfwidth_kana=source.get("halfwidth_kana", False))
    if width and desired > width:
        size *= width / desired
        desired = width
    font = _font_name(source, fonts)
    canvas.setFillColorRGB(*(v / 255 for v in source["colour"]))
    obj = canvas.beginText(x, 842 - baseline)
    obj.setFont(font, size)
    measured = pdfmetrics.stringWidth(text, font, size)
    if measured:
        obj.setHorizScale(desired / measured * 100)
    obj.textOut(text)
    canvas.drawText(obj)
    return desired


def _draw_paths(canvas, paths: list[dict]) -> None:
    for drawing in paths:
        path = canvas.beginPath()
        for item in drawing["items"]:
            op = item[0]
            if op == "re":
                x0, y0, x1, y1 = item[1:]
                path.rect(x0, 842 - y1, x1 - x0, y1 - y0)
            elif op == "l":
                path.moveTo(item[1][0], 842 - item[1][1])
                path.lineTo(item[2][0], 842 - item[2][1])
            elif op == "c":
                path.moveTo(item[1][0], 842 - item[1][1])
                path.curveTo(*[v for point in item[2:] for v in (point[0], 842 - point[1])])
            elif op == "qu":
                path.moveTo(item[1][0], 842 - item[1][1])
                for point in (item[2], item[4], item[3]):
                    path.lineTo(point[0], 842 - point[1])
                path.close()
        if drawing["close"]:
            path.close()
        if drawing["fill"] is not None:
            canvas.setFillColorRGB(*drawing["fill"])
        if drawing["colour"] is not None:
            canvas.setStrokeColorRGB(*drawing["colour"])
        canvas.setLineWidth(drawing["width"] or .12)
        canvas.drawPath(path, stroke=drawing["colour"] is not None,
                        fill=drawing["fill"] is not None, fillMode=0 if drawing["even_odd"] else 1)


def draw_page(canvas, result: dict, page_number: int, fonts: tuple[str, str],
              overrides: dict | None = None, *,
              y_range: tuple[float, float] | None = None) -> None:
    """Draw a source page or a complete-cell band for semantic pagination."""
    layout = load_layout()
    page = layout["pages"][page_number - 1]
    draw_layout_page(canvas, result, layout, page, fonts, overrides, y_range=y_range)


def draw_layout_page(canvas, result: dict, layout: dict, page: dict,
                     fonts: tuple[str, str], overrides: dict | None = None, *,
                     y_range: tuple[float, float] | None = None) -> None:
    """Render one A4 worksheet page using its own cells, typography and paths.

    The caller supplies the bundled layout, dynamic values and any diagram
    overlay.  This keeps 0600/0610/0620 independent of the reference workbook.
    """
    report_id = layout.get("report_id", "0600")
    # New worksheet layouts can opt into Excel's halfwidth-kana metrics while
    # preserving the already issued 0600 report byte for byte.
    halfwidth_kana = layout.get("halfwidth_kana", False)
    def source_font(index):
        return {**layout["fonts"][index], "halfwidth_kana": halfwidth_kana}
    values = {**result.get("cells", {}).get(page["sheet"], {}), **(overrides or {}).get(page["sheet"], {})}
    missing = [cell["address"] for cell in page["cells"] if cell.get("dynamic") and cell["address"] not in values
               and not _inside_region(cell["box"], page["diagram_regions"])]
    if missing:
        raise ValueError(f"{report_id}帳票の表示値が不足: {page['sheet']}!{', '.join(missing)}")
    canvas.saveState()
    if y_range is not None:
        top, bottom = y_range
        clip = canvas.beginPath()
        # A small bleed keeps the full stroke of a table's boundary rule.
        clip.rect(0, 842 - bottom - .6, 595, bottom - top + 1.2)
        canvas.clipPath(clip, stroke=0, fill=0)
    canvas.setStrokeColorRGB(0, 0, 0)
    _draw_paths(canvas, page["paths"])
    canvas.setDash()
    for cell in page["cells"]:
        left, top, right, bottom = cell["box"]
        if _inside_region(cell["box"], page["diagram_regions"]):
            continue
        if y_range is not None:
            if bottom <= y_range[0] or top >= y_range[1]:
                continue
            if top < y_range[0] - .01 or bottom > y_range[1] + .01:
                raise ValueError(f"{report_id}の改ページがセルを分断しています: {page['sheet']}!{cell['address']}")
        if page["sheet"] == "直角荷重" and cell["address"] in ("F22", "F47"):
            side = "b" if cell["address"] == "F22" else "c"
            span = result.get("input", {}).get("spans", {}).get(side, {})
            if span.get("radius", 0) > 0:
                continue
        value = values.get(cell["address"], cell.get("value"))
        if cell.get("blank_zero") and value == 0:
            continue
        style = layout["styles"][cell["style"]]
        font = source_font(style["font"])
        text = format_value(value, style["format"])
        if not text:
            continue
        lines = _wrapped_lines(text, font["size"], max(1, right - left - 1.68),
                               halfwidth_kana=halfwidth_kana) if style["wrap"] else text.splitlines()
        leading = font["size"] * 1.13
        baseline = bottom - 2.16 - (len(lines) - 1) * leading
        if style["vertical"] == 0:
            baseline = top + font["size"] - .66
        elif style["vertical"] == 1:
            baseline = (top + bottom) / 2 + font["size"] * .37 - (len(lines) - 1) * leading / 2
        numeric = isinstance(value, (int, float))
        align = style["horizontal"] or (3 if numeric else 1)
        for line in lines:
            width = _text_width(line, font["size"], halfwidth_kana=halfwidth_kana)
            right_inset = 2.76 if numeric and "_" in style["format"] else .84
            max_width = max(1, right - left - .84 - right_inset) if style["shrink"] or numeric else None
            if max_width is not None:
                width = min(width, max_width)
            xx = right - right_inset - width if align == 3 else (left + right - width) / 2 if align == 2 else left + .84 + style.get("indent", 0) * 10.08
            runs = cell.get("runs") if isinstance(value, str) and value == cell.get("value") and len(lines) == 1 else None
            if runs:
                entries = list(runs)
                if entries[0][0] != 0:
                    entries.insert(0, [0, style["font"]])
                for index, (offset, font_index) in enumerate(entries):
                    end = entries[index + 1][0] if index + 1 < len(entries) else len(line)
                    xx += _draw_text(canvas, line[offset:end], xx, baseline, source_font(font_index), fonts)
            else:
                _draw_text(canvas, line, xx, baseline, font, fonts, max_width)
            baseline += leading
    canvas.restoreState()
