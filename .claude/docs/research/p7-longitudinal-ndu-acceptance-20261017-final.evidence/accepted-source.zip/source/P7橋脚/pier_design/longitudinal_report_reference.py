"""Reference-style 0610 typography and current-input vector drawings."""

from __future__ import annotations

from functools import lru_cache
import json
from pathlib import Path

from reportlab.pdfgen.canvas import Canvas

from .frame_outline import build_outline, draw_outline, fit_frame, frame_dimensions
from .frame_model_report import draw_frame_graph, draw_model_conditions
from .reaction_report_layout import draw_layout_page, format_value, missing_layout_cells
from .report import _Page, _fonts


@lru_cache(maxsize=1)
def load_layout() -> dict:
    return json.loads((Path(__file__).parent / "assets/longitudinal_report_layout.json").read_text(encoding="utf-8"))


def _source_page(canvas, result, fonts, number, overrides):
    layout = load_layout()
    draw_layout_page(canvas, result, layout, layout["pages"][number - 1], fonts, overrides)


def _band(canvas, result, fonts, number, first_row, last_row, target_top, overrides):
    """Move a complete semantic group without scaling its type or rules."""
    layout = load_layout()
    page = layout["pages"][number - 1]
    top, bottom = page["rows"][str(first_row)], page["rows"][str(last_row + 1)]
    canvas.saveState()
    canvas.translate(0, top - target_top)
    draw_layout_page(canvas, result, layout, page, fonts, overrides, y_range=(top, bottom))
    canvas.restoreState()
    return target_top + bottom - top


def _frame(p: _Page, result: dict) -> None:
    frame = result["frame"]
    outline = build_outline(result["input"]["geometry"], "b")
    layout = fit_frame(outline, frame["nodes"], (102.0, 232.0, 535.0, 676.0),
                       members=frame["members"], dimensions=frame_dimensions(frame),
                       font=p.fonts[0], font_size=9.9)
    draw_outline(p.canvas, outline, layout)
    draw_frame_graph(p.canvas, p.fonts, frame, layout)
    p.text(117, 725, "寸法の単位：m。骨組は現在の実節点・部材接続に対応する。", size=8.7)
    p.text(117, 741, f"太線は剛域。基礎底面の支持節点ID: {frame['support_node_id']}。", size=8.7)


def _basic_notes(p, result):
    p.heading(102.6, 552, "計算条件・出典")
    lines = (
        "本計算書は線路方向の荷重条件と設計作用の組合せ係数を示す。",
        "構造解析による変位・断面力の算定および部材照査は含まない。",
        ("基本ケース 1〜21、躯体 12 列・基礎 8 列に続き、S30の3基本ケース・4組合せを示す。"
         if len(result["basic_cases"]) == 24 else "基本ケース 1〜21 と、躯体 12 列・基礎 8 列の全係数を以下に示す。"),
        "ばね番号 3 は地震時の原表分類であり、第 3 のばね定数は算定しない。",
        "0500 のばねと 0600 の自重・列車・衝撃・水平力には転記時の Single 値を用いる。",
        "荷重計算中の分布荷重 ω2〜ω7 と浮力の分布式は元式の参考値で、直接基礎には採用しない。",
        "入力・元セルの全精度値と転記元は、同名の結果 JSON に保持する。",
        "出典：" + result["provenance"]["source_workbook"],
    )
    for index, line in enumerate(lines):
        p.text(117, 578 + 17 * index, line, size=8.5, max_width=415)
    if any("サンプル" in warning for warning in result.get("warnings", [])):
        p.text(117, 727, "入力はサンプル条件であり、実 P7 条件への置換は別途必要。", size=8.5)


def _table_text(p, x0, x1, top, bottom, text, *, size=9.9, align="center", red=False):
    lines = text.splitlines()
    leading = size * 1.13
    baseline = (top + bottom) / 2 + size * .37 - (len(lines) - 1) * leading / 2
    for line in lines:
        x = (x0 + x1) / 2 if align == "center" else x0 + 2
        p.text(x, baseline, line, size=size, align=align,
               max_width=x1 - x0 - 4, color=(1, 0, 0) if red else (0, 0, 0))
        baseline += leading


def _matrix(p, result, scope):
    selected = [case for case in result["combinations"] if case["scope"] == scope and case["source_column"] is not None]
    expected = 12 if scope == "body" else 8
    rows = len(result["basic_cases"])
    if rows not in (21, 24) or len(selected) != expected or any(len(case["coefficients"]) != rows for case in selected):
        raise ValueError(f"0610 {scope}の組合せ係数は21行×{expected}列が必要です")
    title = "躯体" if scope == "body" else "基礎"
    p.heading(87.96, 97.8, "(4) 設計作用の組合せ")
    p.heading(102.48, 126.36, f"2) 組合せケース（{title}）")
    left, top, row_h, header_h = 58.08, 143.4, 14.28, 57.12
    no_width, name_width = 25.0, 151.0
    coefficient_width = (496 - no_width - name_width) / len(selected)
    divider = left + no_width + name_width
    right, body_top = left + 496, top + header_h
    bottom = body_top + 21 * row_h
    for x in (left, left + no_width, divider, right):
        p.line(x, top, x, bottom, .75 if x in (left, divider, right) else .12)
    for y in (top, body_top, bottom):
        p.line(left, y, right, y, .75)
    for index in range(1, 21):
        p.line(left, body_top + index * row_h, right, body_top + index * row_h, .12)
    for index in range(1, len(selected)):
        p.line(divider + index * coefficient_width, top, divider + index * coefficient_width, bottom, .12)
    for index in range(1, 4):
        p.line(divider, top + index * row_h, right, top + index * row_h, .12)
    _table_text(p, left, left + no_width, top, body_top, "No", size=9.2)
    _table_text(p, left + no_width, divider, top, body_top, "荷重名称")
    for index, case in enumerate(selected):
        xx = divider + index * coefficient_width
        _table_text(p, xx, xx + coefficient_width, top, top + row_h, str(case["id"]), size=9.2)
    if scope == "body":
        groups = ((0, 6, "安全性", "破壊"), (6, 10, "使用性・耐久性", ""), (10, 12, "復旧性", "損傷"))
        subgroups = ((6, 8, "永久＋変動"), (8, 9, "永久\n作用"), (9, 10, "変動\n作用"))
        circles = {**{i: "①②③④⑤⑥"[i] for i in range(6)}, 10: "①", 11: "②"}
    else:
        groups = ((0, 4, "安全性", "安定"), (4, 7, "使用性", ""), (7, 8, "復旧性", "地震時"))
        subgroups = ((4, 6, "短期支持"), (6, 7, "長期\n支持"))
        circles = {i: "①②③④"[i] for i in range(4)}
    for first, last, name, subtype in groups:
        x0, x1 = divider + first * coefficient_width, divider + last * coefficient_width
        p.canvas.setFillColorRGB(1, 1, 1)
        p.canvas.rect(x0 + .5, 842 - (top + 3 * row_h) + .5,
                      x1 - x0 - 1, 2 * row_h - 1, stroke=0, fill=1)
        for yy in (top + row_h, top + 2 * row_h, top + 3 * row_h):
            p.line(x0, yy, x1, yy, .12)
        p.line(x0, top, x0, bottom, .65 if first else .75)
        _table_text(p, x0, x1, top + row_h, top + 2 * row_h, name, size=8.8)
        if subtype:
            _table_text(p, x0, x1, top + 2 * row_h, top + 3 * row_h, subtype, size=8.6)
    for first, last, label in subgroups:
        x0, x1 = divider + first * coefficient_width, divider + last * coefficient_width
        # These headings span both lower header rows; the common row rule
        # must not cross their text or leave a divider inside a merged cell.
        p.canvas.setFillColorRGB(1, 1, 1)
        p.canvas.rect(x0 + .4, 842 - body_top + .4,
                      x1 - x0 - .8, 2 * row_h - .8, stroke=0, fill=1)
        _table_text(p, x0, x1, top + 2 * row_h, body_top, label, size=8.4)
        p.line(x0, top + 2 * row_h, x0, body_top, .12)
        p.line(x1, top + 2 * row_h, x1, body_top, .12)
    for index, label in circles.items():
        xx = divider + index * coefficient_width
        _table_text(p, xx, xx + coefficient_width, top + 3 * row_h, body_top, label, size=9.1)
    for row, basic in enumerate(result["basic_cases"][:21]):
        yy = body_top + row * row_h
        _table_text(p, left, left + no_width, yy, yy + row_h, str(basic["id"]), size=9.1)
        _table_text(p, left + no_width, divider, yy, yy + row_h, basic["label"], align="left", size=9.2)
        for index, case in enumerate(selected):
            value = case["coefficients"][row]
            xx = divider + index * coefficient_width
            _table_text(p, xx, xx + coefficient_width, yy, yy + row_h,
                        "" if value == 0 else format_value(value, "0.00"), size=9.1, red=True)
    p.text(87.96, bottom + 29, "空欄は係数 0。基本ケースの条件・線数・ばね区分は前記の一覧による。", size=8.5)
    mapping = "元表列：" + "、".join(f"{case['id']} [{case['source_column']}]" for case in selected)
    p.text(87.96, bottom + 45, mapping, size=7.8, max_width=460)
    if scope == "foundation":
        for index, text in enumerate((
            "地震時以外の安全性に関する基礎の安定照査および不静定構造物における",
            "上部構造物の破壊の照査については、地盤・基礎部材等の非線形を無視した",
            "線形モデルによる構造解析の係数 γa を 1.2 とする（元表の記載）。",
            "ここでは組合せ係数を示し、γa の暗黙乗算や構造応答の算定は行っていない。",
        )):
            p.text(87.96, bottom + 79 + index * 16, text, size=8.7)


def _snow_cases(p, result):
    selected = [case for case in result["combinations"] if case["source_column"] is None]
    if len(result["basic_cases"]) != 24 or len(selected) != 4 or any(len(case["coefficients"]) != 24 for case in selected):
        raise ValueError("0610 S30追加組合せは24行×4列が必要です")
    p.heading(58.08, 97.8, "(5) 雪荷重30年 S30 と LR単独の追加ケース")
    p.text(58.08, 121, "Example橋脚2/07 7-10・7-12。列車・衝撃・水位荷重を含まない。", size=9.0)
    p.text(58.08, 139, "鉛直荷重はDouble、水平荷重は0600のSingle転記値。構造解析・断面照査は含まない。", size=8.5)
    snow = result["vertical"]["snow30"]
    p.heading(58.08, 164, "追加基本ケース（力:kN、距離:m、モーメント:kN m）")
    for index, side in enumerate(("B", "C")):
        row = snow[side]
        p.text(73, 184 + 17 * index,
               f"22 雪荷重30年 S30  {side}: N={row['N']:.2f}, arm={row['arm']:.3f}, M={row['M']:.2f}", size=9.0)
    p.text(73, 218, f"合計 N={snow['N']:.2f}, M={snow['M']:.2f}（各支点Mを小数2桁に丸めて合計）", size=9.0)
    for index, basic in enumerate(result["basic_cases"][22:]):
        loads = basic["loads"]
        p.text(73, 238 + 18 * index,
               f"{basic['id']} {basic['label']}  H_B={loads['B']:.2f}, H_C={loads['C']:.2f}, 合計={loads['total']:.2f}", size=9.0)
    p.text(58.08, 281, "追加4組合せの全係数（既存20組合せの追加3行はすべて0）。ばね区分は1。", size=8.8)
    left, top, row_h, header_h = 58.08, 298.0, 17.0, 42.0
    no_w, label_w, coefficient_w = 25.0, 191.0, 70.0
    divider, right = left + no_w + label_w, left + 496
    body_top, bottom = top + header_h, top + header_h + 24 * row_h
    for x in (left, left + no_w, divider, *(divider + coefficient_w * i for i in range(1, 5))):
        p.line(x, top, x, bottom, .55)
    for y in (top, body_top, *(body_top + row_h * i for i in range(1, 25))):
        p.line(left, y, right, y, .45 if y in (top, body_top, bottom) else .12)
    _table_text(p, left, left + no_w, top, body_top, "No", size=9.0)
    _table_text(p, left + no_w, divider, top, body_top, "基本ケース", size=9.0)
    for column, case in enumerate(selected):
        x = divider + column * coefficient_w
        scope = "躯体" if case["scope"] == "body" else "基礎"
        condition = case["title"].split(" ", 1)[0]
        _table_text(p, x, x + coefficient_w, top, body_top, f"{scope} {case['id']}\n{condition}\nLR + S30", size=8.8)
    for index, basic in enumerate(result["basic_cases"]):
        y = body_top + index * row_h
        _table_text(p, left, left + no_w, y, y + row_h, str(basic["id"]), size=9.0)
        _table_text(p, left + no_w, divider, y, y + row_h, basic["label"], size=9.0, align="left")
        for column, case in enumerate(selected):
            x = divider + column * coefficient_w
            _table_text(p, x, x + coefficient_w, y, y + row_h,
                        format_value(case["coefficients"][index], "0.00"), size=9.0)


def _footer(p, result, page):
    digest = result["provenance"].get("input_sha256", "未指定")[:12]
    p.text(58.08, 811, f"0610 線路方向荷重　入力 SHA256: {digest}", size=7.5)
    p.text(554.08, 811, f"- {page} -", align="right", size=8)


def render_longitudinal_report(result: dict, output_path: str | Path) -> None:
    """Render semantic pages, inserting model continuations as necessary."""
    layout = load_layout()
    missing = missing_layout_cells(layout, result)
    if missing:
        raise ValueError(f"0610帳票の表示値が不足: {missing}")
    fonts = _fonts()
    overrides = {"骨組図": {"B26": "§7. 線路方向の荷重計算", "F105": "(c) 弾性係数"}}
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    canvas = Canvas(str(path), pagesize=(595, 842), pageCompression=1, invariant=1)
    canvas.setTitle("0610 線路方向荷重")
    canvas.setAuthor("P7橋脚 計算プログラム")
    p = _Page(canvas, fonts)
    output_page = 0

    def finish_page() -> None:
        nonlocal output_page
        output_page += 1
        _footer(p, result, output_page)
        canvas.showPage()

    _source_page(canvas, result, fonts, 1, overrides)
    _frame(p, result)
    finish_page()
    draw_model_conditions(canvas, result, fonts, finish_page)
    for source in (4, 5, 6, 7):
        _source_page(canvas, result, fonts, source, overrides)
        finish_page()
    _source_page(canvas, result, fonts, 8, overrides)
    _basic_notes(p, result)
    finish_page()
    for scope in ("body", "foundation"):
        _matrix(p, result, scope)
        finish_page()
    if len(result["basic_cases"]) > 21:
        _snow_cases(p, result)
        finish_page()
    canvas.save()
