"""Extend the opening dead/snow-load blocks without changing the source layout.

Existing cells keep their Excel addresses. Snow rows have no workbook address:
their labels and numbers are drawn directly from the calculated snow result.
"""

from __future__ import annotations

from copy import deepcopy
from decimal import Decimal, ROUND_HALF_UP, localcontext
from typing import Any

from reportlab.pdfgen.canvas import Canvas

from .reaction_inputs import SNOW_LOAD_CASES
from .reaction_math import VBA_SINGLE_MAX
from .reaction_report_layout import (
    _draw_paths,
    _draw_text,
    _text_width,
    draw_layout_page,
    format_value,
    load_layout,
)


SNOW_PAGE_BANDS = (
    ((1, 85.68, 537.96),),
    ((1, 552.24, 759.96), (2, 71.4, 116.04)),
)
SNOW_EXTRA_HEIGHT = (3 * 14.28 + 6 * 14.88, 6 * 14.88)
GIRDER_COLUMNS_PER_TABLE = 5
GIRDER_COLUMN_WIDTH = 43.56


def _source_page(page_number: int, top: float) -> dict[str, Any]:
    """Join complete source bands in a private, per-render page copy."""
    layout = load_layout()
    page: dict[str, Any] = {"sheet": "死荷重", "cells": [], "paths": [],
                            "diagram_regions": []}
    cursor = top
    for source_number, start, end in SNOW_PAGE_BANDS[page_number - 1]:
        source = layout["pages"][source_number - 1]
        displacement = cursor - start
        for original in source["cells"]:
            left, cell_top, right, bottom = original["box"]
            if cell_top >= start - .01 and bottom <= end + .01:
                cell = deepcopy(original)
                cell["box"] = [left, cell_top + displacement, right, bottom + displacement]
                if cell["address"] == "C5":
                    cell["value"] = "6.1 死荷重・雪荷重"
                page["cells"].append(cell)
        # The source tables use filled rectangles for both thin and thick rules.
        # Keep their small boundary bleed so adjacent source pages join cleanly.
        for original in source["paths"]:
            items = []
            for operation, left, y0, right, y1 in original["items"]:
                if operation != "re":
                    raise ValueError("0600死荷重表の罫線形式が変わっています")
                if y1 < start - .6 or y0 > end + .6:
                    continue
                items.append([operation, left, max(y0, start - .6) + displacement,
                              right, min(y1, end + .6) + displacement])
            if items:
                page["paths"].append({**deepcopy(original), "items": items})
        cursor += end - start
    return page


def _insertions(page_number: int, top: float) -> tuple[tuple[float, float], ...]:
    if page_number == 1:
        return tuple((top + boundary - 85.68, height)
                     for boundary, height in ((228.48, 42.84), (374.28, 44.64),
                                               (493.32, 44.64)))
    return ((top + 640.92 - 552.24, 44.64), (top + 759.96 - 552.24, 44.64))


def _select_girder_columns(page: dict[str, Any], header_row: int,
                           columns: tuple[int, ...]) -> None:
    """Compact configured columns in one five-girder table, keeping cell IDs."""
    cells = {cell["address"]: cell for cell in page["cells"]}
    top = cells[f"M{header_row}"]["box"][1]
    bottom = cells[f"M{header_row + 6}"]["box"][3]
    removed_width = (GIRDER_COLUMNS_PER_TABLE - len(columns)) * GIRDER_COLUMN_WIDTH
    shifts = {column: (column - index) * GIRDER_COLUMN_WIDTH
              for index, column in enumerate(columns)}
    selected = []
    for cell in page["cells"]:
        row = int(cell["address"].lstrip("ABCDEFGHIJKLMNOPQRSTUVWXYZ"))
        if not header_row - 1 <= row <= header_row + 6:
            selected.append(cell)
            continue
        if not columns:
            continue
        box = cell["box"]
        if row == header_row - 1:  # Unit, aligned to the table's right edge.
            box[0] -= removed_width
            box[2] -= removed_width
        elif row == header_row:
            box[2] -= removed_width  # Merged B/C support caption.
        elif box[0] >= 217.8:
            column = round((box[0] - 217.8) / GIRDER_COLUMN_WIDTH)
            if column not in shifts:
                continue
            box[0] -= shifts[column]
            box[2] -= shifts[column]
        selected.append(cell)
    page["cells"] = selected
    for path in page["paths"]:
        items = []
        for item in path["items"]:
            if not (top - .6 <= item[2] and item[4] <= bottom + .6):
                items.append(item)
                continue
            if not columns:
                continue
            if item[3] - item[1] > 1.2:  # Horizontal rules.
                if item[3] > 434:
                    item[3] -= removed_width
            elif item[1] > 434:  # Right outer border.
                item[1] -= removed_width
                item[3] -= removed_width
            elif item[1] > 217.8:
                # Compact columns are equally wide; retain their separators.
                divider = round((item[1] - 260.4) / GIRDER_COLUMN_WIDTH)
                if divider >= len(columns) - 1:
                    continue
            items.append(item)
        path["items"] = items


def _extend_page(page: dict[str, Any], insertions: tuple[tuple[float, float], ...]) -> None:
    for cell in page["cells"]:
        box = cell["box"]
        displacement = sum(height for boundary, height in insertions if box[1] >= boundary - .01)
        box[1] += displacement
        box[3] += displacement
    for drawing in page["paths"]:
        for item in drawing["items"]:
            y0, y1 = item[2], item[4]
            if y1 - y0 <= 1.2:
                # Move an existing boundary rule below the new rows.
                displacement = sum(height for boundary, height in insertions
                                   if (y0 + y1) / 2 >= boundary - .6)
                item[2] += displacement
                item[4] += displacement
            else:
                # The .6 pt tolerance includes the source's half-stroke insets.
                item[2] += sum(height for boundary, height in insertions if y0 >= boundary - .6)
                item[4] += sum(height for boundary, height in insertions if y1 >= boundary - .6)


def _draw_cell(canvas: Canvas, layout: dict, template: dict, value: str | float,
               top: float, height: float, fonts: tuple[str, str]) -> None:
    left, _, right, _ = template["box"]
    style = layout["styles"][template["style"]]
    font = layout["fonts"][style["font"]]
    numeric = isinstance(value, (int, float))
    if numeric:
        # A valid snow reaction can exceed Decimal's default 28 digits. Keep
        # the existing one-decimal/Excel rounding inside a private context.
        with localcontext() as context:
            context.prec = max(context.prec, Decimal(str(value)).adjusted() + 3)
            if abs(value) > VBA_SINGLE_MAX:
                normalized = Decimal(format(value, ".15g"))
                text = format(normalized.quantize(Decimal("0.1"), rounding=ROUND_HALF_UP), ".1f")
            else:
                text = format_value(value, style["format"])
            if text in ("inf", "-inf"):
                # Excel's 15-digit normalization can round float.max just
                # above the float range. Avoid that final float round-trip.
                normalized = Decimal(format(value, ".15g"))
                text = format(normalized.quantize(Decimal("0.1"), rounding=ROUND_HALF_UP), ".1f")
    else:
        text = format_value(value, style["format"])
    inset = 2.76 if numeric and "_" in style["format"] else .84
    if numeric:
        # These original table styles all right-align numeric values.
        width = min(_text_width(text, font["size"]), right - left - .84 - inset)
        x = right - inset - width
    else:
        x = left + .84 + style.get("indent", 0) * 10.08
    _draw_text(canvas, text, x, top + height - 2.16, font, fonts,
               max(1, right - x - inset))


def _girder_page(result: dict, page_number: int,
                 top: float) -> tuple[dict[str, Any], dict[int, tuple[int, ...]]]:
    """Select the configured columns before measuring or drawing a page."""
    page = _source_page(page_number, top)
    side = "B" if page_number == 1 else "C"
    slots = result["dead_loads"]["slots"][side]
    visible = {}
    header_rows = (19, 27) if page_number == 1 else (37, 45)
    for start, row in zip((0, GIRDER_COLUMNS_PER_TABLE), header_rows):
        columns = tuple(column for column in range(GIRDER_COLUMNS_PER_TABLE)
                        if slots[start + column]["position"] is not None)
        visible[start] = columns
        _select_girder_columns(page, row, columns)
    return page, visible


def snow_page_height(result: dict, page_number: int) -> float:
    """Height through the final visible row, including inserted snow rows."""
    page, _ = _girder_page(result, page_number, 0)
    _extend_page(page, _insertions(page_number, 0))
    return max(cell["box"][3] for cell in page["cells"])


def draw_snow_page(canvas: Canvas, result: dict, page_number: int,
                   fonts: tuple[str, str], overrides: dict, *, top: float) -> None:
    """Draw one complete support/girder page using calculated values only."""
    layout = load_layout()
    page, visible = _girder_page(result, page_number, top)
    templates = {cell["address"]: deepcopy(cell) for cell in page["cells"]}
    insertions = _insertions(page_number, top)
    _extend_page(page, insertions)
    local_overrides = {**overrides, "死荷重": {**overrides.get("死荷重", {}),
                                            "C5": "6.1 死荷重・雪荷重"}}
    draw_layout_page(canvas, result, layout, page, fonts, local_overrides)
    blocks = (("E12", ("J10", "N10", "R10", "V10", "Z10", "AD10"), "", 0),
              ("F22", ("M22", "P22", "S22", "V22", "Y22"), "B", 0),
              ("F30", ("M30", "P30", "S30", "V30", "Y30"), "B", 5)) if page_number == 1 else (
              ("F40", ("M40", "P40", "S40", "V40", "Y40"), "C", 0),
              ("F48", ("M48", "P48", "S48", "V48", "Y48"), "C", 5))
    snow = result.get("snow_loads", {})
    displacement = 0.0
    for (boundary, extra), (label_address, addresses, side, start) in zip(insertions, blocks):
        columns = visible[start] if side else tuple(range(6))
        if not columns:
            displacement += extra
            continue
        row_height = extra / len(SNOW_LOAD_CASES)
        row_top = boundary + displacement
        label_template = templates[label_address]
        left = 115.68 if side else 100.68
        right = (435.12 - (GIRDER_COLUMNS_PER_TABLE - len(columns)) * GIRDER_COLUMN_WIDTH
                 if side else 521.88)
        for index, (key, label) in enumerate(SNOW_LOAD_CASES):
            y = row_top + index * row_height
            _draw_paths(canvas, [{"items": [["re", left, y - .002, right, y + .118]],
                                  "fill": [0, 0, 0], "colour": None, "width": None,
                                  "close": None, "even_odd": False}])
            _draw_cell(canvas, layout, label_template, label, y, row_height, fonts)
            for column in columns:
                address = addresses[column]
                if side:
                    slots = snow.get("slots", {}).get(side, ())
                    value = slots[start + column].get(key, 0) if len(slots) > start + column else 0
                else:
                    point = ("A", "B", "C", "D", "AB", "CD")[column]
                    group = "points" if column < 4 else "girders"
                    value = snow.get(group, {}).get(point, {}).get(key, 0)
                _draw_cell(canvas, layout, templates[address], value, y, row_height, fonts)
        displacement += extra
