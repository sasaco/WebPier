"""Example2-style 0610 pages drawn solely from the canonical calculation result."""

from __future__ import annotations

from pathlib import Path
import re

from reportlab.pdfbase import pdfmetrics
from reportlab.pdfgen.canvas import Canvas

from .frame_model_report import draw_frame_graph
from .frame_outline import build_outline, draw_outline, fit_frame, frame_dimensions
from .report import _fonts


_PART = {"beam": "梁", "column": "柱", "footing": "フーチング"}
_REGION = {"h1": "H1", "h2": "H2", "h3": "H3", "h4": "H4",
           "footing_top_to_centroid": "基礎天端～重心", "footing_centroid_to_bottom": "基礎重心～底面",
           "parapet_arm": "H1水平アーム"}
_ROLE = {"cap_top": "梁天端", "footing_top": "基礎天端", "footing_centroid": "基礎重心",
         "footing_bottom": "基礎底面", "h2_h3": "H2/H3", "h3_h4": "H3/H4",
         "parapet_base": "H1基部", "parapet_top": "H1上端"}


def _f(value, places=2):
    return f"{value:,.{places}f}"


class _Page:
    def __init__(self, canvas, fonts, *, height=842):
        self.canvas, self.fonts, self.height = canvas, fonts, height

    def text(self, x, y, value, *, size=9.9, align="left", heading=False):
        canvas = self.canvas
        canvas.setFillGray(0)
        canvas.setFont(self.fonts[1 if heading else 0], size)
        method = {"left": canvas.drawString, "center": canvas.drawCentredString,
                  "right": canvas.drawRightString}[align]
        method(x, self.height - y, str(value))

    def line(self, x1, y1, x2, y2, width=0.3):
        self.canvas.setStrokeGray(0)
        self.canvas.setLineWidth(width)
        self.canvas.line(x1, self.height - y1, x2, self.height - y2)

    def heading(self, y, title):
        self.text(40, y, title, size=11, heading=True)

    def wrapped(self, text, width, *, size=9.9):
        lines = []
        for paragraph in str(text).split("\n"):
            line = ""
            for char in paragraph:
                if line and pdfmetrics.stringWidth(line + char, self.fonts[0], size) > width:
                    lines.append(line)
                    line = ""
                line += char
            lines.append(line)
        return lines

    def note(self, y, text, *, x=40, width=515):
        lines = self.wrapped(text, width)
        for index, line in enumerate(lines):
            self.text(x, y + 13 * index, line)
        return y + 13 * len(lines)

    def table(self, y, widths, headers, rows, *, x=40, row_height=21):
        xs = [x]
        for width in widths:
            xs.append(xs[-1] + width)
        for row_index, row in enumerate((headers, *rows)):
            wrapped = [self.wrapped(value, width - 8) for value, width in zip(row, widths, strict=True)]
            height = max(row_height, max(map(len, wrapped)) * 11.5 + 7)
            if y + height > 790:
                raise ValueError("0610帳票: 可読な表の高さがページ内に収まりません")
            self.line(xs[0], y, xs[-1], y)
            for xx in xs:
                self.line(xx, y, xx, y + height)
            for column, lines in enumerate(wrapped):
                numeric = re.fullmatch(r"[-+]?\d[\d,.]*", str(row[column])) is not None
                for index, line in enumerate(lines):
                    self.text(xs[column + 1] - 4 if numeric else xs[column] + 4,
                              y + 13 + index * 11.5, line, align="right" if numeric else "left",
                              heading=row_index == 0)
            y += height
        self.line(xs[0], y, xs[-1], y)
        return y


def _model(p, result):
    frame = result["frame"]
    p.heading(78, "1. 骨組モデル・支持ばね（線路方向）")
    outline = build_outline(result["input"]["geometry"], "b")
    layout = fit_frame(outline, frame["nodes"], (65, 100, 535, 500),
                       members=frame["members"], dimensions=frame_dimensions(frame), font=p.fonts[0], font_size=9.9)
    draw_outline(p.canvas, outline, layout)
    draw_frame_graph(p.canvas, p.fonts, frame, layout)
    p.note(528, f"支持節点 {frame['support_node_id']} ：基礎底面。太線は剛域、寸法・節点座標の単位は m。")
    p.heading(565, "支持ばね：線路方向・正規 Double 値")
    p.table(580, (75, 145, 145, 150), ("区分", "Kv (kN/m)", "Ks (kN/m)", "Kr (kN m/rad)"),
            [["長期" if term == "long_term" else "短期", *[_f(value[key], 0) for key in ("Kv", "Ks", "Kr")]]
             for term, value in frame["springs"].items()])
    p.note(676, "0500の長期・短期の正規値を、線路方向の支持節点へ接続する。")
    p.note(702, "本書は作用・骨組条件と非地震の組合せを示す。構造解析・断面照査は含まない。")


def _conditions(p, result):
    frame = result["frame"]
    p.heading(78, "2. 断面・材料および実節点・部材")
    y = p.table(95, (175, 155, 185), ("材料", "f'ck (N/mm2)", "Ec (kN/m2)"),
                [[_PART[key], _f(value["fck"], 1), _f(value["Ec"], 0)] for key, value in frame["materials"].items()])
    y = p.note(y + 18, "Ecは部位別強度に応じたRcDan表の補間値。フーチングは入力強度を表示し剛域として扱う。")
    y = p.table(y + 10, (125, 85, 85, 105, 115), ("断面", "幅 (m)", "高さ (m)", "A (m2)", "I (m4)"),
                [[key, _f(value["width"], 3), _f(value["depth"], 3), _f(value["area"], 3), _f(value["inertia"], 5)]
                 for key, value in frame["sections"].items()], row_height=19)
    y = p.table(y + 15, (45, 90, 90, 290), ("節点", "x (m)", "y (m)", "役割"),
                [[node["id"], _f(node["x"], 3), _f(node["y"], 3), " / ".join(_ROLE[role] for role in node["roles"])]
                 for node in frame["nodes"]], row_height=18.5)
    y = p.table(y + 15, (35, 40, 40, 145, 55, 95, 105), ("部材", "始点", "終点", "区間", "挙動", "断面", "材料"),
                [[m["id"], m["node_i"], m["node_j"], _REGION[m["region"]],
                  "剛域" if m["behavior"] == "rigid" else "弾性", m["section_ref"] or "－",
                  _PART.get(m["material_ref"], "－")] for m in frame["members"]], row_height=18.5)
    y = p.note(y + 18, "H2/H3＝梁、H4＝柱。H1は専用材料入力がないため柱材料を継承する。")
    p.note(y + 2, "フーチングとH1水平アームは剛域。部材の自重は重複して自動加算しない。")


def _dead_water(p, result):
    v = result["vertical"]
    detail = result["calculation_details"]["fixed"]
    p.heading(78, "8.2 作用の計算")
    p.heading(105, "(1) 固定死荷重 D1")
    p.text(55, 127, f"柱分布　q = {_f(v['fixed']['column']['intensity'])} kN/m")
    p.text(55, 145, f"フーチング　P = {_f(v['fixed']['footing']['N'])} kN、M = {_f(v['fixed']['footing']['M'])} kN m")
    for x, label in ((310, "鉛直力 N (kN)"), (425, "アーム (m)"), (550, "モーメント (kN m)")):
        p.text(x, 171, label, align="right")
    for index, (key, label) in enumerate((("B", "起点側 B"), ("C", "終点側 C"),
                                           ("pedestal", "桁受け"), ("beam", "はり等（0600集約）"))):
        c, y = detail["components"][key], 190 + 18 * index
        p.text(65, y, label)
        for x, field, places in ((310, "N", 2), (425, "arm", 3), (550, "M", 2)):
            p.text(x, y, _f(c[field], places), align="right")
    p.line(60, 251, 555, 251, width=0.5)
    p.text(65, 269, "合計")
    p.text(310, 269, _f(detail["sum_N"]), align="right")
    p.text(550, 269, _f(detail["sum_M"]), align="right")
    d = detail["column_deduction"]
    p.text(65, 294, f"鉛直力　N = {_f(detail['sum_N'])} − {_f(d['intensity'])} × {_f(d['length'], 3)} = {_f(detail['adopted_top']['N'])} kN")
    p.text(65, 312, f"モーメント　M = {_f(detail['adopted_top']['M'])} kN m")
    p.text(65, 330, f"柱控除長 H2+H3 = {_f(d['length'], 3)} m")
    for index, key in enumerate(("omega2", "omega3")):
        f = result["reference_formulas"]["fixed"][key]
        p.text(65, 351 + 18 * index, f"参考 ω{index + 2} = {_f(f['height'], 3)} × {_f(f['width'], 3)} × {_f(f['unit_weight'], 1)} = {_f(f['value'])} kN/m")
    p.heading(403, "(2) 付加死荷重 D2")
    p.text(55, 425, f"上載土　P = {_f(v['additional']['soil']['N'])} kN、M = {_f(v['additional']['soil']['M'])} kN m")
    for x, label in ((310, "鉛直力 N (kN)"), (425, "アーム (m)"), (550, "モーメント (kN m)")):
        p.text(x, 452, label, align="right")
    for index, side in enumerate(("B", "C")):
        load, y = v["additional"]["top"][side], 471 + 18 * index
        p.text(65, y, "起点側 B" if side == "B" else "終点側 C")
        for x, field, places in ((310, "N", 2), (425, "arm", 3), (550, "M", 2)):
            p.text(x, y, _f(load[field], places), align="right")
    p.line(60, 496, 555, 496, width=0.5)
    p.text(65, 514, "合計")
    p.text(310, 514, _f(v["additional"]["top"]["N"]), align="right")
    p.text(550, 514, _f(v["additional"]["top"]["M"]), align="right")
    p.heading(553, "(3) 浮力")
    p.text(55, 576, "参考ωは高さ×幅×γの線荷重。採用Nは集中鉛直力、Mは偏心モーメント。")
    for index, (key, label) in enumerate((("high", "高水位"), ("normal", "平水位"), ("low", "低水位"))):
        f, load = result["reference_formulas"]["water"][key], v["water"][key]
        y = 603 + 46 * index
        p.text(55, y, label)
        p.text(115, y, f"参考 ω = {_f(f['height'], 3)} × {_f(f['width'], 3)} × {_f(f['unit_weight'], 1)} = {_f(f['value'])} kN/m")
        p.text(115, y + 18, f"採用 N = {_f(load['N'])} kN、M = {_f(load['M'])} kN m")


def _support_rows(groups):
    return [[label, *[_f(load[side][key], 3 if key == "arm" else 2) for side in ("B", "C") for key in ("N", "arm", "M")],
             _f(load["N"]), _f(load["M"])] for label, load in groups]


def _snow_train(p, result):
    def support_block(y, label, load):
        p.text(55, y, label, heading=True)
        for x, title in ((300, "鉛直力 N (kN)"), (425, "アーム (m)"), (550, "モーメント (kN m)")):
            p.text(x, y + 23, title, align="right")
        for index, side in enumerate(("B", "C")):
            yy = y + 42 + 18 * index
            p.text(85, yy, "起点側 B" if side == "B" else "終点側 C")
            for x, field, places in ((300, "N", 2), (425, "arm", 3), (550, "M", 2)):
                p.text(x, yy, _f(load[side][field], places), align="right")
        p.line(80, y + 67, 555, y + 67, width=0.5)
        p.text(85, y + 85, "合計")
        p.text(300, y + 85, _f(load["N"]), align="right")
        p.text(550, y + 85, _f(load["M"]), align="right")

    p.heading(78, "(4) 雪荷重")
    for y, key, label in ((106, "s2", "1) 2年確率 S2"), (224, "s10", "2) 10年確率 S10"),
                          (342, "s30", "3) 30年確率 S30")):
        support_block(y, label, result["vertical"]["snow"][key])
    p.heading(472, "(5) 列車荷重")
    support_block(500, "1) 単線載荷 L1", result["vertical"]["train"]["single"])
    support_block(618, "2) 複線載荷 L2", result["vertical"]["train"]["double"])
    p.note(742, "列車荷重は無係数反力。組合せでは安全性・復旧性の有効係数、または使用性の係数を一度だけ適用する。")


def _impact_horizontal(p, result):
    p.heading(78, "(6) 衝撃荷重")
    family = {row["track"]: row for row in result["basic_cases"] if row["id"] in (11, 12)}
    for y, track, label in ((103, "single", "1) 単線載荷"), (203, "double", "2) 複線載荷")):
        load = result["vertical"]["impact"]["ultimate"][track]
        trace = family[track]["usage_resolution"]["ultimate"]
        p.text(55, y, f"{label}（安全性）", heading=True)
        p.text(550, y, f"採用 a = {_f(trace['effective_train_factor'])}", align="right")
        for x, title in ((200, "採用 L (kN)"), (280, "橋脚 c_p"), (365, "I (kN)"),
                         (448, "アーム (m)"), (550, "M (kN m)")):
            p.text(x, y + 21, title, align="right")
        for index, side in enumerate(("B", "C")):
            yy = y + 40 + 18 * index
            p.text(55, yy, "起点 B" if side == "B" else "終点 C")
            p.text(200, yy, _f(trace["support_calculation"][side]["train"]), align="right")
            p.text(212, yy, "×", align="center")
            p.text(280, yy, _f(trace["pier_coefficients"][side], 5), align="right")
            p.text(295, yy, "=", align="center")
            p.text(365, yy, _f(load[side]["N"]), align="right")
            p.text(448, yy, _f(load[side]["arm"], 3), align="right")
            p.text(550, yy, _f(load[side]["M"]), align="right")
        p.line(50, y + 65, 555, y + 65, width=0.5)
        p.text(55, y + 82, "合計")
        p.text(365, y + 82, _f(load["N"]), align="right")
        p.text(550, y + 82, _f(load["M"]), align="right")
    p.note(306, "c_pは0600の用途別橋脚低減込み。Iは支点別0.1 kN丸め。名目0.75・荷重係数を再乗算しない。")
    p.text(40, 335, "使用性・最大時の補足（最大時も橋脚低減を再評価しない）", heading=True)
    columns = ((45, "用途・線数", "left"), (145, "採用 a", "right"), (211, "B c_p", "right"),
               (277, "C c_p", "right"), (343, "B I (kN)", "right"), (409, "C I (kN)", "right"),
               (482, "N (kN)", "right"), (550, "M (kN m)", "right"))
    for x, title, align in columns:
        p.text(x, 357, title, align=align)
    index = 0
    for usage, label in (("service", "使用性"), ("maximum", "最大")):
        for track, track_label in (("single", "単線"), ("double", "複線")):
            load, trace = result["vertical"]["impact"][usage][track], family[track]["usage_resolution"][usage]
            values = (f"{label} {track_label}", _f(trace["effective_train_factor"]),
                      _f(trace["pier_coefficients"]["B"], 5), _f(trace["pier_coefficients"]["C"], 5),
                      _f(load["B"]["N"]), _f(load["C"]["N"]), _f(load["N"]), _f(load["M"]))
            for (x, _, align), value in zip(columns, values, strict=True):
                p.text(x, 376 + 19 * index, value, align=align)
            index += 1
    p.line(40, 442, 555, 442, width=0.3)
    p.heading(469, "(7) 水平荷重")
    xs, top, header_height, row_height = (40, 90, 120, 330, 405, 480, 555), 489, 28, 22
    bottom = top + header_height + row_height * len(result["horizontal"])
    for xx in xs:
        p.line(xx, top, xx, bottom, width=0.2)
    p.line(xs[0], top, xs[-1], top, width=0.6)
    for i, title in enumerate(("用途", "基本", "荷重種別", "起点 B (kN)", "終点 C (kN)", "合計 (kN)")):
        p.text((xs[i] + xs[i + 1]) / 2, top + 18, title, align="center")
    p.line(xs[0], top + header_height, xs[-1], top + header_height, width=0.3)
    for first, count, label in ((0, 2, "使用性"), (2, 4, "安全性"), (6, 2, "復旧性")):
        yy = top + header_height + row_height * first
        p.text(65, yy + row_height * count / 2 + 3, label, align="center")
    for index, row in enumerate(result["horizontal"]):
        yy = top + header_height + row_height * index
        label = row["label"].replace("ロングレール縦荷重 ", "").replace("ロングレール+制動 ", "")
        label = label.split(" ", 1)[-1]
        p.text(105, yy + 15, row["id"], align="center")
        p.text(125, yy + 15, label)
        for x, key in ((400, "B"), (475, "C"), (550, "total")):
            p.text(x, yy + 15, _f(row[key]), align="right")
        group_end = index in (1, 5, 7)
        p.line(40 if group_end else 90, yy + row_height, 555, yy + row_height,
               width=0.5 if group_end else 0.2)
    recovery = next(row for row in result["horizontal"] if row["id"] == 19)["upstream_details"]
    coefficients = [recovery[side].get("effective_brake_coefficient") for side in ("B", "C")]
    if all(isinstance(value, (int, float)) for value in coefficients):
        p.note(bottom + 22, f"復旧性の側別制動係数：B {_f(coefficients[0])} / C {_f(coefficients[1])}。")
    p.note(bottom + 47, "支承摩擦は上部工の L+I を含む採用水平力を保持する。鉛直Iの組合せ係数とは別に扱う。")


def _definitions(p, result):
    p.heading(78, "6. 基本ケース・定義ケース (Define)")
    rows = []
    for basic, define in zip(result["basic_cases"], result["define_cases"], strict=True):
        signed = " / ".join(f"{value:+d}" for value in define["signed_basic_case_ids"])
        rows.append([basic["id"], basic["symbol"], basic["label"], basic["spring_case"], signed])
    y = p.table(100, (35, 125, 240, 40, 75), ("ID", "作用", "基本ケース", "ばね", "Define"), rows, row_height=26)
    p.note(y + 20, "Define 1～12は正方向、13～20は当該水平作用のみ正負を選択する。")


def _matrix(p, result):
    # Physical page stays portrait. The table's own coordinate system is a
    # logical 842 by 595 landscape sheet; its y increases downwards.
    canvas = p.canvas
    canvas.saveState()
    canvas.translate(595, 0)
    canvas.rotate(90)
    q = _Page(canvas, p.fonts, height=595)
    q.text(60, 45, "7. 荷重組合せ（名目係数）", size=12, heading=True)
    q.text(60, 65, "20基本を列、16組合せを行に示す。－は0。水平作用だけ正負を展開する。")
    for start, count, title in ((0, 2, "死荷重"), (2, 3, "水位"), (5, 3, "雪"), (8, 2, "列車"), (10, 2, "衝撃"), (12, 8, "水平作用")):
        q.text(137 + (start + count / 2) * 29, 86, title, align="center")
    for j, basic in enumerate(result["basic_cases"]):
        x = 137 + (j + 0.5) * 29
        symbol = basic["symbol"].replace("（側別係数）", "")
        canvas.saveState()
        canvas.translate(x + 3, 595 - 160)
        canvas.rotate(90)
        canvas.setFont(p.fonts[0], 9.9)
        canvas.drawString(0, 0, symbol)
        canvas.restoreState()
        q.text(x, 178, basic["id"], align="center")
    for j in range(21):
        q.line(137 + 29 * j, 92, 137 + 29 * j, 446)
    q.line(55, 186, 717, 186)
    for i, case in enumerate(result["combinations"]):
        y = 186 + i * 16.25
        q.text(60, y + 11.5, case["id"])
        q.text(78, y + 11.5, case["label"].split()[-1])
        for j, coefficient in enumerate(case["coefficients"]):
            q.text(137 + (j + 0.5) * 29, y + 11.5, "－" if coefficient == 0 else _f(coefficient), size=10, align="center")
        q.line(55, y + 16.25, 717, y + 16.25)
    q.text(60, 472, "組合せ1～9：躯体、10～16：基礎。各組合せの用途は後掲の対応表に示す。")
    q.text(60, 494, "Iの名目係数を、用途別橋脚係数で解決済みのIに再乗算しない。採用荷重は用途別表による。")
    canvas.restoreState()


def _extractions(p, result):
    p.heading(78, "8. 抽出ケース")
    y = p.table(102, (45, 275, 195), ("ID", "性能・用途", "組合せID"),
                [[row["id"], row["label"], ", ".join(map(str, row["combination_ids"]))]
                 for row in result["extraction_cases"]], row_height=30)
    p.heading(y + 32, "組合せケースの対応")
    y = p.table(y + 46, (45, 80, 390), ("ID", "対象", "組合せ"),
                [[row["id"], "躯体" if row["scope"] == "body" else "基礎", row["label"]]
                 for row in result["combinations"]], row_height=20)
    p.note(y + 20, "抽出は組合せの参照群を示す。応答解析による最大・最小値の抽出結果ではない。")


def render_longitudinal_report(result: dict, output_path: str | Path) -> None:
    """Render the canonical snapshot without reading inputs or source layouts."""
    if result.get("schema_version") != 2:
        raise ValueError("0610正規帳票にはschema_version=2の計算結果が必要です")
    canvas = Canvas(str(output_path), pagesize=(595, 842))
    fonts = _fonts()
    page = _Page(canvas, fonts)
    drawers = (_model, _conditions, _dead_water, _snow_train, _impact_horizontal,
               _definitions, _matrix, _extractions)
    for index, draw in enumerate(drawers, 1):
        if draw is not _matrix:
            page.text(40, 43, "0610 線路方向荷重", size=13, heading=True)
            page.line(40, 53, 555, 53)
        draw(page, result)
        page.line(40, 805, 555, 805)
        page.text(40, 822, f"入力 SHA256: {result.get('provenance', {}).get('input_sha256', '未記録')[:12]}", size=8.5)
        page.text(555, 822, f"8-{index}", size=9.9, align="right")
        canvas.showPage()
    canvas.save()
