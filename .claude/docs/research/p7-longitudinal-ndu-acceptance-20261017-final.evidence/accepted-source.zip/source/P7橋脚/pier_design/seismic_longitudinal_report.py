"""Three-page earthquake load report drawn only from its calculated snapshot."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import replace
from decimal import Decimal, DecimalException, ROUND_HALF_UP, localcontext
from io import BytesIO
import math
from pathlib import Path

from reportlab.pdfbase import pdfmetrics
from reportlab.pdfgen.canvas import Canvas

from .frame_model_report import draw_frame_graph
from .frame_outline import Dimension, build_outline, dimension_text, draw_outline, fit_frame, frame_dimensions
from .report import _Page, _fonts


_PAGE_SIZE = (595, 842)
_DIRECTIONS = {"down": "↓", "up": "↑", "left": "←"}
_LOAD_TYPES = {"fixed": "固定", "incremental": "増分", "limited_incremental": "限定増分"}


def _number(value: float, places: int = 2) -> str:
    if not math.isfinite(value):
        raise ValueError("0710帳票: 表示値には有限の数値が必要です")
    return f"{value:.{places}f}"


def _formula_factors(values: dict[str, tuple[float, int]], expected: float,
                     evaluate: Callable[[dict[str, Decimal]], Decimal]) -> dict[str, str]:
    """Add only the factor precision needed to reproduce the printed result.

    Begin with the reference's decimal places, then check the displayed
    decimal arithmetic itself. This keeps float/Single trailing noise out of
    the page without presenting a false equality for nonround inputs.
    """
    target = Decimal(_number(expected))
    with localcontext() as context:
        context.prec = 60
        for extra in range(13):
            formatted = {}
            for key, (value, minimum) in values.items():
                text = _number(value, minimum + extra)
                while len(text.partition(".")[2]) > minimum and text.endswith("0"):
                    text = text[:-1]
                formatted[key] = text
            try:
                displayed = evaluate({key: Decimal(text) for key, text in formatted.items()})
                rounded = displayed.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            except DecimalException:
                # A positive divisor may round to zero at the initial display
                # precision; try additional digits before rejecting the page.
                continue
            if rounded == target:
                return formatted
    raise ValueError("0710帳票: 表示因子と計算結果を整合させる精度を確保できません")


def _text(p: _Page, x: float, y: float, value: object, *, size: float = 9.9,
          align: str = "left", width: float | None = None, gothic: bool = False) -> None:
    """Keep all report text readable; reject overflow instead of clipping it."""
    text = str(value)
    if width is not None and p.width(text, size) > width:
        size *= width / p.width(text, size)
    if size < 8.5:
        raise ValueError(f"0710帳票: 3ページ内に可読な文字サイズで収まりません: {text}")
    measured = p.width(text, size)
    left = x - measured if align == "right" else x - measured / 2 if align == "center" else x
    if left < 35 or left + measured > 565 or y < 35 or y > 785:
        raise ValueError(f"0710帳票: 3ページの描画範囲を超えています: {text}")
    p.text(x, y, text, size=size, align=align, gothic=gothic)


def _heading(p: _Page, y: float, text: str, *, x: float = 95) -> None:
    _text(p, x, y, text, gothic=True)


def _horizontal_dimension(p: _Page, left: float, right: float, y: float, value: float) -> None:
    label = _number(value, 3)
    if right - left < p.width(label, 9.9) + 6:
        raise ValueError("0710帳票: 水平寸法を可読な間隔で表示できません")
    p.line(left, y, right, y)
    for xx, direction in ((left, 1), (right, -1)):
        p.line(xx, y - 7, xx, y + 5)
        p.line(xx, y, xx + direction * 4, y - 2)
        p.line(xx, y, xx + direction * 4, y + 2)
    _text(p, (left + right) / 2, y - 4, label, align="center")


def _bearing_annotations(p: _Page, result: dict, outline, layout) -> None:
    """The superstructure bearing types belong beside the cap, not the base."""
    cap = next((part for part in reversed(outline.components) if part.name in ("beam", "haunch", "shaft")))
    cap_xs = [point[0] for point in cap.points]
    cap_top = max(point[1] for point in cap.points)
    positions = [(layout.point(min(cap_xs), cap_top)[0] - 26, layout.y(cap_top) + 23),
                 (layout.point(max(cap_xs), cap_top)[0] + 26, layout.y(cap_top) + 23)]
    # Keep a reserved band above the diagram for unusually wide cap shapes.
    if positions[0][0] < 105 or positions[1][0] > layout.extension_x - 14:
        positions = [(130, 168), (195, 168)]
    for side, (x, y) in zip(("b", "c"), positions, strict=True):
        bearing = result["input"]["spans"][side]["bearing"]
        symbol = {"可動": "M", "固定": "F"}.get(bearing)
        if symbol is None:
            raise ValueError(f"0710帳票: 支承種別を表示できません: {bearing}")
        p.canvas.setStrokeGray(0)
        p.canvas.setLineWidth(.3)
        p.canvas.circle(x, _PAGE_SIZE[1] - y, 6, stroke=1, fill=0)
        _text(p, x, y + 3, symbol, size=9, align="center")


def _seismic_frame_dimensions(frame: dict) -> tuple[Dimension, ...]:
    """Split only the seismic column base; other reports retain their geometry."""
    nodes = {node["id"]: node for node in frame["nodes"]}
    roles = frame["node_ids"]
    micro_top = nodes[roles["column_base_micro_top"]]["y"]
    footing_top = nodes[roles["footing_top"]]["y"]
    cap_top = nodes[roles["cap_top"]]["y"]
    dimensions = []
    for dimension in frame_dimensions(frame):
        is_column = dimension.name == "H4"
        is_upper_total = dimension.column == 1 and dimension.top == cap_top and dimension.bottom == footing_top
        if is_column or is_upper_total:
            dimension = Dimension(dimension.name, dimension.top, micro_top, dimension.column)
        dimensions.append(dimension)
    dimensions.extend(Dimension("柱下端微小部材", micro_top, footing_top, column) for column in (0, 1))
    return tuple(dimensions)


def _micro_dimension_labels(layout, font: str):
    """Move the two tiny-span labels clear of the coincident extension lines."""
    ys = list(layout.dimension_label_ys)
    widths = [pdfmetrics.stringWidth(dimension_text(dimension), font, 9.9)
              for dimension in layout.dimensions]
    extensions = {layout.y(height) for dimension in layout.dimensions
                  for height in (dimension.top, dimension.bottom)}
    for index, dimension in enumerate(layout.dimensions):
        if dimension.name != "柱下端微小部材":
            continue
        desired = layout.y(dimension.top) - widths[index] / 2 - 7
        selected_y = None
        for offset in range(100):
            candidate = desired - offset * 2
            top, bottom = candidate - widths[index] / 2, candidate + widths[index] / 2
            if top < 179:
                break
            if any(top - 3 <= yy <= bottom + 3 for yy in extensions):
                continue
            if any(other.column == dimension.column and other_index != index
                   and abs(candidate - ys[other_index]) < (widths[index] + widths[other_index]) / 2 + 4
                   for other_index, other in enumerate(layout.dimensions)):
                continue
            selected_y = candidate
            break
        if selected_y is None:
            raise ValueError("0710帳票: 微小部材の寸法文字を可読な間隔で表示できません")
        ys[index] = selected_y
    bounds = list(layout.annotation_bounds)
    start = len(layout.node_labels) + len(layout.member_labels)
    for index, (old_y, new_y) in enumerate(zip(layout.dimension_label_ys, ys, strict=True)):
        left, top, right, bottom = bounds[start + index]
        bounds[start + index] = (left, top + new_y - old_y, right, bottom + new_y - old_y)
    return replace(layout, dimension_label_ys=tuple(ys), annotation_bounds=tuple(bounds))


def _micro_node_labels(frame: dict, layout, font: str):
    """Keep the near-coincident endpoint labels vertically ordered at true scale."""
    labels, bounds = dict(layout.node_labels), list(layout.annotation_bounds)
    roles = frame["node_ids"]
    endpoints = {roles["column_base_micro_top"]: -6, roles["footing_top"]: 14}
    positions = {node["id"]: index for index, node in enumerate(frame["nodes"])}
    occupied = [bound for index, bound in enumerate(bounds)
                if index not in {positions[identifier] for identifier in endpoints}]
    ascent, descent = pdfmetrics.getAscentDescent(font, 9.9)
    for node in frame["nodes"]:
        identifier = node["id"]
        if identifier not in endpoints:
            continue
        xx, yy = layout.point(node["x"], node["y"])
        width = pdfmetrics.stringWidth(str(identifier), font, 9.9)
        ty = yy + endpoints[identifier]
        for left_offset in (10, 24, 38, 52):
            tx = xx - left_offset
            bound = (tx - width, ty - ascent, tx, ty - descent)
            if bound[0] < 97 or bound[1] < 179 or bound[2] > 533 or bound[3] > 679:
                continue
            if any(bound[0] < other[2] + 2 and bound[2] > other[0] - 2
                   and bound[1] < other[3] + 2 and bound[3] > other[1] - 2 for other in occupied):
                continue
            labels[identifier] = (tx, ty)
            bounds[positions[identifier]] = bound
            occupied.append(bound)
            break
        else:
            raise ValueError("0710帳票: 微小部材の節点番号を可読な間隔で表示できません")
    return replace(layout, node_labels=labels, annotation_bounds=tuple(bounds))


def _micro_node_leaders(p: _Page, frame: dict, layout) -> None:
    roles = frame["node_ids"]
    for node in frame["nodes"]:
        identifier = node["id"]
        if identifier not in (roles["column_base_micro_top"], roles["footing_top"]):
            continue
        xx, yy = layout.point(node["x"], node["y"])
        tx, ty = layout.node_labels[identifier]
        end_offset = -2 if identifier == roles["column_base_micro_top"] else 2
        p.line(tx + 2, ty - 3, xx - 2, yy + end_offset, .12)


def _model(p: _Page, result: dict) -> None:
    _heading(p, 95, "§10. 線路方向の計算（地震時）", x=73)
    _heading(p, 124, "10.1 検討モデル", x=82)
    _heading(p, 152, "(1) 骨組図")
    frame = result["frame"]
    geometry = result["input"]["geometry"]
    outline = build_outline(geometry, "b")
    layout = fit_frame(outline, frame["nodes"], (95, 177, 535, 681),
                       members=frame["members"], dimensions=_seismic_frame_dimensions(frame),
                       font=p.fonts[0], font_size=9.9)
    layout = _micro_dimension_labels(layout, p.fonts[0])
    layout = _micro_node_labels(frame, layout, p.fonts[0])
    draw_outline(p.canvas, outline, layout)
    draw_frame_graph(p.canvas, p.fonts, frame, layout)
    _micro_node_leaders(p, frame, layout)
    _bearing_annotations(p, result, outline, layout)
    b7, b8, b9 = (geometry[f"b{i}"] for i in (7, 8, 9))
    coordinates = (-b8 / 2 - b7, -b8 / 2, b8 / 2, b8 / 2 + b9)
    xs = [layout.point(x, 0)[0] for x in coordinates]
    for xx in (xs[0], xs[-1]):
        p.line(xx, layout.y(0) + 7, xx, 732)
    # A very narrow segment can be read in a compact dimension note while the
    # overall dimension remains to scale; never obscure a physical segment.
    segment_labels_fit = all(xs[i + 1] - xs[i] >= p.width(_number(value, 3), 9.9) + 6
                             for i, value in enumerate((b7, b8, b9)))
    if segment_labels_fit:
        for i, value in enumerate((b7, b8, b9)):
            _horizontal_dimension(p, xs[i], xs[i + 1], 706, value)
    else:
        _text(p, 100, 706,
              f"左張出し {_number(b7, 3)}   中央幅 {_number(b8, 3)}   右張出し {_number(b9, 3)}", width=435)
    _horizontal_dimension(p, xs[0], xs[-1], 731, b7 + b8 + b9)
    _text(p, 535, 764, "単位：m", align="right")


def _train(p: _Page, result: dict) -> None:
    _heading(p, 154, "(1) 列車荷重")
    _heading(p, 181, "・単線載荷", x=121)
    for x, label in ((250, "鉛直力 (kN)"), (349, "アーム (m)"), (446, "モーメント (kN・m)")):
        _text(p, x, 203, label, align="center")
    train = result["vertical"]["train"]["earthquake"]
    for y, side, label in ((217, "B", "起点側  RＢ"), (231, "C", "終点側  RＣ")):
        row = train[side]
        _text(p, 131, y, label)
        for x, key, places, width in ((274, "N", 2, 76), (369, "arm", 3, 76), (466, "M", 2, 76)):
            _text(p, x, y, _number(row[key], places), align="right", width=width)
    p.line(129, 235, 468, 235, .8)
    _text(p, 131, 253, "合計")
    _text(p, 274, 253, _number(train["N"]), align="right", width=76)
    _text(p, 466, 253, _number(train["M"]), align="right", width=76)


def _bearing_loads(p: _Page, result: dict) -> None:
    _heading(p, 283, "(2) 水平荷重")
    _heading(p, 312, "1) 支承に働く水平荷重のまとめ", x=105)
    left, top, right, bottom = 116, 328, 418, 402
    for xx in (left, right):
        p.line(xx, top, xx, bottom, .8)
    for yy in (top, bottom):
        p.line(left, yy, right, yy, .8)
    for xx in (298, 358):
        p.line(xx, top, xx, bottom)
    p.line(141, 356, 141, bottom)
    p.line(left, 356, right, 356)
    p.line(141, 379, right, 379)
    _text(p, 207, 346, "荷　重　種　別", align="center")
    for x, label in ((328, "起点桁"), (388, "終点桁")):
        _text(p, x, 341, label, align="center")
        _text(p, x, 352, "(kN)", align="center")
    for y, label in ((370, "地"), (381, "震"), (392, "時")):
        _text(p, 129, y, label, align="center")
    for y, key, label in ((371, "girder", "1.0 EＱ（桁荷重）"), (394, "train", "1.0 EＱ（列車荷重）")):
        _text(p, 144, y, label, width=150)
        for x, side in ((351, "B"), (411, "C")):
            _text(p, x, y, _number(result["horizontal"][key][side]), align="right", width=55)


def _line_inertia(p: _Page, y: float, name: str, symbol: str, formula: dict) -> None:
    factors = _formula_factors(
        {key: (value, 1 if key == "unit_weight" else 2) for key, value in formula["factors"].items()},
        formula["value"], lambda values: values["b"] * values["w"] * values["unit_weight"] * values["Kh"],
    )
    first, second = ("w", "b") if symbol == "Hw3" else ("b", "w")
    expression = (f"{symbol} = {factors[first]} × {factors[second]} × "
                  f"{factors['unit_weight']} × {factors['Kh']}"
                  f" = {_number(formula['value'])} kN/m")
    _text(p, 119, y, name, width=67)
    _text(p, 194, y, expression, width=355)


def _inertia(p: _Page, result: dict) -> None:
    _heading(p, 441, "(3) 自重による地震時慣性力")
    _text(p, 106, 469, f"設計水平震度  Kh  =  {_number(result['inertia']['Kh'])}")
    formulas = result["formulas"]
    y = 497.0
    pedestal = formulas["pedestal"]
    if pedestal["value"] or pedestal["moment"]:
        _text(p, 106, y, "・桁受けに作用する水平力")
        factors = pedestal["factors"]
        force_factors = _formula_factors(
            {key: (factors[key], 2) for key in ("weight", "Kh")}, pedestal["value"],
            lambda values: values["weight"] * values["Kh"],
        )
        moment_factors = _formula_factors(
            {"H": (pedestal["value"], 2), "height": (factors["height"], 3)}, pedestal["moment"],
            lambda values: values["H"] * values["height"],
        )
        _text(p, 119, y + 20,
              f"H = {force_factors['weight']} × {force_factors['Kh']}"
              f" = {_number(pedestal['value'])} kN", width=430)
        _text(p, 119, y + 40,
              f"M = {moment_factors['H']} × {moment_factors['height']}"
              f" = {_number(pedestal['moment'])} kN・m", width=430)
        y += 66
    _text(p, 106, y, "・橋脚く体に作用する水平力")
    distinct_bottom = formulas["beam_bottom"]["value"] != formulas["column"]["value"]
    _line_inertia(p, y + 21, "はり上" if distinct_bottom else "はり", "Hw1", formulas["beam_top"])
    y += 42
    if distinct_bottom:
        _line_inertia(p, y, "はり下", "Hw2", formulas["beam_bottom"])
        y += 21
    _line_inertia(p, y, "柱", "Hw3", formulas["column"])
    y += 40
    _text(p, 106, y, "・フーチング重心に作用する水平力")
    footing = formulas["footing"]
    factors, geometry = footing["factors"], footing["geometry"]
    rectangle_volume = geometry["b"] * geometry["w"] * geometry["h6"]
    # Show physical dimensions for the rectangular source case. A tapered or
    # rounded weight uses the actual adopted volume, never a guessed cuboid.
    rectangular = geometry["h5"] == 0 and math.isclose(
        rectangle_volume, factors["weight"] / factors["unit_weight"], rel_tol=0, abs_tol=1e-5)
    factor_inputs = {key: (factors[key], 2 if key == "Kh" else 1)
                     for key in ("unit_weight", "displaced_unit_weight", "Kh")}
    if rectangular:
        try:
            displayed = _formula_factors(
                {**factor_inputs, **{key: (geometry[key], 2) for key in ("b", "w", "h6")}},
                footing["value"], lambda values: values["b"] * values["w"] * values["h6"]
                * (values["unit_weight"] - values["displaced_unit_weight"]) * values["Kh"],
            )
        except ValueError:
            # At a rounding boundary even a tiny transferred-weight difference
            # can matter; print the actual adopted volume in that case.
            rectangular = False
    if rectangular:
        first = f"H = {displayed['b']} × {displayed['w']}"
        second = f"× {displayed['h6']}"
    else:
        displayed = _formula_factors(
            {**factor_inputs, "weight": (factors["weight"], 2)}, footing["value"],
            lambda values: values["weight"] / values["unit_weight"]
            * (values["unit_weight"] - values["displaced_unit_weight"]) * values["Kh"],
        )
        first = f"H = {displayed['weight']} / {displayed['unit_weight']}"
        second = ""
    second += (f" × ( {displayed['unit_weight']} - {displayed['displaced_unit_weight']} )"
               f" × {displayed['Kh']} = {_number(footing['value'])} kN")
    _text(p, 131, y + 22, first, width=418)
    _text(p, 205, y + 38, second.strip(), width=344)


def _actions(p: _Page, result: dict) -> None:
    _heading(p, 95, "10.2 作用の計算", x=82)
    _text(p, 95, 125, "下記以外の作用は、0610 線路方向荷重（地震時以外）と同様とする。", width=460)
    _train(p, result)
    _bearing_loads(p, result)
    _inertia(p, result)


def _combinations(p: _Page, result: dict) -> None:
    _heading(p, 95, "10.3 作用の組合せ", x=82)
    cases, combination = result["basic_cases"], result["combinations"][0]
    xs = (93, 142, 189, 239, 287, 554)
    top, header, row_height = 130, 159, 14.4
    bottom = header + len(cases) * row_height
    _text(p, 273, 127, "基本Case", align="center")
    for yy in (top, header, bottom):
        p.line(xs[0], yy, xs[-1], yy, .8)
    for xx in xs[1:-1]:
        p.line(xx, top, xx, bottom, .8)
    for index, label in enumerate(("Case", "記号", "作用方向", "荷重種別", "荷　重　名　称")):
        _text(p, (xs[index] + xs[index + 1]) / 2, 142, label, align="center", width=xs[index + 1] - xs[index] - 4)
    for row, case in enumerate(cases):
        y = header + row_height * row
        if row:
            p.line(xs[0], y, xs[-1], y)
        texts = (case["id"], case["symbol"], _DIRECTIONS[case["direction"]], _LOAD_TYPES[case["load_type"]])
        for index, value in enumerate(texts):
            _text(p, (xs[index] + xs[index + 1]) / 2, y + 11.5, value,
                  align="center", width=xs[index + 1] - xs[index] - 4)
        label = case["label"]
        if case["symbol"] in ("EQ1", "EQL", "EQ2"):
            kh = (result["horizontal"]["girder"]["Kh"] if case["symbol"] == "EQ1" else
                  result["horizontal"]["train"]["Kh"] if case["symbol"] == "EQL" else result["inertia"]["Kh"])
            label += f"（Kh={_number(kh)}）"
        _text(p, xs[4] + 3, y + 11.5, label, width=xs[5] - xs[4] - 6)

    top = bottom + 43
    _text(p, 261, top - 4, "組合せCase", align="center")
    columns = (93, 118, 154, 190, 511, 554)
    for xx in columns[1:-1]:
        p.line(xx, top, xx, top + 58, .8)
    for yy in (top, top + 29, top + 58):
        p.line(columns[0], yy, columns[-1], yy, .8)
    for x, label in ((105, "Case"), (350, "荷重補正係数＋基本Case")):
        _text(p, x, top + 18, label, align="center")
    for x, first, second in ((136, "αf", "ρm"), (172, "作用", "方向"), (532, "地盤抵抗", "TYPE")):
        _text(p, x, top + 12, first, align="center", size=8.5 if x == 532 else 9.9)
        _text(p, x, top + 26, second, align="center")
    _text(p, 105, top + 47, combination["id"], align="center")
    _text(p, 136, top + 40, _number(combination["alpha_f"], 1), align="center")
    _text(p, 136, top + 55, _number(combination["rho_m"], 1), align="center")
    _text(p, 172, top + 47, _DIRECTIONS[combination["direction"]], align="center")
    expression = " + ".join(str(case["id"]) if coefficient == 1 else f"{coefficient:g}×{case['id']}"
                            for case, coefficient in zip(cases, combination["coefficients"], strict=True))
    _text(p, 350, top + 47, expression, align="center", width=313)
    _text(p, 532, top + 47, combination["ground_resistance_type"], align="center")


def render_seismic_longitudinal_report(result: dict, output_path: str | Path) -> None:
    """Write exactly three A4 pages without reopening inputs or source documents."""
    if result.get("schema_version") != 1 or result.get("stage") != "0710":
        raise ValueError("0710帳票: schema_version=1、stage=0710の計算結果が必要です")
    if len(result["basic_cases"]) != 8 or len(result["combinations"]) != 1:
        raise ValueError("0710帳票: 基本8ケース・組合せ1ケースが必要です")
    if len(result["combinations"][0]["coefficients"]) != 8:
        raise ValueError("0710帳票: 組合せ係数は8個必要です")
    buffer = BytesIO()
    canvas = Canvas(buffer, pagesize=_PAGE_SIZE, pageCompression=1, invariant=1)
    canvas.setTitle("0710 線路方向荷重（地震時）")
    canvas.setAuthor("P7橋脚 計算プログラム")
    canvas.setSubject("検討モデル・作用の計算・作用の組合せ")
    page = _Page(canvas, _fonts())
    for number, draw in enumerate((_model, _actions, _combinations), 1):
        _text(page, 554, 52, f"10 - {number}", align="right", size=10.5)
        draw(page, result)
        canvas.showPage()
    canvas.save()
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(buffer.getvalue())
