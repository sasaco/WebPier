"""Verify retained 0710/NDU candidates in JRSNAP V5.2, then publish those bytes.

The normal CLI has no JRSNAP dependency. This deliberately separate acceptance
entry point retains independent evidence and supports receipt-only recovery if
the final receipt write fails after successful publication. It never runs SNAP.
"""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import os
import subprocess
import sys
import tempfile
from collections.abc import Callable, Mapping
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

PROJECT = Path(__file__).resolve().parents[1]
REPOSITORY = PROJECT.parent
sys.path.insert(0, str(PROJECT))

from pier_design.jrsnap_readback import ReadbackError, verify_readback

DEFAULT_ORACLE = PROJECT / "tests" / "fixtures" / "jrsnap_v52_longitudinal_expected.json"
DEFAULT_APP = Path("C:/RTRI_Program/JRSNAP(Ver5.2-L03)/JRSNAP_Input.exe")
DEFAULT_HELPER = REPOSITORY / ".agents/skills/jrsnap-input-open-save/scripts/save-ndu.ps1"


class AcceptanceError(ValueError):
    """Acceptance failed; a completed publication must not be claimed."""


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical_sha256(value: Any) -> str:
    return sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                             ensure_ascii=False, allow_nan=False).encode("utf-8"))


def _utc_now() -> str:
    return datetime.now(UTC).isoformat()


def _ps_literal(value: Path | str) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def _powershell_json(command: str, *, timeout: int) -> Any:
    prefix = ("$ErrorActionPreference='Stop'; "
              "$OutputEncoding=[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false); ")
    encoded = base64.b64encode((prefix + command).encode("utf-16le")).decode("ascii")
    try:
        result = subprocess.run(
            ["powershell.exe", "-NoProfile", "-NonInteractive", "-EncodedCommand", encoded],
            capture_output=True, timeout=timeout, check=False,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise AcceptanceError(f"JRSNAP helper could not finish: {exc}") from exc
    if result.returncode:
        detail = result.stderr.decode("utf-8", errors="replace").strip()
        raise AcceptanceError(f"JRSNAP helper exit {result.returncode}: {detail}")
    try:
        return json.loads(result.stdout.decode("utf-8-sig"))
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise AcceptanceError("JRSNAP helper did not return valid JSON") from exc


def app_identity(executable: Path = DEFAULT_APP) -> dict[str, str]:
    """Check the installed build, rather than trusting an NDU header."""
    executable = executable.resolve(strict=True)
    command = (
        "$p=" + _ps_literal(executable) + "; $f=Get-Item -LiteralPath $p; "
        "[ordered]@{file_version=$f.VersionInfo.FileVersion;"
        "product_version=$f.VersionInfo.ProductVersion;"
        "assembly_version=[Reflection.AssemblyName]::GetAssemblyName($p).Version.ToString()}"
        "| ConvertTo-Json -Compress"
    )
    identity = _powershell_json(command, timeout=30)
    required = {"file_version": "5.2.3.0", "product_version": "5.2.3.0",
                "assembly_version": "5.2.3.1"}
    if not isinstance(identity, dict) or any(identity.get(key) != value for key, value in required.items()):
        raise AcceptanceError(f"Installed application is not JRSNAP 5.2-L03: {identity}")
    return {**identity, "path": str(executable), "sha256": sha256(executable.read_bytes())}


def run_v52_roundtrip(candidate: bytes, *, timeout: int = 30,
                      helper: Path = DEFAULT_HELPER) -> dict[str, Any]:
    """Read/save copies twice using the installed app and retain both byte arrays."""
    if not 5 <= timeout <= 300:
        raise AcceptanceError("Helper timeout must be 5-300 seconds")
    identity = app_identity()
    helper = helper.resolve(strict=True)
    sources = {str(path): sha256(path.read_bytes()) for path in (helper, helper.with_name("roundtrip.cs"))}
    with tempfile.TemporaryDirectory(prefix="p7-ndu-acceptance-") as temporary:
        copied = Path(temporary) / "candidate.ndu"
        copied.write_bytes(candidate)
        started = datetime.now(UTC).timestamp()
        command = ("& " + _ps_literal(helper) + " -Path " + _ps_literal(copied)
                   + f" -Version V52 -TimeoutSeconds {timeout} | ConvertTo-Json -Depth 8 -Compress")
        report = _powershell_json(command, timeout=2 * timeout + 90)
        if (not isinstance(report, dict) or report.get("Written") is not False
                or report.get("ConvertedS6") is not False
                or str(report.get("BeforeHash", "")).lower() != sha256(candidate)):
            raise AcceptanceError("The helper did not validate the unchanged candidate in dry-run mode")
        if copied.read_bytes() != candidate:
            raise AcceptanceError("The application modified the acceptance input copy")
        stage = Path(str(report.get("Stage", "")))
        if not stage.is_dir() or not stage.name.startswith("jrsnap-ndu-save-"):
            raise AcceptanceError("JRSNAP helper stage is missing or invalid")
        paths = [stage / f"case1.{part}.ndu" for part in ("original", "saved", "second")]
        for path in paths:
            if not path.is_file() or path.stat().st_mtime < started - 2:
                raise AcceptanceError(f"Missing or stale JRSNAP readback: {path}")
        original, first, second = (path.read_bytes() for path in paths)
        if original != candidate or not first or first != second:
            raise AcceptanceError("JRSNAP second save is not byte-stable")
        if str(report.get("AfterHash", "")).lower() != sha256(first):
            raise AcceptanceError("JRSNAP helper output hash differs")
    if app_identity() != identity or any(sha256(Path(path).read_bytes()) != digest for path, digest in sources.items()):
        raise AcceptanceError("JRSNAP application or helper changed during acceptance")
    return {"application": identity, "first": first, "second": second,
            "helper_sources": sources, "helper_report": report}


def _check_files(expected: Mapping[str, str], label: str) -> None:
    if not expected:
        raise AcceptanceError(f"Empty {label} binding")
    for name, digest in expected.items():
        path = Path(name)
        if path.is_symlink() or not path.is_file() or sha256(path.read_bytes()) != digest:
            raise AcceptanceError(f"{label} changed or is missing: {name}")


def _write_receipt(path: Path, document: dict[str, Any], *, create: bool) -> None:
    encoded = (json.dumps(document, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8")
    if create:
        # Incomplete creation can never authorize publication: the file is read
        # back and checked before publish(). Existing receipts are never replaced.
        with path.open("xb") as stream:
            stream.write(encoded)
            stream.flush()
            os.fsync(stream.fileno())
    else:
        fd, name = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
        try:
            with os.fdopen(fd, "wb") as stream:
                stream.write(encoded)
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(name, path)
        finally:
            Path(name).unlink(missing_ok=True)
    if path.read_bytes() != encoded:
        raise AcceptanceError("Acceptance receipt bytes changed while writing")


def _origin_snapshot(candidate: Any) -> Path:
    origin = candidate.options.input_path.resolve()
    snapshot = origin.parent / "snapshots" / f"ndu-origin-{candidate.input_sha256}.json"
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    if not snapshot.exists():
        with snapshot.open("xb") as stream:
            stream.write(candidate.input_bytes)
    if snapshot.is_symlink() or snapshot.read_bytes() != candidate.input_bytes:
        raise AcceptanceError("Origin snapshot does not match the full raw input bytes")
    return snapshot.resolve()


def _receipt_binding(candidate: Any, *, oracle_path: Path, receipt_path: Path,
                     app_result: Mapping[str, Any], semantic: dict[str, Any],
                     supporting_sources: Mapping[str, str]) -> dict[str, Any]:
    evidence = receipt_path.with_suffix(".evidence")
    evidence.mkdir()
    native = candidate.read_paths[candidate.ndu_path].read_bytes()
    evidence_hashes = {}
    for name, data in (("candidate.ndu", native), ("first.ndu", app_result["first"]),
                       ("second.ndu", app_result["second"])):
        path = evidence / name
        with path.open("xb") as stream:
            stream.write(data)
        evidence_hashes[str(path.resolve())] = sha256(data)
    sources = {str(path.resolve()): digest for path, digest in candidate.source_hashes.items()}
    sources.update(app_result["helper_sources"])
    sources.update(supporting_sources)
    return {
        "publication_id": candidate.publication_id,
        "raw_input_path": str(candidate.options.input_path.resolve()),
        "raw_input_sha256": candidate.input_sha256,
        "origin_input_sha256": candidate.input_sha256,
        "origin_snapshot": str(_origin_snapshot(candidate)),
        "canonical_snapshot_sha256": {stage: canonical_sha256(candidate.computed[stage]) for stage in ("0500", "0710")},
        "metadata": candidate.metadata,
        "expected_artifacts": {str(path.resolve()): digest for path, digest in candidate.artifact_hashes.items()},
        "native_path": str(candidate.ndu_path.resolve()),
        "source_hashes": sources,
        "implementation_source_paths": sorted(str(path.resolve()) for path in candidate.source_hashes),
        "implementation_source_directory": str((PROJECT / "pier_design").resolve()),
        "oracle_path": str(oracle_path.resolve()),
        "application": app_result["application"],
        "evidence_hashes": evidence_hashes,
        "semantic_inspection": semantic,
        "gui_inspected": False, "analysis_executed": False,
    }


def _check_binding(receipt: Mapping[str, Any], *, published: bool) -> None:
    binding = receipt.get("binding", {})
    if receipt.get("schema_version") != 1 or canonical_sha256(binding) != receipt.get("binding_sha256"):
        raise AcceptanceError("Acceptance receipt binding is missing or altered")
    if receipt.get("status") not in ("verified_pending_publication", "complete"):
        raise AcceptanceError("Unsupported acceptance receipt status")
    raw_hash = binding["raw_input_sha256"]
    if binding["origin_input_sha256"] != raw_hash:
        raise AcceptanceError("Origin and raw input generations differ")
    _check_files({binding["raw_input_path"]: raw_hash, binding["origin_snapshot"]: raw_hash}, "Input")
    _check_files(binding["source_hashes"], "Source/profile/oracle")
    current_sources = sorted(str(path.resolve()) for path in Path(binding["implementation_source_directory"]).glob("*.py"))
    if current_sources != binding["implementation_source_paths"]:
        raise AcceptanceError("Implementation source file set changed")
    _check_files(binding["evidence_hashes"], "Readback evidence")
    oracle = json.loads(Path(binding["oracle_path"]).read_text(encoding="utf-8"))
    if oracle.get("acceptance_approved") is not True:
        raise AcceptanceError("The independent acceptance oracle has not been approved")
    if oracle.get("input_sha256") != raw_hash:
        raise AcceptanceError("Independent oracle belongs to another input generation")
    _check_roles(binding["metadata"], oracle)
    evidence = {Path(name).name: Path(name).read_bytes() for name in binding["evidence_hashes"]}
    if set(evidence) != {"candidate.ndu", "first.ndu", "second.ndu"}:
        raise AcceptanceError("Incomplete readback evidence set")
    if evidence["first.ndu"] != evidence["second.ndu"]:
        raise AcceptanceError("Application second save changed")
    for data in evidence.values():
        verify_readback(data, oracle)
    if sha256(evidence["candidate.ndu"]) != binding["expected_artifacts"].get(binding["native_path"]):
        raise AcceptanceError("Readback candidate is not the bound publication candidate")
    if published:
        _check_files(binding["expected_artifacts"], "Published artifact")


def finalize_receipt(path: Path, *, identity_reader: Callable[[], dict[str, str]] = app_identity) -> dict[str, Any]:
    """Recheck all retained bindings before completing a receipt; never regenerate."""
    if path.is_symlink():
        raise AcceptanceError("Acceptance receipt must not be a symlink")
    receipt = json.loads(path.read_text(encoding="utf-8"))
    _check_binding(receipt, published=True)
    if identity_reader() != receipt["binding"]["application"]:
        raise AcceptanceError("The installed application changed since readback")
    receipt.update(status="complete", completed_utc=_utc_now())
    _write_receipt(path, receipt, create=False)
    return receipt


def _held_calculation_hash(candidate: Any) -> str:
    return canonical_sha256({"metadata": candidate.metadata,
                             "calculations": {stage: candidate.computed[stage] for stage in ("0500", "0710")},
                             "publication_id": candidate.publication_id,
                             "input_sha256": candidate.input_sha256})


def _check_roles(metadata: Mapping[str, Any], oracle: Mapping[str, Any]) -> None:
    if metadata.get("profile_id") != oracle.get("profile_id"):
        raise AcceptanceError("The candidate profile differs from the independent oracle")
    if metadata.get("target_version") not in ("5.2-L03", "JRSNAP 5.2-L03"):
        raise AcceptanceError("The candidate target version is not JRSNAP 5.2-L03")
    roles = metadata.get("roles", {})
    for role, identifier in oracle["role_ids"].items():
        source_role = "cap_top" if role in ("load_top", "control") else role
        if roles.get(source_role) != identifier:
            raise AcceptanceError(f"The candidate role {role} differs from the independent oracle")


def accept_generation(options: Any, *, oracle_path: Path = DEFAULT_ORACLE,
                      receipt_path: Path | None = None,
                      prepare: Callable[..., Any] | None = None,
                      app_runner: Callable[[bytes], dict[str, Any]] = run_v52_roundtrip,
                      identity_reader: Callable[[], dict[str, str]] = app_identity) -> Path:
    """Publish the same held candidates only after independent real-app acceptance."""
    if not options.jrsnap or options.stage not in ("0710", "all"):
        raise AcceptanceError("Acceptance requires --stage 0710/all and JRSNAP output")
    if prepare is None:
        from pier_design.cli import prepare_generation
        prepare = prepare_generation
    oracle_path = oracle_path.resolve(strict=True)
    oracle = json.loads(oracle_path.read_text(encoding="utf-8"))
    if oracle.get("acceptance_approved") is not True:
        raise AcceptanceError("The independent acceptance oracle has not been approved")
    supporting_sources = {str(path.resolve()): sha256(path.read_bytes()) for path in (
        Path(__file__), PROJECT / "pier_design/jrsnap_readback.py", oracle_path)}
    with prepare(options) as candidate:
        candidate.validate_unchanged()
        _check_files(supporting_sources, "Acceptance source/oracle")
        if oracle.get("input_sha256") != candidate.input_sha256:
            raise AcceptanceError("Independent oracle is for another raw input generation")
        _check_roles(candidate.metadata, oracle)
        held_calculation_hash = _held_calculation_hash(candidate)
        native = candidate.read_paths[candidate.ndu_path].read_bytes()
        before = verify_readback(native, oracle)
        app_result = app_runner(native)
        if app_result["first"] != app_result["second"]:
            raise AcceptanceError("Application second save changed")
        first = verify_readback(app_result["first"], oracle)
        second = verify_readback(app_result["second"], oracle)
        candidate.validate_unchanged()
        _check_files(supporting_sources, "Acceptance source/oracle")
        if _held_calculation_hash(candidate) != held_calculation_hash:
            raise AcceptanceError("Held calculation/profile metadata changed during readback")
        path = (receipt_path or REPOSITORY / ".agents/docs/research" /
                f"p7-longitudinal-ndu-acceptance-{candidate.publication_id}.json").resolve()
        if path in {artifact.resolve() for artifact in candidate.artifact_hashes} or path == options.input_path.resolve():
            raise AcceptanceError("Receipt collides with a product artifact or input")
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists() or path.is_symlink():
            raise AcceptanceError("Receipt already exists; use --finalize-receipt for recovery")
        binding = _receipt_binding(candidate, oracle_path=oracle_path, receipt_path=path,
                                   app_result=app_result, semantic={"candidate": before, "first": first, "second": second},
                                   supporting_sources=supporting_sources)
        receipt = {"schema_version": 1, "status": "verified_pending_publication",
                   "verified_utc": _utc_now(), "binding": binding, "binding_sha256": canonical_sha256(binding)}
        _write_receipt(path, receipt, create=True)
        stored = json.loads(path.read_text(encoding="utf-8"))
        _check_binding(stored, published=False)
        if identity_reader() != binding["application"]:
            raise AcceptanceError("Application changed before publication")
        candidate.validate_unchanged()
        if _held_calculation_hash(candidate) != held_calculation_hash:
            raise AcceptanceError("Held calculation/profile metadata changed before publication")
        candidate.publish()
        try:
            finalize_receipt(path, identity_reader=identity_reader)
        except Exception as exc:
            raise AcceptanceError(
                f"Published; acceptance receipt is incomplete. Recheck with --finalize-receipt {path}: {exc}"
            ) from exc
        return path


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=PROJECT / "pre/input.json")
    parser.add_argument("--output-dir", type=Path, default=PROJECT / "output")
    parser.add_argument("--post-dir", type=Path)
    parser.add_argument("--stage", choices=("0710", "all"), default="0710")
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--oracle", type=Path, default=DEFAULT_ORACLE)
    parser.add_argument("--receipt", type=Path)
    parser.add_argument("--finalize-receipt", type=Path)
    args = parser.parse_args(argv)
    try:
        if args.finalize_receipt:
            finalize_receipt(args.finalize_receipt)
            path = args.finalize_receipt
        else:
            from pier_design.cli import GenerationOptions
            options = GenerationOptions(input_path=args.input, output_dir=args.output_dir,
                                        post_dir=args.post_dir, stage=args.stage,
                                        overwrite=args.overwrite, jrsnap=True)
            path = accept_generation(options, oracle_path=args.oracle, receipt_path=args.receipt)
    except (AcceptanceError, ReadbackError, OSError, ValueError, KeyError) as exc:
        print(f"受入未完了: {exc}", file=sys.stderr)
        return 2
    print(f"受入完了（入力読込・再保存のみ、解析未実行）: {path.resolve()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
